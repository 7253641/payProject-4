package ismsapp

import grails.test.*

class ABCTests extends GrailsUnitTestCase {
    def abcService
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testSomething() {
       abcService.query("301221111",1);
    }
}
