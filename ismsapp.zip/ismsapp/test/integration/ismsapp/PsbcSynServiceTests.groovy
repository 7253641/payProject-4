package ismsapp

import grails.test.*

class PsbcServiceTests extends GrailsUnitTestCase {
    def psbcService
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testSomething() {
       psbcService.query();
    }
}
