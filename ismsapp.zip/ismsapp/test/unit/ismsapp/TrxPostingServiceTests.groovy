package ismsapp

import grails.test.*
import ismsapp.banks.CcbService
import ismsapp.banks.AbcService
import ismsapp.banks.BocService

class TrxPostingServiceTests extends GrailsUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void rtestCcb() {
        def ccbService=new CcbService();
        println ccbService.query("20110331","711033157487411718");
    }
    void rtestAbc(){
        def abcService=new AbcService();
        println abcService.query("343434",1);
    }
    void testBoc(){
        def bocService=new BocService();
        bocService.printXml();
    }

}
