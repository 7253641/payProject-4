package ismsapp

import grails.test.*

class AcquireSynTrxTests extends GrailsUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testSomething() {


         def a = new Excel2003Builder(new FileInputStream(new File("E:\\银行B2C对账数据\\光大银行2012.2.1.xls"))).eachLine {
             println "First column on row ${it.rowNum} = ${cell(0)}"
         }
    }
}
