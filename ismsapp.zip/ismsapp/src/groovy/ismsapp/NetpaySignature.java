package ismsapp;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Enumeration;

import sun.misc.BASE64Encoder;

public class NetpaySignature{

	public String sign(String algorithm, byte[] srcData,String path)throws Exception{
	    try{
	           KeyStore store = KeyStore.getInstance("JKS");
	           FileInputStream stream = new FileInputStream(path);
	           String passwd = "reapal2012";
	           store.load(stream, passwd.toCharArray());
	           Enumeration en = store.aliases();
	           String pName = null;
	           while (en.hasMoreElements()){
	        	   String n = (String)en.nextElement();
	        	   if (store.isKeyEntry(n)){
	        		   pName = n;
	        	   }
	           }
	           PrivateKey key = (PrivateKey)store.getKey(pName, passwd.toCharArray());
	           Signature signature=Signature.getInstance(algorithm);
	           signature.initSign(key);
	           signature.update(srcData);
	           byte[] signedData = signature.sign();
	           System.out.println("已签名" + new BASE64Encoder().encode(signedData));
	           return new BASE64Encoder().encode(signedData);
	    }catch(Exception e){
	    	throw new Exception("signature.sign.error");
	    }
	}
	

	public boolean verify(String algorithm, byte[] srcData, byte[]signedData,String path)throws Exception{

		CertificateFactory certInfo=CertificateFactory.getInstance("x.509");
		X509Certificate cert = (X509Certificate) certInfo.generateCertificate(new FileInputStream(path));
		PublicKey publicKey = cert.getPublicKey();
		try{
			Signature sign3=Signature.getInstance(algorithm);
			sign3.initVerify(publicKey);
			sign3.update(srcData);
			return sign3.verify(signedData);
		}catch(Exception e){
			throw new Exception("signature.verify.error");
		}
		}
}
