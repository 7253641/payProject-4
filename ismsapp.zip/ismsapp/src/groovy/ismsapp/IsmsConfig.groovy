package ismsapp
import java.util.EnumMap;
import java.util.Map
import java.text.DecimalFormat;

/**
 * Created by IntelliJ IDEA.
 * User: Kitian
 * Date: 11-4-1
 * Time: 上午11:42
 * To change this template use File | Settings | File Templates.
 */
public class IsmsConfig {
    public static enum TrxSTS{UNPAID,SUCCESS,FAILURE,CLOSED,UNCERTAIN,NOTFOUND}
    private static EnumMap<TrxSTS,String> stateMap=new EnumMap<TrxSTS,String>(TrxSTS.class);
    static {
        stateMap.put(TrxSTS.UNPAID,"0");
        stateMap.put(TrxSTS.SUCCESS,"1");
        stateMap.put(TrxSTS.FAILURE,"2");
        stateMap.put(TrxSTS.CLOSED,"3");
        stateMap.put(TrxSTS.UNCERTAIN,"5");
        stateMap.put(TrxSTS.NOTFOUND,"-1");
    }

    public static String getTrxsts(TrxSTS ts){
        return stateMap.get(ts);
    }
    def static Map TrxstsDesc=["0":"未支付","1":"付款成功","2":"付款失败","3":"关闭",'5':"状态不确定","-1":"不存在"]

    public static String getFormatAmount(String amount,int exp) {
		BigDecimal big = new BigDecimal(amount) ;
		BigDecimal big2=big.multiply(new BigDecimal(Math.pow(10,exp)));
		return new DecimalFormat("0.00").format(big2);
   }
}


