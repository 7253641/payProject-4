package spdb;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author edward
 */
public class Spdb {
    public static String getSign(String plain)
    {
        try{
            return com.csii.payment.client.core.MerchantSignVerify.merchantSignData_ABA(plain);
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public static boolean decodeSign(String signature,String plain)
    {
        try{
            return com.csii.payment.client.core.MerchantSignVerify.merchantVerifyPayGate_ABA(signature,plain);
        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
}
