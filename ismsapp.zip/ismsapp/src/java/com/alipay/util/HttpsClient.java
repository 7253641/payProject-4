package com.alipay.util;

import org.apache.http.client.HttpClient;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreProtocolPNames;

import javax.net.ssl.*;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

/**
 * Created with IntelliJ IDEA.
 * User: admin
 * Date: 14-3-6
 * Time: 上午10:50
 * To change this template use File | Settings | File Templates.
 */
public class HttpsClient {

    public static HttpClient getInstance() throws KeyManagementException,
            NoSuchAlgorithmException {
        DefaultHttpClient client = new DefaultHttpClient();
        client.getParams().setParameter(ClientPNames.COOKIE_POLICY,
                CookiePolicy.BROWSER_COMPATIBILITY);
        client.getParams().setParameter(CoreProtocolPNames.USER_AGENT,
                "Mozilla/5.0 (Windows NT 6.2; rv:18.0) Gecko/20100101 Firefox/18.0");
        // HTTPS应绕开证书验证
        SSLContext context = SSLContext.getInstance("TLS");
        context.init(null, new TrustManager[] { new EasyTrustManager() },null);
        SSLSocketFactory factory = new SSLSocketFactory(context);
        factory.setHostnameVerifier(new EasyHostnameVerifier());
        Scheme https = new Scheme("https", factory, 443);
        client.getConnectionManager().getSchemeRegistry().register(https);
        return client;
    }


    /**
     * 自定义私有类：绕开HTTPS证书校验
     */
    private static class EasyTrustManager implements X509TrustManager {
        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return null;
        }

        @Override
        public void checkClientTrusted(X509Certificate[] certs, String authType) {
        }

        @Override
        public void checkServerTrusted(X509Certificate[] certs, String authType) {
        }
    }

    private static class EasyHostnameVerifier implements X509HostnameVerifier {
        public boolean verify(String arg0, SSLSession arg1) {
            return true;
        }
        public void verify(String arg0, SSLSocket arg1) throws IOException {}
        public void verify(String arg0, String[] arg1, String[] arg2) throws SSLException {}
        public void verify(String arg0, X509Certificate arg1) throws SSLException {}
    }

}
