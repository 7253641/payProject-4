

import ebank.core.remote.entity.CommResult;
import com.bocom.netpay.b2cAPI.BOCOMB2COPReply;


/**
 * @author xiexh
 * Description: �ӿ�ʹ��jni�Ĵ���
 * 
 */
public interface JniProxyService {
	/**
	 * ��ݷ���IDȡ�ü������
	 * @param plain
	 * @param serviceid
	 * @param cmd 
	 * @return
	 */
	public String getCrypt(String plain,String serviceid,String cmd);
	
	/**
	 * ��֤ǩ�����
	 * @param plain
	 * @param serviceid
	 * @return
	 */
	public boolean verify(String plain,String serviceid,String cmd);
	
	/**
	 * ����
	 * @param plain
	 * @param serviceid
	 * @param cmd
	 * @return
	 */
	public String decrypt(String plain,String serviceid,String cmd);
	
	/**
	 * ��ѯ
	 * @param orders
	 * @return
	 */
	public CommResult  getRep(String plain,String serviceid,String orders);

}
