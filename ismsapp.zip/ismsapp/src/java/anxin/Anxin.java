/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package anxin;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import com.anxin.ipg.util.MD5;

/**
 *
 * @author edward
 */
public class Anxin extends MD5
{
    public static String toStr(String str)
    {
        String sign="";
        try
        {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(str.getBytes());
            byte b[] = md.digest();
            int i;
            StringBuffer buf = new StringBuffer("");
            for (int offset = 0; offset < b.length; offset++)
            {
                i = b[offset];
                if (i < 0)
                   i += 256;
                if (i < 16)
                   buf.append("0");
                buf.append(Integer.toHexString(i));
            }
            sign = buf.toString();
            //System.out.println("result==: " + buf.toString());// 32位的加密
        }
        catch (NoSuchAlgorithmException e)
        {
            e.printStackTrace();
        }
        return sign;
    }
}
