import cn.tempus.pt.supplier.ca.CAUtil;
import cn.tempus.pt.supplier.exception.TrxException;
import cn.tempus.pt.supplier.response.GenericResponse;
import cn.tempus.pt.supplier.send.Sender;
import cn.tempus.pt.supplier.util.XMLConvertor;
import org.bouncycastle.util.encoders.Base64;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: qiuqiu
 * Date: 14-6-24
 * Time: 下午3:23
 * To change this template use File | Settings | File Templates.
 */
public class TftSender extends Sender
{
    private static String CONN;
     private static String METHOD;
     private static String MER_ID;
     private static String VERSION;
     private static String CHARSET;
     private static final String HTTP_CONTEXT = "/middleWeb/webconn";
     private static final String HTTPS_CONTEXT = "/middleWeb/security/webconn";

    private String path;

    public void setPath(String path){
        this.path=path;



//       ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
//    try {
//      InputStream fis = classLoader.getResourceAsStream(path+"payConfig.properties");
//      Properties prop = new Properties();
//      prop.load(fis);
//      fis.close();
//      METHOD = prop.getProperty("connMethod");
//      if ("80".equals(prop.getProperty("connPort")))
//        CONN = METHOD + "://" + prop.getProperty("connIp");
//      else {
//        CONN = METHOD + "://" + prop.getProperty("connIp") + ":" +
//          prop.getProperty("connPort");
//      }
//
//      MER_ID = prop.getProperty("merId");
//      VERSION = prop.getProperty("version");
//      CHARSET = prop.getProperty("charset");
//      CAUtil.loadPrivPFX(path+prop.getProperty("keyFile"),
//              prop.getProperty("password"));
//      CAUtil.loadCertificate(path+prop.getProperty("certFile"));
//    } catch (FileNotFoundException e) {
//      System.out.println("无法读取商户端配置文件");
//      e.printStackTrace();
//    } catch (IOException e) {
//      System.out.println("系统发生无法预期的错误");
//      e.printStackTrace();
//    } catch (Exception e) {
//      System.out.println("系统发生无法预期的错误");
//      e.printStackTrace();
//    }


  }

}
