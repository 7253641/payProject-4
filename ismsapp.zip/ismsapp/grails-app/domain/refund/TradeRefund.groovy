package refund

class TradeRefund extends refund.TradeBase{

    String  submitBatch
    String  submitType
    Long    customerOperId
    String  submitter
    Long    backFee
    Long    realRefundAmount
    String  refundType
    String  refundParams
    String  royaltyRefundStatus
    String  acquirerCode
    String  acquirerMerchantNo
    Long    acquirer_account_id
    String  checkStatus
    Long    checkOperatorId
    Date    checkDate
    Long    handleOperId
    String  handleOperName
    String  handleBatch
    String  handleCommandNo
    String  handleStatus
    Date    handleTime
    Long    realityRefundAmount  // 实际退款金额 贺连鑫

    static constraints = {
        submitBatch(maxSize: 16,blank: false)
        submitType(maxSize: 32,inList: ['manual','automatic'])
        customerOperId(nullable: true)
        submitter(maxSize: 32)
        refundType(maxSize: 16,inList: ['normal','royalty'])
        refundParams(maxSize: 512,nullable: true)
        royaltyRefundStatus(maxSize: 16,inList: ['starting','processing','successed','failed'])
        acquirerCode(maxSize: 16,nullable: true)
        acquirerMerchantNo(maxSize: 20,nullable: true)
        checkStatus(maxSize: 16)
        checkOperatorId(nullable: true)
        checkDate(nullable: true)
        handleOperId(nullable: true)
        handleOperName(maxSize: 16,nullable: true)
        handleBatch(maxSize: 16,nullable: true)
        handleCommandNo(maxSize: 40,nullable: true)
        handleStatus(maxSize: 16,inList: ['waiting','fChecked','checked','fRefuse','sRefuse','submited','completed'])
        handleTime(nullable: true)
    }

    def static submitTypeMap = ['manual': '人工提交', 'automatic': '接口提交']
    def static refundTypeMap = ['normal': '普通退款', 'royalty': '分润退款']
    def static royaltyRefundStatusMap = ['starting': '开始', 'processing': '处理中','successed':'成功','failed':'失败']
    def static handleStatusMap = ['waiting': '待处理','fChecked':'初审通过', 'checked': '已审核','fRefuse':'初审拒绝','sRefuse':'终审拒绝','submited':'已提交','completed':'完毕']
}
