package ismsapp

class Gwtrxs {
    String trxnum
    String servicecode
    String acquirerCode
    String acquirerMerchant
    String id

    long amount
    String trxsts

    String submitdates
    String acquirerSeq

     Date createdate

    static constraints = {
        trxnum(nullable: false,maxsize:128)
        amount(maxsize:12)
    }
    static mapping={
        table 'GWTRXS'
        cache   usage: 'read-only'
        id  generator:'assigned', type: 'string'
        trxnum column: 'TRXNUM'
        servicecode column:"SERVICECODE"
        acquirerCode column:"ACQUIRER_CODE"
        acquirerMerchant column:"ACQUIRER_MERCHANT"
        amount     column:"AMOUNT"
        trxsts    colunm:"TRXSTS"
        submitdates column:"SUBMITDATES"
        acquirerSeq column:"ACQUIRER_SEQ"
        createdate colum:" Date dateCreated"
    }
}
