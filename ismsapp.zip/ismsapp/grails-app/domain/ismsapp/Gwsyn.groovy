package ismsapp

class Gwsyn {
    String synsts
    Date   createdate;
    int    syntimes
    Date   synclosedate
    String synresult
    String id
    static constraints = {
         synsts(inList:['Y','N','F'],nullable:false)
         synresult(maxsize:64,nullable:true)
    }
    static mapping = {
        id  generator:'assigned', type: 'string',column:"trxid"
    }
}
