package ismsapp

import grails.converters.JSON

class PostFaultTrxController {
    def httpInvokeClientService;
    def create={
        println "*******************post fault trx*******************";
        def AcquireFaultTrx faultTrx=new AcquireFaultTrx(params);
        if(faultTrx.iniSts==faultTrx.changeSts) {
            def mp=[response:"-1",resmsg:"状态相同未处理"]
            render mp as JSON
            return
        }
        def Gwtrxs gwtrx;
        if(params.id){
            gwtrx=Gwtrxs.findById(params.id)
            if(gwtrx==null){
                def mp=  [response:"-1",resmsg:"交易未找到"]
                render mp as JSON
                return
            }
        }else{
            gwtrx=Gwtrxs.findByTrxnumAndAcquirerMerchant(trxnum:params.trxid,acquirerMerchant:params.acquirerMerchant)
        }
        if(!gwtrx){
            def mp= [response:-1,resmsg:"交易未找到"]
            render mp as JSON
            return
        }
        if(!String.valueOf(gwtrx.amount).equals(params.trxamount)){
            println  gwtrx.amount+"="+params.amount
            def mp= [response:-1,resmsg:"金额不等"]
            render mp as JSON
            return
        }
        if(!faultTrx.trxid) faultTrx.trxid=gwtrx.id
        faultTrx.acquireCode=gwtrx.acquirerCode
        faultTrx.acquireMerchant=gwtrx.acquirerMerchant
        faultTrx.changeApplier=params.oper
        faultTrx.trxdate=gwtrx.submitdates?.substring(0,8)
        faultTrx.createDate=new Date()
        faultTrx.authDate=new Date()
        faultTrx.updateDate=new Date()
        if(!faultTrx.datasrc){
            faultTrx.datasrc="MANUAL"
        }
        faultTrx.acquireTrxnum=gwtrx.trxnum
        if(!faultTrx.authSts){
            faultTrx.authSts='U';    //set U
        }
        faultTrx.finalSts='WAIT'
        if(faultTrx.save(flush:true)){
            if(faultTrx.authSts=='U'||faultTrx.authSts=='Y'){
                if(httpInvokeClientService.tx_next(faultTrx.id)){
                    def mp= [response:0,resmg:"已受理,处理成功"]
                    render mp as JSON
                }else{
                    def mp= [response:0,resmg:"已受理,处理失败"]
                    render mp as JSON
                }
            }else{
                def mp= [response:0,resmg:"已受理,等待审核"]
                render mp as JSON
            }
            return
        }else{
           faultTrx.errors.each {
               println it
           }
           def mp=[response:0,resmg:"受理失败"]
           render mp as JSON;
        }

    }
    def authorize={
        def faultTrx= AcquireFaultTrx.findById(params.id)
        if(!faultTrx){
            def mp= [response:-1,resmsg:"不存在该差错交易"]
            render mp  as JSON
            return
        }
        if(!faultTrx.authSts.equals('N')||!params.authOper){
            def mp=[response:-1,resmsg:"不能审核"]
            render mp  as JSON
            return
        }
        faultTrx.authDate=new Date()
        faultTrx.authOper=params.authOper
        faultTrx.authSts=params.authSts
        faultTrx.faultAdvice=params.faultAdvice
        if(faultTrx.save(flush:true)){
            if(faultTrx.authSts=='U'||faultTrx.authSts=='Y'){
                if(httpInvokeClientService.tx_next(faultTrx.id)){
                    render ([response:0,resmsg:"审核成功,交易自动处理成功"] as JSON)
                    return
                }else{
                    render ([response:0,resmsg:"审核成功,交易自动处理失败"] as JSON)
                    return
                }
            }else{
                    render ([response:0,resmsg:"审核不通过"] as JSON)
                    return
            }
        } else{
            faultTrx.errors.each {
               println it
           }
           render ([response:0,resmg:"受理失败"] as JSON);
        }
    }
}
