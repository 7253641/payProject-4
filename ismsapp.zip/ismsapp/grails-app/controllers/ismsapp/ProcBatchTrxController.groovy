package ismsapp

import java.text.SimpleDateFormat
import groovyx.net.http.HTTPBuilder

import static groovyx.net.http.Method.GET
import static groovyx.net.http.ContentType.TEXT
import grails.converters.JSON
import groovy.sql.Sql

import grails.converters.XML
import org.codehaus.groovy.grails.commons.ConfigurationHolder
import org.hibernate.Session
import org.hibernate.transform.AliasToEntityMapResultTransformer
import org.springframework.orm.hibernate3.HibernateCallback
import org.springframework.orm.hibernate3.HibernateTemplate
import com.burtbeckwith.grails.plugin.datasources.DatasourcesUtils

class ProcBatchTrxController {


    def fileParseService;
    def dataSource_ismp
    def accountSynTrxService
    def httpInvokeClientService;

    def parse = {
        println "uri  is ${params.uri}  ${params.uri instanceof String[]}"
        println "bankCode  is ${params.bankCode}  ${params.bankCode instanceof String[]}"
        println "bankAccountNo  is ${params.bankAccountNo} ${params.bankAccountNo instanceof String[]}"
        println "acquireMerchant  is ${params.acquireMerchant} ${params.acquireMerchant instanceof String[]}"
        println "serviceCodes  is ${params.serviceCodes} ${params.serviceCodes instanceof String[]}"
        println "beginTime  is ${params.beginTime} "
        println "endTime  is ${params.endTime} "
        println "oper  is ${params.oper} "

        def now = new Date()
        def batchnum = params.bankCode + new SimpleDateFormat("yyyyMMddHHmmss").format(now);

        def flag=0
        if(params.uri instanceof String[]){
               params.uri.each {
                  flag=dealFile(it,now,batchnum)
                  if(flag==-1){
                     render ([response:-1,resmsg:'处理文件失败'] as JSON)
                     return
                  }
               }
        } else{
            flag=dealFile(params.uri,now,batchnum)
            if(flag==-1){
                render ([response:-1,resmsg:'处理文件失败'] as JSON)
                return
            }else if(flag==0){
                render ([response:0,resmsg:'文件没有内容'] as JSON)
                return
            }
        }

//        println "serviceCode ${params.serviceCodes.join(',').toString()}"
        flag=synToResult(batchnum,now)
        if(flag==-1){
            render ([response:-1,resmsg:'对账处理失败'] as JSON)
            return
        }
//        synTest()
        flag=synTofault('N',batchnum)
        if(flag==-1){
            render ([response:-1,resmsg:'差错交易处理失败'] as JSON)
        }else{
            render ([response:1,resmsg:'对账处理完成'] as JSON);
        }
    }

    def dealFile(uri,now,batchnum){
        def resURL = ConfigurationHolder.config.boss.inner.server
        String resurl = resURL + uri
        println "resurl  is ${resurl} "
        def extension = uri.substring(uri.lastIndexOf(".") + 1)
        println "extension  is ${extension} "
        def bankCode = params.bankCode
        println "bankName  is ${bankCode} "
	    def trxlist = []
        def flag=1
        try{
        def http = new HTTPBuilder(resurl);
        switch (extension) {
            case "txt":
                http.request(GET, TEXT) {req ->
                    response.success= { resp, reader ->
//                        println "Content-Type: ${resp.headers.'Content-Type'}"
                        trxlist=fileParseService.parseTxt(bankCode,reader);
                    }
                }
                break;
            case "xls":
                http.request(GET, XML) {req ->
                    response.success = { resp, reader ->
                        trxlist=fileParseService.parseXls(bankCode,reader);
                    }
                }
                break;
            case "xlsx":
                http.request(GET, XML) {req ->
                    response.success = { resp, reader ->
                        trxlist=fileParseService.parseXlsx(bankCode,reader);
                    }
                }
            break;
            case "csv":
                http.request(GET,XML) {req ->
                    response.success= { resp, reader ->
//                        println "Content-Type: ${resp.headers.'Content-Type'}"
                        trxlist=fileParseService.parseCsv(bankCode,reader);
                    }
                }
                break;
        }
        if(trxlist?.size()==0){
            return 0
        }

        accountSynTrxService.importAcquireSynTrx(trxlist,params,now,batchnum)
        } catch (e){
             log.error(e.printStackTrace())
            flag=-1
        }
        return flag
    }

    def synToResult(batchnum,now){
        def flag=1
        try{
//            accountSynTrxService.synTest(params,batchnum,now)
            accountSynTrxService.synShot(params,batchnum,now)
            accountSynTrxService.synOver(params,batchnum,now)
            accountSynTrxService.importAcquireSynResult(params,batchnum,now)
        } catch (e){
             log.error(e.printStackTrace())
            flag=-1
        }
        return flag
    }



    def synTofaultx(authsts,batchnum){
        def db=new Sql(dataSource_ismp);
        def sqls="""
                insert into acquire_fault_trx
                (id, version, acquire_authcode, acquire_cardnum, acquire_code, acquire_date, acquire_merchant, acquire_refnum, acquire_seq,
                 acquire_trxnum, auth_date, auth_oper, auth_sts, change_applier, change_sts, create_date, datasrc, fault_advice, final_result,
                 final_sts, trxamount, trxdate, trxid, update_date, ini_sts, payer_ip,batchnum)
                 select SEQ_ORDEREXT.NEXTVAL,0,acquire_authcode,acquire_cardnum, acquire_code, acquire_date, acquire_merchant, acquire_refnum, acquire_seq,
                 trxid,sysdate,null,$authsts,applier,change_sts,sysdate,'FILE',NULL,NULL,
                 'WAIT',amount,trxdate,id,sysdate,ini_sts,payer_ip,batchnum
                 from (
                 select distinct trxid,acquire_merchant,acquire_date,acquire_seq,s.amount,acquire_authcode,acquire_cardnum,acquire_code,acquire_refnum,$params.oper as applier,
                 s.trxsts as change_sts,g.trxsts as ini_sts,g.payer_ip,g.id as id,$batchnum as batchnum,substr(g.submitdates,0,8) as trxdate
                 from acquire_syn_trx s left join gwtrxs g
                 on s.trxid=g.trxnum and s.acquire_code=g.acquirer_code and s.amount=g.amount
                 where s.trxsts!=g.trxsts and g.trxsts!=1 and s.batchnum=$batchnum
                )
              """
        db.execute(sqls)
        httpInvokeClientService.tx_batchNext(batchnum);
    }


    def synTofault(authsts,batchnum){
        def flag=1
        try{
            def db=new Sql(dataSource_ismp);
            def sqls="""
                    insert into acquire_fault_trx
                    (id, version, acquire_authcode, acquire_cardnum, acquire_code, acquire_date, acquire_merchant, acquire_refnum, acquire_seq,
                     acquire_trxnum, auth_date, auth_oper, auth_sts, change_applier, change_sts, create_date, datasrc, fault_advice, final_result,
                     final_sts, trxamount, trxdate, trxid, update_date, ini_sts, payer_ip,batchnum)
                     select SEQ_ORDEREXT.NEXTVAL,0,acquire_authcode,acquire_cardnum, acquire_code, acquire_date, acquire_merchant, acquire_refnum, acquire_seq,
                     trxid,sysdate,null,'"""+authsts+"""','"""+params.oper+"""',change_sts,sysdate,'FILE',NULL,NULL,
                     'WAIT',amount,trxdate,id,sysdate,ini_sts,payer_ip,batchnum
                     from (
                     select distinct
                     acquire_authcode
                     ,acquire_cardnum
                     ,acquire_code
                     ,to_char(acquire_date,'yyyymmdd') as acquire_date
                     ,acquire_merchant
                     ,acquire_refnum
                     ,acquire_seq
                     ,trxid
                     ,s.trxsts as change_sts
                     ,s.amount
                     ,substr(g.submitdates,0,8) as trxdate
                     ,g.id as id
                     ,g.trxsts as ini_sts
                     ,g.payer_ip
                     ,s.batchnum
                     from acquire_syn_trx s left join gwtrxs g
                     on s.trxid=g.trxnum
                     and g.servicecode in ("""+joinInlist(params.serviceCodes)+""")

                     where
                      s.trxsts!=g.trxsts
                     and g.trxsts!=1
                     and s.batchnum='"""+batchnum+"""'
                    )
                  """

            println sqls

            db.execute(sqls)
            httpInvokeClientService.tx_batchNext(batchnum);
        } catch (e){
             log.error(e.printStackTrace())
            flag=-1
        }
        return flag
    }



    def synTest(){
        //查长账（我方系统比银行多）
        def ssf =  " '2005', '2005', '9102', '102', '6666666666'"
        def query="""
                 select count(*)
                     from gwtrxs g
                     where
                      g.servicecode in (${joinInlist(params.serviceCodes)})
              """

        def db=new Sql(dataSource_ismp);
        def count=0
        println "==================================================="
        count = db.firstRow(query)
         println       count
    }



    def joinInlist(serviceCodes){
        StringBuilder ids= new StringBuilder()
        if(serviceCodes instanceof String[]){
            int len = serviceCodes.size();
            for(int i=0 ;i<len;i++){
                if(i>0&&i<len){
                 ids.append(",")
                }
               ids.append("'").append(serviceCodes[i]).append("'")
            }
        }else{
             ids.append("'").append(serviceCodes).append("'")
        }

        return ids
    }
}
