package ismsapp

import grails.converters.JSON

class DownAcqTrxController {
    def cmbService;
    def abcService
    def download = {
         def acquiredate=params.acqdate
         def acquirecode=params.acqcode
         def withaction=true;
         def batchnum=""
         switch (acquirecode){
             case "CMB":
                 batchnum=cmbService.downloadTrxs(acquiredate)
                 break;
             case "ABC":
                 batchnum =abcService.getSettleList(acquiredate)
                 break;
             default:
                withaction=false;
                break;
         }
         if(!withaction){
            render ([response:-1,resmsg:"未提供该服务"] as JSON)
            return
         }else{
            render ([response:0,resmsg:"处理成功",batchnum:batchnum] as JSON)
            return
         }
    }
}
