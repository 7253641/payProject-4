package ismsapp

import org.apache.commons.httpclient.HttpClient
import org.apache.commons.httpclient.methods.PostMethod
import org.apache.commons.httpclient.params.HttpMethodParams
import org.apache.commons.httpclient.HttpStatus
import org.codehaus.groovy.grails.commons.ConfigurationHolder

class HUnionPayTransferController {

    def sendData= {
        String strSendData="";
        ByteArrayOutputStream baout = new ByteArrayOutputStream();
        BufferedOutputStream bout = new BufferedOutputStream(baout);
        BufferedInputStream bin = new BufferedInputStream(request.getInputStream());
        byte [] bs = new byte[1024];
        int len = 0;
        while((len = bin.read(bs, 0, 1024))!=-1){
                bout.write(bs, 0 , len);
        }
        bin.close();
        bout.flush();
        bout.close();
        strSendData = baout.toString();
        println "---begin"+strSendData+"---end";
        render send(strSendData);
    }

    def send(String strSendData) throws Exception {
        String strResp="";
        HttpClient httpClient = new HttpClient();
        PostMethod postMethod = null;
        postMethod = new PostMethod(ConfigurationHolder.config.service.url);

        httpClient.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "GBK");
        postMethod.setRequestBody(strSendData);
        int statusCode = httpClient.executeMethod(postMethod);
        if (statusCode != HttpStatus.SC_OK) {
            byte[] responseBody = postMethod.getResponseBody();
            strResp = new String(responseBody, "GBK");
            System.out.println(strResp);
            throw new Exception("send bankfailure:" + strResp)
        }
        else {
            byte[] responseBody = postMethod.getResponseBody();
            strResp = new String(responseBody, "GBK");
            System.out.println("server response:" + strResp);
        }
        postMethod.releaseConnection();
        return strResp;
    }

}
