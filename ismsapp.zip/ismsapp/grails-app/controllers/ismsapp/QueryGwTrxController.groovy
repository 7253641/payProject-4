package ismsapp

import grails.converters.JSON
import org.codehaus.groovy.grails.commons.ConfigurationHolder
import groovy.sql.Sql

class QueryGwTrxController {
    def heePayService;
    def ccbService;
    def abcService;
    def abc_B2BService;
    def psbcService;
    def unionpayService;
    def cmbService;
    def fxppaycardService;
    def icbcService;
    def commService;
    def bocService;
    def spdbService;
    def anxinService;
    def citicService;
    def cebService;
    def cmbcService;
    def icbcLiteService;
//    def cbhbService;
//    def citic_B2BService;
    def cmbc_B2BService;

    def ccb_B2BService;

    def httpInvokeClientService;
    def httpInvokeABCService;

    def sdbService;
    def sdb_B2BService;
    def hzBankService;
    def litePayService;
    def cibService;
    def yintongService;
    def onlineService;
    def tftService;


     def dataSource_ismp;

    def synAcquire = {
    log.info("synAcquire request from:"+params.id+" params:"+params)

        Gwtrxs trx=Gwtrxs.findById(params.id)
//        log.info(ConfigurationHolder.config.dataSource.ismp.url)
//        log.info(ConfigurationHolder.config.dataSource.ismp.logSql)
//        log.info("--------------------kjkjjkjjk")
//        if(!trx){
//            render ([response:-1,resmsg:"未找到对应交易"+params.id,proc:"未同步银行返回"] as JSON)
//            return
//        }
//        if(trx.trxsts in['3','5']){
//            render ([response:0,resmsg:IsmsConfig.TrxstsDesc.get(trx.trxsts),proc:"未同步银行返回"] as JSON)
//            return
//        }

        def res;
        def query=true
        switch (trx.acquirerCode){
            case "HEEPAY":
                res=heePayService.query(trx.submitdates,trx.trxnum)
                break;
             case "YINTONG":
                res=yintongService.query(trx.submitdates,trx.trxnum)
                break;
            case "tft":
                res=tftService.query(trx.submitdates,trx.trxnum)
                break;
            case "ONLINE_FIVE":
                res=onlineService.query(trx.submitdates,trx.trxnum)
                break;
             case "ONLINE":
                res=onlineService.query(trx.submitdates,trx.trxnum)
                break;
            case "CCB":
                res=ccbService.query(trx.submitdates?.substring(0,8),trx.trxnum)
                break;
            case "ABC": //农行
                res= abcService.query(trx.trxnum, "0")
                break;
            case "ABC_B2B":  //农行B2B
                res= abc_B2BService.query(trx.trxnum)
                break;
            case "PSBC":
//                res=psbcService.query(trx.trxnum)
                break;
//            case "CMB":
//                res=cmbService.query(trx.submitdates.substring(0,8),trx.trxnum)
//                break;
            case "ICBC":
                 res=icbcService.query(trx.trxnum,trx.submitdates)
                break;
             case "BOCM":
                 res=commService.query(trx.trxnum,trx.submitdates)
                break;
             case "BOC":
                 res=bocService.query(trx.trxnum)
                 break;
            case ["SPDB","SPDB_B2B"]:
                res=spdbService.query(trx.trxnum)
                break;
            case "CITIC":
                 res= citicService.query(trx.trxnum,'CITIC')
                break;
             case "CEB":
                 res=cebService.query(trx.trxnum,trx.submitdates,trx.amount)
               break;
             case "CMBC":
                 res=cmbcService.query(trx.trxnum)
               break;
//              case "ICBCLITE":
//                 res=icbcLiteService.query(trx.trxnum)
//               break;
//             case "CBHB":
//                   log.info("jinru  CBHB-------------------------------------")
//                 res=cbhbService.query(trx.trxnum)
//               break;
            case "CITIC_B2B":
                   log.info("jinru  CITIC_B2B-------------------------------------")
                   res= citicService.query(trx.trxnum,'CITIC_B2B')
               break;
            case "CMBC_B2B":
                 res=cmbc_B2BService.query(trx.trxnum)
               break;
//             case "HSBK":
//                 res=hsbkService.query(trx.trxnum,trx.submitdates)
//               break;
             case "CCB_B2B":
//                 res=ccb_B2BService.query(trx.trxnum,trx.submitdates.substring(0,8))
                break;

            case "SDB": //深发展
                res= sdbService.query(trx.trxnum)
                break;
            case "SDB_B2B":  //深发展B2B
//                res= sdb_B2BService.query(trx.trxnum, trx.submitdates.substring(0,8))
                break;

            case "HZBANK":  //杭州银行
//                res= hzBankService.query(trx.trxnum, trx.submitdates.substring(0,8))
                break;
             case "LITEPAY":  //杭州银行
//                   res =litePayService.query(trx.trxnum,trx.submitdates)
                break;
             case "CIB"://兴业银行
                   res = cibService.query(trx.trxnum,'CIB')
                 break;
             case "CIB_B2B":
                   res = cibService.query(trx.trxnum,'CIB_B2B')
                 break;
            default:
                query=false
                break;
        }
        //generate the fault transaction
        if(!query){
          render ([response:"-1",resmsg:"暂未提供该银行查询服务"] as JSON )
          return
        }
        if(!res){
            render([response:"-1",resmsg:"查询失败"] as JSON)
            return
        }
        if(res&&res.RESCODE?.equals("200-00")){
            if(res.STS.equals(IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS))&&!trx.trxsts.equals(res.STS)){
                AcquireFaultTrx faultTrx=new AcquireFaultTrx();
                faultTrx.properties=trx.properties
                faultTrx.properties=res;

                faultTrx.acquireCode=trx.acquirerCode
                faultTrx.trxid=trx.id
                faultTrx.trxdate=trx.submitdates.substring(0,8)
                faultTrx.iniSts=trx.trxsts as int
                faultTrx.createDate=new Date()
                faultTrx.updateDate=new Date();
                faultTrx.authDate=new Date()
                faultTrx.authOper="SYSTEM"
                faultTrx.authSts="U"
                faultTrx.changeApplier=params.oper==null?"SYSTEM":params.oper
                faultTrx.changeSts=1
                faultTrx.finalSts="SUCCESS"
                faultTrx.acquireMerchant=trx.acquirerMerchant
                faultTrx.acquireTrxnum=trx.trxnum
                faultTrx.trxamount=trx.amount
                if(!res.TRXAMOUNT&&!res.TRXAMOUNT.equals(trx.amount)){
                    render ([response:"0",resmsg:"交易"+IsmsConfig.TrxstsDesc.get(res.STS)+",金额差异,未处理"] as JSON);
                    return;
                }
                if(faultTrx.save(flush:true, failOnError :true)){
                    log.info("handle faulttrx id:"+faultTrx.id+"  trx.trxnum:"+trx.trxnum)
                    def flg=httpInvokeClientService.tx_next(faultTrx.id)
                    render ([response:"0",resmsg:"交易"+IsmsConfig.TrxstsDesc.get(res.STS)+",差错处理"+flg?"成功":"失败",trxsts:res.STS,proc:"同步银行返回"] as JSON);
                    return;
                }else{
                    faultTrx.errors.each {
                        log.info it
                    }
                    render ([response:-1,resmg:"交易"+IsmsConfig.TrxstsDesc.get(res.STS)+",产生差错交易失败",proc:"同步银行返回"] as JSON);
                }
            }else{
                log.info("trx.trxnum:"+trx.trxnum+" status:"+IsmsConfig.TrxstsDesc.get(res.STS))
                render ([response:0,resmsg:"交易"+IsmsConfig.TrxstsDesc.get(res.STS)] as JSON)
            }

         }else if(res&&res.RESCODE?.equals("200-02")){

            render(res.RESMSG);

        }else{
             render ([response:"0",resmsg:res.RESMSG,proc:"同步银行返回"] as JSON)
        }

    }
    def update={

    }

}
