package refund
import grails.converters.JSON
import ismsapp.Gwtrxs

class RefundController {

    def fxppaycardService
    def aotoApp = {
      log.info("aotoApp request from:"+params.id+" params:"+params)
      def tradeRefundInstance = TradeRefund.get(params.id)
        if(!tradeRefundInstance){
            render ([response:-1,resmsg:"未找到对应交易"+params.id,proc:""] as JSON)
            return
        }
           def res;
        def query=true
        switch (tradeRefundInstance.acquirerCode){
            case "FXPPAYCARD"://方兴高盛预付费卡退款
                res=fxppaycardService.fxppayRefund(tradeRefundInstance)
                break;
            default:
                query=false
                break;
        }
           render ([response:0,resmsg:res] as JSON)
    }
}
