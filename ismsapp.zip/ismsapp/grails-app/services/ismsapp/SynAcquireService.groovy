package ismsapp

import grails.converters.JSON
import groovy.sql.Sql



class SynAcquireService {

    static transactional = false
    def ccbService;
    def abcService;
    def psbcService;
    def unionpayService;
    def cmbService;    
    def fxppaycardService;
    def icbcService;
    def commService;
    def bocService;
    def spdbService;
    def anxinService;
    def citicService;
    def sdbService;
    def cebService;
    def cmbcService;
    def abc_B2BService;
    def cmbc_B2BService;

    def httpInvokeClientService;
    def httpInvokeABCService;
    def dataSource_ismp;

    def yintongService;
    def onlineService;
    def tftService;
    def inputdata(String acqcode){
        String sql="""
        insert into gwsyn
          (trxid, version, createdate, synclosedate, synresult, synsts, syntimes)
        select
          t.id, 0, t.createdate, sysdate, '', 'N', 0
        from gwtrxs t left join gwsyn g on t.id=g.trxid
        where 1=1
        and t.trxsts=0
        and trunc(t.createdate)>trunc(sysdate-3)
        and t.createdate<sysdate-5/(24*60)
        and g.trxid is null and ACQUIRER_CODE='$acqcode' """
        def db=new Sql(dataSource_ismp);
        db.execute sql

    }

    static void main(String[] args){

        Calendar t=Calendar.getInstance();

        t.set(Calendar.DAY_OF_MONTH,t.get(Calendar.DAY_OF_MONTH)-3);
        t.set(Calendar.HOUR,12);
        t.set(Calendar.MINUTE,0);
        t.set(Calendar.SECOND,0);
       println   t.time.format("yyy-MM-dd HH:mm:ss")
    }

    def serviceMethod() {

        Calendar t=Calendar.getInstance();
        t.set(Calendar.DAY_OF_MONTH,t.get(Calendar.DAY_OF_MONTH)-3);
        t.set(Calendar.HOUR,12);
        t.set(Calendar.MINUTE,0);
        t.set(Calendar.SECOND,0);

        List li = Gwsyn.createCriteria().list {
            eq("synsts","N")
            le("syntimes",3)
            ge("createdate",t.time)
            maxResults(50)
        }
        if(!li){
            log.info "li is null"
        }
        for (syn in li) {
            Gwtrxs trx = Gwtrxs.get(syn.id)
            if (!trx) {
                log.debug([response: -1, resmsg: "未找到对应交易" + syn.id, proc: "未同步银行返回"] as JSON)
                syn.synsts="F"
                syn.synresult="NOT_FOUND"
                syn.save(flush:true)
                continue
            }
            if (trx.trxsts in ['3', '5']) {
                log.debug([response: 0, resmsg: IsmsConfig.TrxstsDesc.get(trx.trxsts), proc: "未同步银行返回"] as JSON)
                 syn.synsts="F"
                syn.synresult="SUCESS_TRX"
                syn.save(flush:true)
                continue
            }
            def res;
            def query = true
            log.info "trxnum:"+trx.trxnum+"  acquirerCode:"+trx.acquirerCode

            try{
                log.info "login ...switch(trx.acquirerCode)"+trx.acquirerCode+"==========================="
                switch (trx.acquirerCode) {
                    case "YINTONG":
                       res=yintongService.query(trx.submitdates,trx.trxnum)
                       break;
                   case "tft":
                       res=tftService.query(trx.submitdates,trx.trxnum);
                       break;
                   case "ONLINE_FIVE":
                       res=onlineService.query(trx.submitdates,trx.trxnum)
                       break;
                    case "ONLINE":
                       res=onlineService.query(trx.submitdates,trx.trxnum)
                       break;
                    case "CCB":
                        res = ccbService.query(trx.submitdates?.substring(0, 8), trx.trxnum)
                        break;
                    case "ABC":
                        res= abcService.query(trx.trxnum, "0")
                        break;
                    case "PSBC":
                        res = psbcService.query(trx.trxnum)
                        break;
                    case "CMB":
                        res = cmbService.query(trx.submitdates.substring(0, 8), trx.trxnum)
                        break;
                    case "UNIONPAY":
                        res = unionpayService.query(trx.trxnum, trx.submitdates?.substring(0, 8))
                        break;
                    case "FXPPAYCARD":
                        res=fxppaycardService.query(trx.trxnum,trx.submitdates)
                        break;
                    case "ICBC":
                         res=icbcService.query(trx.trxnum,trx.submitdates)
                        break;
                    case "BOCM":
                         res=commService.query(trx.trxnum,trx.submitdates)
                        break;
                    case "BOC":
                         res=bocService.query(trx.trxnum)
                        break;
                    case "SPDB":
                         res=spdbService.query(trx.trxnum)
                        break;
                    case "PREPAYCARD":
                         res=anxinService.query(trx.trxnum,trx.submitdates?.substring(0,8),trx.amount,trx.trxsts)
                        break;
                    case "CITIC":
                         res= citicService.query(trx.trxnum)
                        break;
                    case "SDB": //深发展
                       res= sdbService.query(trx.trxnum)
                       break;
                    case "CEB":
                       res=cebService.query(trx.trxnum,trx.submitdates,trx.amount)
                       break;
                    case "CMBC":
                       res=cmbcService.query(trx.trxnum)
                       break;
                    case "ABC_B2B":
                        log.info "login ...ABC_B2B======================================================="
                       res=abc_B2BService.query(trx.trxnum)
                       break;
                    case "CMBC_B2B":
                         log.info "login ...CMBC_B2B======================================================="
                       res=cmbc_B2BService.query(trx.trxnum)
                       break;
                    default:
                        log.info "login ...case.....default================================================"
                        query = false
                        break;
                }
            }catch(Exception e){
                 log.info "trxnum excepiton:"+trx.trxnum
                e.printStackTrace();
            }
            if(!query){
                 log.info "login.....if(!query)========"+query
                syn.synsts="F"
                syn.synresult="SERVICE_NOTPROVIED"
                syn.save(flush:true)
                continue
            }
            if(res){
              log.info "trxnum:"+trx.trxnum+"  res.RESCODE:"+res.RESCODE
            }else{
              log.info "trxnum:"+trx.trxnum+"  res is null"
            }
            if (res&&res.RESCODE?.equals("200-00")) {
                if (res.STS.equals(IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)) && !trx.trxsts.equals(res.STS)) {
                    AcquireFaultTrx faultTrx = new AcquireFaultTrx();
                    faultTrx.acquireCode = trx.acquirerCode
                    faultTrx.trxid = trx.id
                    faultTrx.trxdate = trx.submitdates.substring(0, 8)
                    faultTrx.iniSts = trx.trxsts as int
                    faultTrx.createDate = new Date()
                    faultTrx.updateDate = new Date();
                    faultTrx.authDate = new Date()
                    faultTrx.authOper = "SYN"
                    faultTrx.authSts = "U"
                    faultTrx.changeApplier = "SYN"
                    faultTrx.changeSts = 1
                    faultTrx.finalSts = "SUCCESS"
                    faultTrx.acquireMerchant = trx.acquirerMerchant
                    faultTrx.acquireTrxnum = trx.trxnum
                    faultTrx.trxamount = trx.amount
                    if (!res.TRXAMOUNT && !res.TRXAMOUNT.equals(trx.amount)) {
                        log.debug([response: "0", resmsg: "交易" + IsmsConfig.TrxstsDesc.get(res.STS) + ",金额差异,未处理"] as JSON);
                        syn.syntimes+=1
                        if(syn.syntimes>=3){
                            syn.synsts="F"
                        }
                        syn.synresult="AMOUNT_NOT_EQUAL"
                        syn.save(flush:true)
                        continue;
                    }
                    if (faultTrx.save(flush: true,failOnError:true)) {
                        log.info("handle faulttrx id111:" + faultTrx.id)
                        def flg = httpInvokeClientService.tx_next(faultTrx.id)
                        log.info "falut return:"+flg
                        log.debug([response: "0", resmsg: "交易" + IsmsConfig.TrxstsDesc.get(res.STS) + ",差错处理" + flg ? "成功" : "失败", trxsts: res.STS, proc: "同步银行返回"] as JSON);
                         syn.synsts="Y"
                        syn.synresult="SUCCESS"
                        syn.save(flush: true);
                    } else {
                        faultTrx.errors.each {
                            log.info it
                        }
                        log.debug([response: -1, resmg: "交易" + IsmsConfig.TrxstsDesc.get(res.STS) + ",产生差错交易失败", proc: "同步银行返回"] as JSON);
                    }
                } else {
                    log.debug([response: 0, resmsg: "交易" + IsmsConfig.TrxstsDesc.get(res.STS)] as JSON)
                    log.info("trx.trxnum:"+trx.trxnum+" status:"+IsmsConfig.TrxstsDesc.get(res.STS))
                     syn.syntimes+=1
                    syn.synsts="N"
                    syn.synresult="QUERY_STS_FAILURE"
                    syn.save(flush: true);
                }
            }else {
                syn.syntimes+=1
                syn.synsts='N'
                syn.synresult="QUERY_FAILURE"
                syn.save(flush: true);
            }
        }
    }
}
