package ismsapp

import org.apache.poi.hssf.usermodel.HSSFRow
import org.apache.poi.hssf.usermodel.HSSFCell
import org.apache.poi.hssf.usermodel.HSSFDateUtil
import org.apache.poi.hssf.usermodel.HSSFWorkbook

/**
 * Created by IntelliJ IDEA.
 * User: guonan
 * Date: 12-2-9
 * Time: 下午8:01
 * To change this template use File | Settings | File Templates.
 */
class Excel2003Builder {

	    def workbook
	    def labels
	    def row

	    Excel2003Builder(InputStream is) {
	        HSSFRow.metaClass.getAt = {int idx ->
	            def cell = delegate.getCell(idx)
	            if(! cell) {
	                return null
	            }
	            def value
	            switch(cell.cellType) {
	                case HSSFCell.CELL_TYPE_NUMERIC:
	                if(HSSFDateUtil.isCellDateFormatted(cell)) {
	                    value = cell.dateCellValue
	                } else {
	                    value = cell.numericCellValue
	                }
	                break
	                case HSSFCell.CELL_TYPE_BOOLEAN:
	                value = cell.booleanCellValue
	                break
	                default:
	                value = cell.stringCellValue
	                break
	            }
	            return value
	        }
             workbook = new HSSFWorkbook(is)
	    }

	    def getSheet(idx) {
	        def sheet
	        if(! idx) idx = 0
	        if(idx instanceof Number) {
	            sheet = workbook.getSheetAt(idx)
	        } else if(idx ==~ /^\d+$/) {
	            sheet = workbook.getSheetAt(Integer.valueOf(idx))
	        } else {
	            sheet = workbook.getSheet(idx)
	        }
	        return sheet
	    }

	    def cell(idx) {
	        if(labels && (idx instanceof String)) {
	            idx = labels.indexOf(idx.toLowerCase())
	        }
	        return row[idx]
	    }

	    def propertyMissing(String name) {
	        cell(name)
	    }

    def eachLine = {Map params = [:], Closure closure ->
        def offset = params.offset ?: 0
        def max = params.max ?: 9999999
        def sheet = getSheet(params.sheet)
        def rowIterator = sheet.rowIterator()
        def linesRead = 0

        if (params.labels) {
            labels = rowIterator.next().collect {it.toString().toLowerCase()}
        }
        offset.times { rowIterator.next() }

        closure.setDelegate(this)

        while (rowIterator.hasNext() && linesRead++ < max) {
            row = rowIterator.next()
            closure.call(row)
        }
    }


     static void main(args) {
         new Excel2003Builder(new FileInputStream(new File("d:/1015-连连.xls"))).eachLine {
             println "First column on row ${it.rowNum} = ${cell(4)}"

         }
     }
	}
