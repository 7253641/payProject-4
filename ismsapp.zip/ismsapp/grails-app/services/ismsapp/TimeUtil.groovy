package ismsapp
import java.util.Calendar
import java.text.SimpleDateFormat;

/**
 * Created by IntelliJ IDEA.
 * User: xie
 * Date: 13-7-23
 * Time: 下午4:24
 * To change this template use File | Settings | File Templates.
 */
class TimeUtil {
    /**
     * <p>获取当前时间</p>
     * 此方法获取的当前时间精确到微妙，长度为17位
     * @return String
     * 返回值为字符串形式的9位精确到微妙的当前时间
     */
    public static String getTimeNow1()
    {
         Calendar Cld = Calendar.getInstance();
         String HH = String.valueOf(Cld.get(Calendar.HOUR_OF_DAY));
         String mm = String.valueOf(Cld.get(Calendar.MINUTE));
         String SS = String.valueOf(Cld.get(Calendar.SECOND));
         String MI = String.valueOf(Cld.get(Calendar.MILLISECOND));
         if(HH.length()==1)
         {
             HH="0"+HH;
         }
         if(mm.length()==1)
         {
             mm="0"+mm;
         }
         if(SS.length()==1)
         {
             SS="0"+SS;
         }
         if(MI.length()==1)
         {
             MI="00"+MI;
         }
         if(MI.length()==2)
         {
             MI="0"+MI;
         }
         String currentTime=HH+mm+SS+MI;
         return currentTime;
    }
    /**
     * <p>获取当前时间</p>
     * 此方法获取的当前时间精确到微妙，长度为17位
     * @return String
     * 返回值为字符串形式的6位精确到妙的当前时间
     */
    public static String getTimeNow2()
    {
         Calendar Cld = Calendar.getInstance();
         String HH = String.valueOf(Cld.get(Calendar.HOUR_OF_DAY));
         String mm = String.valueOf(Cld.get(Calendar.MINUTE));
         String SS = String.valueOf(Cld.get(Calendar.SECOND));
         if(HH.length()==1)
         {
             HH="0"+HH;
         }
         if(mm.length()==1)
         {
             mm="0"+mm;
         }
         if(SS.length()==1)
         {
             SS="0"+SS;
         }

         String currentTime=HH+mm+SS;
         return currentTime;
    }


     public static String getStringDateShort() {
         Date currentTime =  new Date();
         SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
         String dateString = formatter.format(currentTime);
         return dateString;
     }

}
