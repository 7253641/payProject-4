package ismsapp
import java.text.SimpleDateFormat
import groovyx.net.http.HTTPBuilder

import static groovyx.net.http.Method.GET
import static groovyx.net.http.ContentType.TEXT
import grails.converters.JSON
import groovy.sql.Sql

import grails.converters.XML
import org.codehaus.groovy.grails.commons.ConfigurationHolder
import org.hibernate.Session
import org.hibernate.transform.AliasToEntityMapResultTransformer
import org.springframework.orm.hibernate3.HibernateCallback
import org.springframework.orm.hibernate3.HibernateTemplate
import com.burtbeckwith.grails.plugin.datasources.DatasourcesUtils
class AccountSynTrxService {

 static transactional = true

 def importAcquireSynTrx(trxlist,params,now,batchnum){
        trxlist.each{x->
            def syntrx = new AcquireSynTrx();
            syntrx.bankCode = params.bankCode

              if(params.bankAccountNo instanceof String[]){
                    syntrx.bankAccountNo=params.bankAccountNo.join(',')
              }else{
                    syntrx.bankAccountNo=params.bankAccountNo
              }
              if(params.acquireMerchant instanceof String[]){
                    syntrx.acquireMerchant=params.acquireMerchant.join(',')
              }else{
                    syntrx.acquireMerchant=params.acquireMerchant
              }
            syntrx.acquireCode
            if(params.serviceCodes instanceof String[]){
                syntrx.serviceCode=params.serviceCodes.join(',')
            }else{
                syntrx.serviceCode=params.serviceCodes
            }
            syntrx.trxid=x['trxid']
            syntrx.amount=(x['amount'] as BigDecimal)*100
            syntrx.acquireDate=x['acquireDate']
            syntrx.accountDate=x['accountDate']
            syntrx.tradeDate
            syntrx.synDateFrom= Date.parse('yyyy-MM-dd HH:mm:ss', params.beginTime)
            syntrx.synDateTo= Date.parse('yyyy-MM-dd HH:mm:ss', params.endTime)
            syntrx.batchnum=batchnum
            syntrx.trxsts=x['trxsts']  as int
            syntrx.synSts=4
            syntrx.createDate=now
            syntrx.fee=x['fee']

            if(syntrx.save(flush:true)){
               log.info "save batchnum:"+syntrx.batchnum+" trxid:"+syntrx.trxid
            }else{
               syntrx.errors.each {
                    log.error it
               }
            }
        }
    }

    def synTest(params,batchnum,now){
        //查长账（我方系统比银行多）
        def query="""
                 select
                     count(*)
                 from gwtrxs g
                 where
                        g.servicecode in (${joinInlist(params.serviceCodes)})
              """
        HibernateTemplate ht = DatasourcesUtils.newHibernateTemplate('ismp')
        def results = ht.executeFind({ Session session ->
            def sqlQuery = session.createSQLQuery(query.toString())
            sqlQuery.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE)
            return sqlQuery.list();
        } as HibernateCallback)

        println   results
    }


     def synShot(params,batchnum,now){
        //查短账（我方系统比银行多）
        def query="""
                 select s.trxid
                     ,g.trxnum
                     ,g.acquirer_merchant
                     ,g.createdate
                     ,g.acquirer_code
                     ,g.payer_ip
                     ,g.servicecode
                     ,g.gworders_id
                     ,g.trxsts as gtrxsts
                     ,s.trxsts as strxsts
                     ,g.amount as gamount
                     ,s.amount as samount
                     ,round(g.fee,2) as fee
                    ,s.fee as bank_fee
                 from acquire_syn_trx s right join (select a.*,
       case
         when c.fee_type = '1' then
          a.amount * (fee_rate / 10000.0)
         else
          fee_rate
       end as fee
  from gwtrxs a, boss.bo_merchant b, boss.bo_Channel_Rate c
 where a.acquirer_merchant = b.acquire_merchant
   and b.id = c.merchant_id
   and upper(b.acquire_indexc) = upper('${params.bankCode}')) g
                 on
                        s.trxid=g.trxnum
                   and  s.batchnum='${batchnum}'
                   and  s.syn_sts='4'
                 where
                        g.servicecode in (${joinInlist(params.serviceCodes)})
                    and g.trxsts='1'
                    and g.createdate>=to_date('${params.beginTime}','yyyy-mm-dd hh24:mi:ss')
                    and g.createdate<=to_date('${params.endTime}','yyyy-mm-dd hh24:mi:ss')
              """

          println    query

        HibernateTemplate ht = DatasourcesUtils.newHibernateTemplate('ismp')
        def results = ht.executeFind({ Session session ->
            def sqlQuery = session.createSQLQuery(query.toString())
            sqlQuery.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE)
            return sqlQuery.list();
        } as HibernateCallback)
         println    results
        if(results.size()>0){
            results.each {
                AcquireSynTrx syntrx
                //短账，没有此订单交易
                if(!it.TRXID){
                    syntrx = new AcquireSynTrx();
                    syntrx.payerIp=it.PAYER_IP
                    syntrx.bankCode= params.bankCode
                    syntrx.acquireMerchant=it.ACQUIRER_MERCHANT
                    syntrx.acquireCode= it.ACQUIRER_CODE
                    syntrx.serviceCode=it.SERVICECODE
                    syntrx.trxid=it.TRXNUM
                    syntrx.tradeAmount=it.GAMOUNT as Double
                    syntrx.tradeFee=it.FEE as Double
                    syntrx.tradeDate=it.CREATEDATE
                    syntrx.synDateFrom= Date.parse('yyyy-MM-dd HH:mm:ss', params.beginTime)
                    syntrx.synDateTo= Date.parse('yyyy-MM-dd HH:mm:ss', params.endTime)
                    syntrx.batchnum=batchnum
                    syntrx.tradeTrxsts=it.GTRXSTS  as Integer
                    syntrx.synSts=2
                    syntrx.createDate=now
                    syntrx.tradeNum= it.GWORDERS_ID
                }else{

                    syntrx = AcquireSynTrx.findByTrxidAndBatchnum(it.TRXID,batchnum)
                    syntrx.payerIp=it.PAYER_IP
                    syntrx.acquireCode=it.ACQUIRER_CODE
                    syntrx.acquireMerchant=it.ACQUIRER_MERCHANT
                    syntrx.serviceCode=it.SERVICECODE
                    syntrx.tradeNum=it.GWORDERS_ID
                    syntrx.tradeAmount=it.GAMOUNT
                    syntrx.tradeFee=it.FEE
                    syntrx.tradeTrxsts=it.GTRXSTS  as Integer
                    syntrx.tradeDate=it.CREATEDATE
                    //状态一致  我方网关成功，银行成功。网关状态为字符串表示，银行为数字
                    if(it.GTRXSTS=='1'&&it.STRXSTS==1){
                         //成功
                        if(it.GAMOUNT==it.SAMOUNT&&it.BANK_FEE==it.FEE){
                             syntrx.synSts=0
                         }
                        //差异
                        else if(it.GAMOUNT!=it.SAMOUNT){
                             syntrx.synSts=3
                         }

                         else {
                             syntrx.synSts=4
                         }


                    }
                    //短账，状态不一致  我方网关成功，银行不成功。我方网关状态为字符串表示，银行为数字
                    if(it.GTRXSTS=='1'&&it.STRXSTS!=1){
                        syntrx.synSts=2
                    }
                }
                syntrx.save(flush:true,failOnError:true)
            }
        }
    }


    def synOver(params,batchnum,now){
        //查长账及成功（我方系统比银行少）
         def query="""
                 select s.trxid
                    ,g.trxnum
                    ,g.payer_ip
                    ,g.acquirer_merchant
                    ,g.acquirer_code
                    ,g.gworders_id
                    ,g.servicecode
                    ,g.createdate
                    ,g.trxsts as gtrxsts
                    ,s.trxsts as strxsts
                    ,g.amount as gamount
                    ,s.amount as samount
                     ,round(g.fee,2) as fee
                    ,s.fee as bank_fee
                 from acquire_syn_trx s left join (select a.*,
       case
         when c.fee_type = '1' then
          a.amount * (fee_rate / 10000.0)
         else
          fee_rate
       end as fee
  from gwtrxs a, boss.bo_merchant b, boss.bo_Channel_Rate c
 where a.acquirer_merchant = b.acquire_merchant
   and b.id = c.merchant_id
   and upper(b.acquire_indexc) = upper('${params.bankCode}')) g
                 on
                        s.trxid=g.trxnum
                    and g.servicecode in (${joinInlist(params.serviceCodes)})
                    and g.createdate>=to_date('${params.beginTime}','yyyy-mm-dd hh24:mi:ss')
                    and g.createdate<=to_date('${params.endTime}','yyyy-mm-dd hh24:mi:ss')
                 where
                    s.batchnum='${batchnum}'
                    and s.trxsts=1
                    and s.syn_sts='4'
              """

        println    query
        HibernateTemplate ht = DatasourcesUtils.newHibernateTemplate('ismp')
        def results = ht.executeFind({ Session session ->
            def sqlQuery = session.createSQLQuery(query.toString())
            sqlQuery.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE)
            return sqlQuery.list();
        } as HibernateCallback)

         println    results
        if(results.size()>0){
            results.each {
                def syntrx = AcquireSynTrx.findByTrxidAndBatchnum(it.TRXID,batchnum)
                //长账，没有此订单交易
                if(!it.TRXNUM){
                   syntrx.synSts=1
                }else{
                   syntrx.payerIp=it.PAYER_IP
                   syntrx.acquireCode=it.ACQUIRER_CODE
                   syntrx.acquireMerchant=it.ACQUIRER_MERCHANT
                   syntrx.serviceCode=it.SERVICECODE
                   syntrx.tradeNum=it.GWORDERS_ID
                   syntrx.tradeAmount=it.GAMOUNT
                    syntrx.tradeFee=it.FEE
                   syntrx.tradeTrxsts=it.GTRXSTS   as Integer
                   syntrx.tradeDate=it.CREATEDATE
                   //状态一致  我方网关成功，银行成功。网关状态为字符串表示，银行为数字

                    if(it.GAMOUNT==it.SAMOUNT&&it.BANK_FEE==it.FEE){
                             syntrx.synSts=0
                         }
                        //差异
                        else if(it.GAMOUNT!=it.SAMOUNT){
                             syntrx.synSts=3
                         }

                         else{
                             syntrx.synSts=4
                         }


                    //长账，状态不一致，银行成功，我方网关不成功  ,网关状态为字符串表示，银行为数字
                    if(it.STRXSTS==1&&it.GTRXSTS!='1'){
                        syntrx.synSts=1
                    }
                }
                syntrx.save(flush:true,failOnError:true)
            }
        }
    }


    //对账结果
     def importAcquireSynResult(params,batchnum,now){
        def query="""
                 select syn_sts,sum(s.amount) sam
                 ,sum(s.trade_amount) stam
                 ,sum(s.trade_fee) tradeFee
                 ,sum(s.fee) fee
                 ,count(*) cou
                 from acquire_syn_trx s
                 where
                        s.batchnum='${batchnum}'
                 group by
                    syn_sts
              """
        HibernateTemplate ht = DatasourcesUtils.newHibernateTemplate('ismp')
        def results = ht.executeFind({ Session session ->
            def sqlQuery = session.createSQLQuery(query.toString())
            sqlQuery.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE)
            return sqlQuery.list();
        } as HibernateCallback)

        def acquireSynTrxs=AcquireSynTrx.findAllByBatchnum(batchnum);
        def syntrx = new AcquireSynResult();
        syntrx.bankCode = acquireSynTrxs[0].bankCode
        syntrx.bankAccountNo=acquireSynTrxs[0].bankAccountNo
        syntrx.acquireMerchant=acquireSynTrxs[0].acquireMerchant
        syntrx.acquireCode=acquireSynTrxs[0].acquireCode
        syntrx.serviceCode=acquireSynTrxs[0].serviceCode
        syntrx.synDateFrom= acquireSynTrxs[0].synDateFrom
        syntrx.synDateTo= acquireSynTrxs[0].synDateTo
        syntrx.batchnum=batchnum
        syntrx.createDate=now
        syntrx.synOp= params.oper
        if(results.size()>0){
            results.each {
              switch (it.SYN_STS) {
                case '0':
                syntrx.successAmount=it.SAM
                syntrx.successNum=it.COU
                break
                case '1':
                syntrx.overAmount=it.SAM
                syntrx.overNum=it.COU
                break
                case '2':
                syntrx.shortAmount=it.STAM
                syntrx.shortNum=it.COU
                break
                case '3':
                syntrx.disAmount=it.SAM
                syntrx.disNum=it.COU
                break
                case '4':
                syntrx.otherAmount=it.TRADEFEE*100
                syntrx.otherNum=it.COU
                break
              }
            }
        }
         syntrx.save(flush:true,failOnError:true)
     }

    def joinInlist(serviceCodes){
        StringBuilder ids= new StringBuilder()
        if(serviceCodes instanceof String[]){
            int len = serviceCodes.size();
            for(int i=0 ;i<len;i++){
                if(i>0&&i<len){
                 ids.append(",")
                }
               ids.append("'").append(serviceCodes[i]).append("'")
            }
        }else{
             ids.append("'").append(serviceCodes).append("'")
        }

        return ids
    }
}
