package ismsapp.refund

import refund.TradeBase
import java.text.SimpleDateFormat
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.KeyStore;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils
import ismsapp.Gwtrxs
import net.sf.json.JSONObject;
import java.util.Random;
import ismsapp.IsmsConfig
//import javax.net.ssl.SSLSocketFactory


class FxppaycardService {
    def keypath=org.codehaus.groovy.grails.commons.ConfigurationHolder.config.Resource.Path
    def urlStr = org.codehaus.groovy.grails.commons.ConfigurationHolder.config.fxppaycard.Path

    static transactional = true

    def fxppayRefund = {def tradeRefundInstance ->
        //构造相应的form表单，提给预付费卡系统。进行退款
        
        String result = "-20";
        StringBuilder sb = new StringBuilder();
        sb = this.getPerMap(urlStr, tradeRefundInstance)
         String retStr = "";
        DefaultHttpClient httpclient = new DefaultHttpClient();
	    try {
	        KeyStore trustStore  = KeyStore.getInstance(KeyStore.getDefaultType());
	        FileInputStream instream = new FileInputStream(new File(keypath+"/fxppaycard/yskey.keystore"));
	        try {
	             trustStore.load(instream, "111111".toCharArray());
	         } finally {
	             try { instream.close(); } catch (Exception ignore) {}
	         }
	         SSLSocketFactory socketFactory = new SSLSocketFactory(trustStore);
	         Scheme sch = new Scheme("https", 443, socketFactory);
	         httpclient.getConnectionManager().getSchemeRegistry().register(sch);
	         HttpGet httpget = new HttpGet(sb.toString());
	         System.out.println("executing request" + httpget.getRequestLine());

	         HttpResponse response = httpclient.execute(httpget);
	         HttpEntity entity = response.getEntity();
	         System.out.println("----------------------------------------");
	         System.out.println(response.getStatusLine());
	        
	         if (entity != null) {
	            InputStream instream2 = entity.getContent();
	             try {

	                BufferedReader reader = new BufferedReader(
	                new InputStreamReader(instream2));
	                retStr = reader.readLine();
	               } catch (IOException ex) {
	                    throw ex;

	              } catch (RuntimeException ex) {
	                    throw ex;

	              } finally {
	                 instream2.close();

	              }
	            }
	            System.out.println("退货通知商户返回信息："+retStr)
	            EntityUtils.consume(entity)


	        } finally {
	            httpclient.getConnectionManager().shutdown()
	      }
              //处理返回的参数
              String[] str = retStr.split(",")
              StringBuilder strBuilder = new StringBuilder();
              for(int i=0;i<str.length;i++){
                  String[] aa = str[i].split("=")
                  if(aa.length>1){
                    strBuilder.append(str[i]+",")
                  }
                  
              }
              String jsonstr = strBuilder.toString()
              println jsonstr
              if(jsonstr==null||"".equals(jsonstr)){
                  result ="cdcbbbf5caa7b0dca3acc7ebd6d8d0c2c9fab3c9cdcbbbf5c9eac7eb"
              }else{
                  def serviceParams = JSONObject.fromObject(jsonstr as String)
                  def rescode = serviceParams.rspcode
                  if(rescode.toString().length()<2){rescode = "0"+rescode}
                  println  rescode.toString()
                  if("00".equals(rescode.toString())||"01".equals(rescode.toString())){
                      result = "00"
                  }else{
                      result =serviceParams.addMsg
                  }
              }
              
    }

    def getPerMap(def url,def tradeRefundInstance){

            def oldTradeInstance = TradeBase.get(tradeRefundInstance.rootId)
            String moneystr = String.valueOf(tradeRefundInstance.realityRefundAmount);
            def gwtrxs = Gwtrxs.findByTrxnum(oldTradeInstance.outTradeNo);

            Random rd=new Random();
            String str="";
            for(int i=0;i<3;i++) str+=rd.nextInt(10);

             Calendar cal = Calendar.getInstance();
             cal.setTime(tradeRefundInstance.dateCreated);
             cal.add(Calendar.SECOND, 5);
            
            StringBuilder sb = new StringBuilder();
            sb.append(url+"?");
            sb.append("tradeType=").append("503");
            sb.append("&merchantId=").append(tradeRefundInstance.acquirerMerchantNo);
            sb.append("&merchantName=").append("bhecard");
            sb.append("&tradeTime=").append(this.format(cal.getTime(),"yyyyMMddHHmmss"));
            sb.append("&orderId=").append(tradeRefundInstance.outTradeNo+str);
            sb.append("&amount=").append(moneystr);
            sb.append("&oldOrderId=").append(oldTradeInstance.outTradeNo);//原订单号
            sb.append("&ysOldTradeId=").append(gwtrxs.acquirerSeq);//原支付系统交易唯一号
            def ifno="503~|~"+tradeRefundInstance.acquirerMerchantNo+"~|~bhecard~|~"+this.format(cal.getTime(),"yyyyMMddHHmmss")+"~|~"+tradeRefundInstance.outTradeNo+str+"~|~"+moneystr+"~|~"+oldTradeInstance.outTradeNo+"~|~"+gwtrxs.acquirerSeq;
            def merprivatekey = keypath+"/fxppaycard/"
            println ifno;
            def signature = com.hnapay.payment.client.key.DSAService.sign(merprivatekey,ifno);
            sb.append("&signature=").append(signature);
        return sb
   }

//    def getPerMap(def url,def tradeRefundInstance){
//
//            StringBuilder sb = new StringBuilder();
//            sb.append(url+"?");
//            sb.append("tradeType=").append("503");
//            sb.append("&merchantId=").append("000000000000034");
//            sb.append("&merchantName=").append("bhecard");
//            sb.append("&tradeTime=").append("20111212154412");
//            sb.append("&orderId=").append("131112130005736");
//            sb.append("&amount=").append("156");
//            sb.append("&oldOrderId=").append("711121200205880942");//原订单号
//            sb.append("&ysOldTradeId=").append("100000005909");//原支付系统交易唯一号
//            def ifno="503~|~000000000000034~|~bhecard~|~20111212154412~|~131112130005736~|~156~|~711121200205880942~|~100000005909";
//            def merprivatekey = keypath+"/fxppaycard/"
//            println ifno;
//            def signature = com.hnapay.payment.client.key.DSAService.sign(merprivatekey,ifno);
//            sb.append("&signature=").append(signature);
//        return sb
//   }


   def  format(def date,def pattn){
     return new SimpleDateFormat(pattn).format(date)
    }



     def query(trxnum,orderdate) {
        //构造相应的form表单，提给预付费卡系统。进行退款
        def resultMap=[]
        def urlStr = "https://58.246.226.171:13443/netpay/query.htm"
        String result = "-20";
        StringBuilder sb = new StringBuilder();
//        sb = this.getSelectPerMap(urlStr,trxnum,orderdate,tradeRefundInstance)
        sb = this.getSelectPerMap(urlStr,trxnum,orderdate)
        DefaultHttpClient httpclient = new DefaultHttpClient();
	    try {
	        KeyStore trustStore  = KeyStore.getInstance(KeyStore.getDefaultType());
	        FileInputStream instream = new FileInputStream(new File(keypath+"/fxppaycard/yskey.keystore"));
	        try {
	             trustStore.load(instream, "111111".toCharArray());
	         } finally {
	             try { instream.close(); } catch (Exception ignore) {}
	         }
	         SSLSocketFactory socketFactory = new SSLSocketFactory(trustStore);
	         Scheme sch = new Scheme("https", 443, socketFactory);
	         httpclient.getConnectionManager().getSchemeRegistry().register(sch);
	         HttpGet httpget = new HttpGet(sb.toString());
	         System.out.println("executing request" + httpget.getRequestLine());

	         HttpResponse response = httpclient.execute(httpget);
	         HttpEntity entity = response.getEntity();
	         System.out.println("----------------------------------------");
	         System.out.println(response.getStatusLine());
	         String retStr = "";
	         if (entity != null) {
	            InputStream instream2 = entity.getContent();
	             try {

	                BufferedReader reader = new BufferedReader(
	                new InputStreamReader(instream2));
	                retStr = reader.readLine();
	               } catch (IOException ex) {
	                    throw ex;

	              } catch (RuntimeException ex) {
	                    throw ex;

	              } finally {
	                 instream2.close();

	              }
	            }else{
                        resultMap=[RESCODE:"200-01",RESMSG:"not found"]
                    }
	            System.out.println("自动对账返回信息："+retStr);
	            EntityUtils.consume(entity);
                     //处理返回的参数
                   String[] str = retStr.split(",")
                   StringBuilder strBuilder = new StringBuilder();
                   for(int i=0;i<str.length;i++){
                       String[] aa = str[i].split("=")
                       if(aa.length>1){
                           if(aa[0].trim()!="ysTime"){
                               strBuilder.append(str[i]+",")
                           }
                       }
 
                   }
                  String jsonstr = strBuilder.toString()
                   def sts
                    def serviceParams = JSONObject.fromObject(jsonstr as String)
                    result = serviceParams.respCode
                    def amount
                    if("0"+result!="00"){
                        sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNPAID)
                    }else{
                        sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                         amount = serviceParams.amount
                    }

                 resultMap=[RESCODE:"200-00",BANKCODE: 'FXPPAYCARD',STS:sts,TRXAMOUNT:amount,TRXNUM:serviceParams.orderId]
	        } finally {
	            httpclient.getConnectionManager().shutdown();
	        }
         return resultMap

    }


     def getSelectPerMap(def url,def trxnum,def orderdate){

//             def oldTradeInstance = TradeBase.get(tradeRefundInstance.rootId)

            def gwtrxs = Gwtrxs.findByTrxnum(trxnum);
            StringBuilder sb = new StringBuilder();
            sb.append(url+"?");
            sb.append("tradeType=").append("502");
            sb.append("&orderId=").append(trxnum);
            sb.append("&tradeTime=").append(orderdate);
            sb.append("&merchantId=").append(gwtrxs.acquirerMerchant);

            def ifno="502~|~"+trxnum+"~|~"+orderdate+"~|~"+gwtrxs.acquirerMerchant;
            def merprivatekey = keypath+"/fxppaycard/"
            println ifno;
            def signature = com.hnapay.payment.client.key.DSAService.sign(merprivatekey,ifno);
            sb.append("&signature=").append(signature);
        return sb
   }

}

