package ismsapp.banks

import groovyx.net.http.HTTPBuilder
import com.csii.payment.client.core.CebMerchantSignVerify
import static groovyx.net.http.Method.GET
import static groovyx.net.http.ContentType.TEXT
import ismsapp.IsmsConfig

class CebService {

   static transactional = true
//    def http = new HTTPBuilder("https://www.cebbank.com/per/QueryMerchantEpay.do");
    def http = new HTTPBuilder("http://219.143.234.251/per/QueryMerchantEpay.do");
    def keypath=org.codehaus.groovy.grails.commons.ConfigurationHolder.config.Resource.Path
    def merchantCode ="370310000004"

    def query(trxnum,orderdate,amount) {
        String merURL ="1";
        def resultMap = [];
        String plain = "transId=IQSR~|~merchantId="+merchantCode+"~|~originalorderId="+trxnum+"~|~originalTransDateTime="+orderdate+"~|~originalTransAmt="+amount+"~|~merURL="+merURL;
        String sign=CebMerchantSignVerify.merchantSignData_ABA(plain);
        http.request(GET, TEXT) {req ->
            uri.query = [TransName: "IQSR", Plain: plain, Signature: sign]

            response.success = { resp, reader ->

                req.getParams().setParameter("http.connection.timeout", 15000)
                req.getParams().setParameter("http.socket.timeout", 15000)
                def res = reader.text;
                log.info "from ceb  bank:"+res
                if(res!=null&&!"".equals(res)){
                    def  result=res.split("\r");
                    def  responseRec=result[0].split("=");
                    if("0000".equals(responseRec[1])){
                        def  signs=result[2].split("=");
                        def plainStr= result[1].toString().substring(7);
                          log.info "plainStr:"+plainStr;
                        Boolean checkRes =CebMerchantSignVerify.merchantVerifyPayGate_ABA(signs[1],plainStr);
                          log.info "return ceb bank signVerify is :"+checkRes;
                        if(checkRes){
                           def  plainSet=plainStr.split("~|~")
                           def sts=''
                           def status=""
                           def amountAMT=""
                           def transDateTime=""
                           def transSeqNo=""
                           for(int i=0;i<plainSet.length;i++){
                               def aa =plainSet[i].split("=");
                               if(aa.size()>0){
                                  if("transStatus".equals(aa[0])){
                                    status = aa[1];
                                  }else if("transAmt".equals(aa[0])){
                                     amountAMT = aa[1];
                                  }else if("transDateTime".equals(aa[0])){
                                      transDateTime = aa[1];
                                  }else if("orderId".equals(aa[0])){
                                      transSeqNo = aa[1];
                                  }
                               }
                           }
                           switch(status){
                                case "00":
                                    sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                    break;
                                default:
                                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.NOTFOUND)
                                    break;
                            }
                            log.info "from ceb  bankSTS "+sts
                            resultMap=[RESCODE:"200-00",BANKCODE: 'CEB', MERCHANT: merchantCode, TRXNUM:transSeqNo , TRXAMOUNT:(amountAMT as BigDecimal)*100 as long, TRXDATE: transDateTime, STS: sts]
                        }else{
                              resultMap=[RESCODE:"200-01",RESMSG:"sing verify is  fail !"]
                              return
                        }
                     }else {
                            resultMap=[RESCODE:"200-01",RESMSG:"ceb responseCode:FFFF"]
                            return
                    }
                 }else{
                          resultMap=[RESCODE:"200-01",RESMSG:"not found"]
                          return
                 }

            }
        }
        return resultMap;
    }
}
