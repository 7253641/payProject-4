package ismsapp.banks


import groovyx.net.http.HTTPBuilder
import static groovyx.net.http.ContentType.TEXT
import static groovyx.net.http.Method.GET
import Union.JnkyServer
import ismsapp.IOUtils
import ismsapp.IsmsConfig
import ismsapp.TimeUtil


class CmbcService {

    static transactional = true
    def  http = new HTTPBuilder("https://pay.cmbc.com.cn/epay/connectForQuery.do");
    def  keypath=org.codehaus.groovy.grails.commons.ConfigurationHolder.config.Resource.Path
    def  merchantCode ="21004"
    def  fileKey = keypath +"/cmbc/cmbc.pfx";
    def  fileCert = keypath +"/cmbc/cmbc.cer";
    def  keyPassword = "12345678";

    def query(trxnum) {

        def resultMap = [];
        def plain = merchantCode+"|"+trxnum;
          log.info " plain:"+plain
        def envolopData="";
        try{
            JnkyServer my = new JnkyServer(IOUtils.readFile(this.fileCert).toByteArray(),
					IOUtils.readFile(this.fileKey).toByteArray(),this.keyPassword);
			envolopData = my.EnvelopData(plain);//""中为待加密的数据
            my=null;
        }catch(Exception e){
			e.printStackTrace();
        }

        http.request(GET, TEXT) {req ->
            uri.query = [cryptograph:URLEncoder.encode(envolopData, "gbk")]

            response.success = { resp, reader ->

            req.getParams().setParameter("http.connection.timeout", 15000)
            req.getParams().setParameter("http.socket.timeout", 15000)
            def res = reader.text;
            if(res!=null&&!"".equals(res)){

                    int first =  res.indexOf("<div>");
                    int firstIndex = first+5;
                    int last = res.indexOf("</div>");
                    int lastIndex = last-1;
                    def result = res.substring(firstIndex,lastIndex);
                    if("验签失败".equals(result)){return }
                    def plainText="";
                    try{
                         JnkyServer my1 = new JnkyServer(IOUtils.readFile(this.fileKey).toByteArray(),this.keyPassword);
                         plainText = my1.DecryptData(URLDecoder.decode(result,"gbk"));
                         my1= null;
                    }catch(Exception e){
			             e.printStackTrace();
                    }
                       log.info "from cmbc  plainText "+plainText;
                    def  resultText =plainText.split("\\|");
                    def sts = "";
                    switch (resultText[2]) {
                                case "1":   //success
                                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                    break;
                                default:
                                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.NOTFOUND)
                                    break;
                    }
                    log.info "from cmbc  bankSTS "+sts
                    resultMap=[RESCODE:"200-00",BANKCODE: 'Cmbc', MERCHANT: merchantCode, TRXNUM:resultText[0] , TRXAMOUNT: resultText[1] , TRXDATE: TimeUtil.getStringDateShort(), STS: sts]
                }else{
                     resultMap=[RESCODE:"200-01",RESMSG:"not found"]
                     return
            }
            }

        }
        return resultMap;
    }
}
