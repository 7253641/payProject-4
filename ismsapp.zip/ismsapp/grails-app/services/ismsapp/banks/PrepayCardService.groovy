package ismsapp.banks

class PrepayCardService {

    static transactional = true

    private final String merchantId = "888888888810001"
    private final String serviceCode = "t0_query"


    def query(merId, orderId, orderDate, signTime)
    {

    }

    def serviceMethod() {

    }
}
