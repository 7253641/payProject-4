package ismsapp.banks

import ismsapp.IsmsConfig
import groovyx.net.http.HTTPBuilder
import static groovyx.net.http.Method.GET
import static groovyx.net.http.ContentType.TEXT
import ismsapp.NetpaySignature

class SdbService {

    static transactional = true

   def http = new HTTPBuilder("https://netpay.pingan.com.cn/peps/getPayInfo.do");
   def keypath=org.codehaus.groovy.grails.commons.ConfigurationHolder.config.Resource.Path
   private String mechantNo = "1000158505";                        //商户ID
   def fileKeyPath =keypath+"/sdb_b2c/pinganmer.jks";

    def query(orderNo) {
        def resultMap=[]
         http.request(GET, TEXT) {req ->

            req.getParams().setParameter("http.connection.timeout", 15000)
            req.getParams().setParameter("http.socket.timeout", 15000)
            uri.query = [MechantNo: mechantNo,orderNo:orderNo,Signature:getSignData(orderNo)]
            response.success = { resp, reader ->
                def res = reader.text;
                println"reutn sdb:"+ res
                 if(res!=null){
                    if(!res.indexOf("error")==0){
                         def sts = "";
                         String returnStr = res.split("\\|")[1]
                         println "---------------:"+ returnStr
                          String orderNum =  returnStr.substring(20,50).trim() ;
                          String amount =  returnStr.substring(50,70).trim();
                          String status = returnStr.substring(70,71).trim();
                          String date = returnStr.substring(88,98).trim();
                          String cardType =  returnStr.substring(98,99).trim();
                          println "========:"+ orderNum+"&&"+amount+"&&"+status+"&&"+date+"&&"+cardType
                          switch(status){
                            case "1":
                                sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                break;
                            default:
                                sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.FAILURE)
                                break;
                           }
                        resultMap=[RESCODE:"200-00",BANKCODE: 'PSBC', TRXNUM:orderNum, TRXAMOUNT:(amount as BigDecimal)*100 as long, TRXDATE: date, STS: sts]
                    }else{
                        log.info("SDB error")
                       resultMap=[RESCODE: "200-01",RESMSG:"not found"]
                    }
                 }else{
                        resultMap=[RESCODE: "200-01",RESMSG:"not found"]
                    }
            }
        }

    }


     def  getSignData(trxnum){

         StringBuffer srcData = new StringBuffer();
         NetpaySignature sign = new NetpaySignature();
         String mysign="";
		 srcData.append("MechantNo=").append(mechantNo)
				.append("&orderNo=").append(trxnum)
         mysign = sign.sign("SHA1withRSA", srcData.toString().getBytes(), fileKeyPath);
         return    mysign
     }
}
