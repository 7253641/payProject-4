package ismsapp.banks

import com.csii.payment.client.bean.data.AllOrderListReceive
import com.csii.payment.client.bean.data.AllOrderListSend
import com.csii.payment.client.core.PaymentInterfaceUtil
import ismsapp.IsmsConfig
import com.hzbank.netpay.b2cAPI.HZBANKB2CClient
import com.hzbank.netpay.b2cAPI.B2COPReply
import com.hzbank.netpay.b2cAPI.OpResultSet
import com.hzbank.netpay.b2cAPI.OpResult

class HzBankService {

    static transactional = true

   private String sdb_NAME = "test0";                        //建行商户ID
   private String sdb_PASS = "111111";                          //建行分支

    def query(orderNo,actionFlag,begTime,endTime) {
        def resultMap=[]

        String flag;       //订单号
        String code;
        String err;
        String msg;

        HZBANKB2CClient client = new HZBANKB2CClient();

        int  ret = client.initialize("C:\\hzbankjava\\ini\\B2CMerchant.xml");

        if (ret != 0) {                                                                 //初始化失败
            println("初始化失败,错误信息：" + client.getLastErr());
        }

        else {
        	B2COPReply rep=null;
            //单笔订单查询
            if(actionFlag.equals("0")){
                rep= client.queryOrder(orderNo);
            }else{

            	flag="0"

            	rep=client.queryOrderDetail(begTime,endTime,new Integer(flag).intValue(),null,null,null);
            }

            if (rep == null) {
                err = client.getLastErr();
                log.info ("hz orderbyid  not found" );
                resultMap=[RESCODE:"200-01",RESMSG:"not found"]

            }

            else {
                code = rep.getRetCode(); //得到交易返回码

                msg = rep.getErrorMessage();

                println("交易返回码：" + code );

                println("交易错误信息：" + msg );

                if ("000000".equals(code)) { //表示交易成功
                    println("------------------------");
                    OpResult FR=rep.getOpResult();
                    int indexNum=new Integer(FR.getValueByName("totalNumber")).intValue();
                    if(indexNum>1){
                    	OpResultSet oprIcoll=rep.getOpResultSet();
                    	for(int i=0;i<oprIcoll.getOpresultNum();i++){
                    		OpResult opr = oprIcoll.getOpresult(i);
            				String   merchantID = FR.getValueByName("merchantID");   //商户号

                            String   order = opr.getValueByName("order");     //订单号

                            String   orderDate1 = opr.getValueByName("orderDate");   //订单日期

                            String   orderTime = opr.getValueByName("orderTime");   //订单时间

                            String   curType = opr.getValueByName("curType");         //订单币种

                            String   amount = opr.getValueByName("amount");   //金额

                            String   tranDate = opr.getValueByName("tranDate"); //支付日期

                            String   tranTime = opr.getValueByName("tranTime"); //支付时间

                            String   tranState = opr.getValueByName("tranState"); //支付交易状态

                            String   orderState = opr.getValueByName("orderState"); //订单状态

                            String   bankSerialNo = opr.getValueByName("bankSerialNo"); //银行流水号

                            String   comment1 = opr.getValueByName("comment1"); //备注1

                            String   comment2 = opr.getValueByName("comment2"); //备注2

        					println("商户号:"+merchantID);

                            println("订单号:" + order);

                            println("订单日期:" + orderDate1);

                            println("订单时间:" + orderTime);

                            println("订单币种:" + curType);

                            println("金额:" + amount);

                            println("支付日期:"+tranDate);

                            println("支付时间:" + tranTime);

                            println("支付交易状态:" + tranState);

                            println("订单状态:" + orderState);

                            println("银行流水号:" + bankSerialNo);

                            println("备注1:" + comment1);

                            println("备注2:" + comment2);
                    	}

                    }else{

                    	OpResult opr=rep.getOpResult();
                        if(opr){

    					String   merchantID = opr.getValueByName("merchantID");   //商户号

                        String   order = opr.getValueByName("order");     //订单号

                        String   orderDate1 = opr.getValueByName("orderDate");   //订单日期

                        String   orderTime = opr.getValueByName("orderTime");   //订单时间

                        String   curType = opr.getValueByName("curType");         //订单币种

                        String   amount = opr.getValueByName("amount");   //金额

                        String   tranDate = opr.getValueByName("tranDate"); //支付日期

                        String   tranTime = opr.getValueByName("tranTime"); //支付时间

                        String   tranState = opr.getValueByName("tranState"); //支付交易状态

                        String   orderState = opr.getValueByName("orderState"); //订单状态

                        String   bankSerialNo = opr.getValueByName("bankSerialNo"); //银行流水号

                        String   comment1 = opr.getValueByName("comment1"); //备注1

                        String   comment2 = opr.getValueByName("comment2"); //备注2
                        def sts=''
                             switch(orderState){
                                    case "0":
                                        sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNCERTAIN)
                                        break;
                                    case "1":
                                        sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNCERTAIN)
                                        break;
                                    case "2":
                                        sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                        break;
                                    case "3":
                                        sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.CLOSED)
                                        break;
                                    case "5":
                                        sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNCERTAIN)
                                        break;
                                    default:
                                        sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.FAILURE)
                                        break;
                                }

                        resultMap=[RESCODE:"200-00",BANKCODE: 'HZBANK', TRXNUM:order , TRXAMOUNT: amount*100 as long, TRXDATE:tranDate, STS: sts]

    					println("商户号:"+merchantID);

                        println("订单号:" + order);

                        println("订单日期:" + orderDate1);

                        println("订单时间:" + orderTime);

                        println("订单币种:" + curType);

                        println("金额:" + amount);

                        println("支付日期:"+tranDate);

                        println("支付时间:" + tranTime);

                        println("支付交易状态:" + tranState);

                        println("订单状态:" + orderState);

                        println("银行流水号:" + bankSerialNo);

                        println("备注1:" + comment1);

                        println("备注2:" + comment2);

                        }else{
               log.info ("hz orderbyid  not found" );
                resultMap=[RESCODE:"200-01",RESMSG:"not found"]
                }
                    }

                } else{
               log.info ("hz orderbyid  not found" );
                resultMap=[RESCODE:"200-01",RESMSG:"not found"]
                }
            }
        }
    }
}
