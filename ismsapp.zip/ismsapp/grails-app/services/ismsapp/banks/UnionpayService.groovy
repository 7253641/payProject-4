package ismsapp.banks

import groovyx.net.http.HTTPBuilder
import static groovyx.net.http.Method.GET
import static groovyx.net.http.ContentType.TEXT
import groovyx.net.http.ContentType
import ismsapp.IsmsConfig

class UnionpayService {

    static transactional = true
     def http = new HTTPBuilder("http://console.chinapay.com/QueryWeb/processQuery.jsp");
    def merchantCode = "808080510004613";
    //def keypath="/home/production/resource/keys.production/unionpay"
    def keypath=org.codehaus.groovy.grails.commons.ConfigurationHolder.config.Resource.Path

    def query(trxnum,orderdate) {
       def resultMap=[]
       http.request(GET, TEXT) {req ->
           req.getParams().setParameter("http.connection.timeout", 15000)
           req.getParams().setParameter("http.socket.timeout", 15000)

            requestContentType = ContentType.URLENC
            headers.'User-Agent' = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)"
            chinapay.PrivateKey key=new chinapay.PrivateKey();

            boolean flag;
            flag=key.buildKey(merchantCode,0,keypath+"/unionpay/MerPrK_808080510004613_20110421144637.key");
            if (flag==false)
            {
              System.out.println("build key error!");
               return;
            }
            chinapay.SecureLink t=new chinapay.SecureLink (key);
            def ckvalue= t.Sign(merchantCode+orderdate+trxnum+"0001");

            uri.query = [MerId: merchantCode, TransType: "0001", OrdId: trxnum, TransDate: orderdate,
                    Version: "20060831", Resv: "", ChkValue: ckvalue]
            response.success = { resp, reader ->
                 def res = reader.text;
                 println res
                 def vals=[:]
                 for(kvs in res.split("&")){
                    String[] arr= kvs.split("=")
                    vals.put(arr[0],arr[1]);
                 }
                 def sts=""
                 chinapay.PrivateKey key2=new chinapay.PrivateKey();
                 key2.buildKey("999999999999999",0,keypath+"/unionpay/PgPubk.key")
                 chinapay.SecureLink t2=new chinapay.SecureLink(key2);
                //public boolean verifyTransResponse(String MerId, String OrdId, String TransAmt, String CuryId, String TransDate, String TransType, String OrderStatus, String CheckValue)
                def isverify;
                if(vals?.status)
                  isverify=t2.verifyTransResponse(merchantCode,vals?.orderno,vals?.amount,vals?.currencycode,vals?.transdate,vals?.transtype,vals?.status,vals?.checkvalue);
                else
                  isverify=-1;
                if(isverify==0){
                     switch(vals?.status){
                         case "1001":
                            sts= IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                            break;
                         case "":
                            sts= IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNCERTAIN)
                            break;
                          default:
                            break;
                     }
                     if("0".equals(vals.Responsecode)){
                           //ResponeseCode=value1&merid=value2&orderno=value3&amount=value4&currencycode=value5&transdate=value6&transtype=value7&status=value8&checkvalue=value9&GateId= value10&Priv1= value11
                          resultMap=[RESCODE:"200-00",BANKCODE: 'UNIONPAY',STS:sts,TRXAMOUNT:vals.amount,TRXNUM:vals.orderno]
                     }else{
                          //ResponeseCode=value0&Message=message_string
                         resultMap=[RESCODE:"200-01",RESMSG:vals.Message]
                     }
                }else{
                      println("sign wrong")
                      resultMap=[RESCODE:"200-01",RESMSG:"签名失败"]
                }

        }

       }
       return resultMap           //

    }
    def parsefile(text){  //xml format
         def list=[];
         def rec = new XmlSlurper().parseText(text)
         if (text?.indexOf("<?xml") >= 0) {
            rec."ROWDATA".ROW.each {
                 if(it.@TransType.text()=='0001')
                 list<<['UNIONPAY',it.@OrderId.text(),(it.@TransAmt.text() as BigDecimal).movePointLeft(2) ,decode(it.@TransState.text()),it.@MerId.text(),it.@CpDate.text(),it.@CpSeqId.text()]
                 else
                    log.info "ignore transtype"+it.@TransType.text()

            }
         }else{
             log.error "wrong format"
         }
         return list
    }
    def decode(sts){
        def dsts=0;
        switch(sts){
            case "1001":
                dsts=1;
                break;
            default:
                dsts=2;
                break;
        }
        return dsts;
    }
}
