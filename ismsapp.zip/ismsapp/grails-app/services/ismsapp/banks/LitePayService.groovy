package ismsapp.banks

import ismsapp.IsmsConfig
import groovyx.net.http.HTTPBuilder
import static groovyx.net.http.Method.GET
import static groovyx.net.http.ContentType.TEXT
import com.alipay.util.AlipayFunction

class LitePayService {

    static transactional = true
    def http = new HTTPBuilder("https://unionpaysecure.com/api/Query.action");
    def keypath=org.codehaus.groovy.grails.commons.ConfigurationHolder.config.Resource.Path
    def merchantCode ="104110548991184"
    def key="GNKH875Y7U0RJKFH89UHYPTNKHFIOUHOPGHJK"
    def version="1.0.0"
    def charset= "UTF-8"
    def signMethod="MD5"
    def transType="01"
    def merReserved=""

   def query(trxnum,orderdate) {
        def resultMap = []
        http.request(GET, TEXT) {req ->

            req.getParams().setParameter("http.connection.timeout", 15000)
            req.getParams().setParameter("http.socket.timeout", 15000)

            trxnum="221306240027898528";
             orderdate="20130624112742";

            uri.query = [version: version,charset:charset,signMethod:signMethod,transType:transType,merId:merchantCode,orderNumber:trxnum,orderTime:orderdate,merReserved:merReserved,signature:getSignData(trxnum,orderdate)]
            response.success = { resp, reader ->
                def res = reader.text;
                println res
                if(res!=null){
                        def sts = "";
                        Map params = this.getResMap(res);
                       String respCode = params.get("respCode");
                       String queryResult = params.get("queryResult");
                       if(respCode.equals("00")&&queryResult.equals("0")){
                              sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                       }else{
                             sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.FAILURE)
                       }
                    resultMap=[RESCODE:"200-00",BANKCODE: 'LITEPAY', TRXNUM: params.get("respCode"), TRXAMOUNT: amount, TRXDATE: transdate, STS: sts]
                }else{
                    resultMap=[RESCODE: "200-01",RESMSG:"not found"];
                }
            }
        }
        return resultMap;
    }

    def  getSignData(trxnum,orderdate){

       String signature="";
		Map sPara = new HashMap();
		sPara.put("version",version);
		sPara.put("charset",charset);
		sPara.put("transType", transType);

		sPara.put("merId",merchantCode);
		sPara.put("orderTime", orderdate);
		sPara.put("orderNumber",trxnum);
		sPara.put("merReserved", merReserved);

	    signature = AlipayFunction.BuildMysignForLitePay(sPara, key);//生成签名结
        return   signature

    }

    def getResMap(res){
           String[] str = res.split("&");
           String respCode="";
           Map sArrayNew = new HashMap();
           for(int i=0;i<str.length;i++){
               String[] aa = str[i].split("=")
               if(aa.length>1){
                   sArrayNew.put(aa[0], aa[1]);
               }
           }
          return   sArrayNew;
    }

}
