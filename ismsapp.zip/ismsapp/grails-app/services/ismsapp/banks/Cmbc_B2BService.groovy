package ismsapp.banks

import com.hitrust.B2B.CMBC.request.QueryTrnsRequest
import com.hitrust.B2B.CMBC.response.GenericResponse
import com.hitrust.B2B.CMBC.common.MessageTagName
import com.hitrust.B2B.CMBC.util.XMLDocument
import ismsapp.IsmsConfig

/**
 * Created by IntelliJ IDEA.
 * User: xie
 * Date: 13-8-9
 * Time: 上午8:55
 * To change this template use File | Settings | File Templates.
 */
class Cmbc_B2BService {
    static transactional = true
    def  merchantCode ="2008243279"

    def query(trxnum) {

//         trxnum ="231308050060942300"
        def resultMap = [];
        QueryTrnsRequest tRequest =  new QueryTrnsRequest();
        tRequest.setMerchantTrnxNo(merchantCode);
        tRequest.setTrnxCode("Q002");
        tRequest.setQryTrnxNo(trxnum);
        GenericResponse tResponse = tRequest.postRequest();
       if (tResponse.isSuccessed()) {
            if(tResponse==null){
                resultMap=[RESCODE:"200-01",RESMSG:"not found"]
            }
//            String msg = new XMLDocument(tResponse.getValue(MessageTagName.MESSAGE_TAG))
//            msg.replaceAll("[<]", "&lt;");
//            msg.replaceAll("[>]", "&gt;");
//             log.info "msg================"  + msg
           String code = new XMLDocument(tResponse.getValue("Code"))
              log.info "result============"  + code
           if("0000".equals(code)){
              def tlist  = tResponse.getValueList("Status")
                  log.info "tlist============"  + tlist[1]
              if(tlist.size()==2){
                  def tSts = tlist[1].toString().substring(8,9)
                      log.info "tSts============"  + tSts
                   if(tSts!=null&&!"".equals(tSts)){

                       def sts=''
                        switch(tSts){
                                case "0":
                                    sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                    break;
                                default:
                                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.NOTFOUND)
                                    break;
                            }
                        resultMap=[RESCODE:"200-00",BANKCODE: 'CMBC_B2B', TRXNUM:tResponse.getValue("TrnxNo") , TRXAMOUNT: (tResponse.getValue("TrnxAmount" ) as BigDecimal)*100 as long, TRXDATE: tResponse.getValue("ServerTime"), STS: sts]
                   }else{
                    resultMap=[RESCODE:"200-01",RESMSG:"not found"]
                  }

              } else{
                  resultMap=[RESCODE:"200-01",RESMSG:"not found"]
              }

           }else {
            resultMap=[RESCODE:"200-01",RESMSG:"sys error"]
           }
       }else{
           resultMap=[RESCODE:"200-01",RESMSG:"not found"]
       }
    }

}
