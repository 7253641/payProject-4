package ismsapp.banks

import com.alipay.util.HttpsClient
import groovyx.net.http.HTTPBuilder
import org.apache.http.HttpEntity
import org.apache.http.HttpResponse
import org.apache.http.NameValuePair
import org.apache.http.client.entity.UrlEncodedFormEntity
import org.apache.http.client.methods.HttpPost
import org.apache.http.impl.client.DefaultHttpClient
import org.apache.http.message.BasicNameValuePair
import org.apache.http.util.EntityUtils

import static groovyx.net.http.Method.GET
import static groovyx.net.http.ContentType.TEXT
import ismsapp.IsmsConfig
import ismsapp.CiticV6_util
import ismsapp.IOUtils
import org.w3c.dom.Document
import ismsapp.XmlUtils


class CiticService {

    static transactional = true
    def http = new HTTPBuilder("https://ec.test.bank.ecitic.com/WebDLink/e3rdqryorderbyno.do");
    def url = "https://ec.test.bank.ecitic.com/WebDLink/e3rdqryorderbyno.do"
    def keypath=org.codehaus.groovy.grails.commons.ConfigurationHolder.config.Resource.Path
    def signercrt = keypath+"/citic/ecclient.cer"
    def signerkey = keypath+"/citic/ecclient.key"
    def signerpwd = keypath+"/citic/ecclient.pwd"
    def libfolder = keypath+"/citic/lib/"
    def merchantCode =""


     def query(trxnum,acquirerCode) {

         if(acquirerCode == "CITIC"){
             merchantCode = '100599'
         }else if(acquirerCode == "CITIC_B2B"){
             merchantCode = '10001390'
         }

        def resultMap = [];
        CiticV6_util util = new CiticV6_util(libfolder);
        String orderInfo = packageOrderInfo(trxnum);

         Map<String, String> params = new HashMap<String, String>();
         params.put("SIGNREQMSG",util.generateSign(orderInfo,signercrt,signerkey,signerpwd));

         DefaultHttpClient client = HttpsClient.getInstance();
         HttpPost httppost = new HttpPost(url);
         List<NameValuePair> formParams = new ArrayList<NameValuePair>();
         for(Map.Entry<String,String> entry : params.entrySet()){
             formParams.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
         }
         httppost.setEntity(new UrlEncodedFormEntity(formParams, "gbk"));
         HttpResponse response = client.execute(httppost);
         HttpEntity resEntity = response.getEntity();
         def res = EntityUtils.toString(resEntity, "gbk")
         log.info("中信银行订单状态查询接口返回："+res)

         def msg_xml = ''
         if(res!=null){
             Document doc1=XmlUtils.getDocument(res);
             if(doc1!=null){
                 def xml_status = XmlUtils.getNodeValue(doc1,"status");
                 if(xml_status.trim()=="AAAAAAA"){
                     def xml_data = XmlUtils.getNodeValue(doc1,"data");
                     byte[] msg_byte = util.getMsg(xml_data);
                     msg_xml = new String(msg_byte);
                     log.info "citic msg_xml:"+msg_xml
                     Document doc=XmlUtils.getDocument(msg_xml);
                     if(doc!=null){
                         def msgCode = XmlUtils.getNodeValue(doc,"msgCode");
                         def orderNo = XmlUtils.getNodeValue(doc,"orderNo");
                         def orderAmt = XmlUtils.getNodeValue(doc,"orderAmt");
                         def orderDate = XmlUtils.getNodeValue(doc,"orderDate");
                         def sts = "";
                         switch(msgCode){
                             case "AAAAAAA":
                                 sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                 break;
                             default:
                                 sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.FAILURE)
                                 break;
                         }
                         resultMap=[RESCODE:"200-00",BANKCODE: 'CITIC', TRXNUM:orderNo, TRXAMOUNT: orderAmt, TRXDATE: orderDate, STS: sts]
                     }else{
                         resultMap=[RESCODE: "200-01",RESMSG:"not found"];
                     }
                 }else{
                     resultMap=[RESCODE: "200-01",RESMSG:"not found"];
                 }

             }else{
                 resultMap=[RESCODE: "200-01",RESMSG:"not found"];
             }
         }else{
             resultMap=[RESCODE: "200-01",RESMSG:"not found"];
         }

//        http.request(GET, TEXT) {req ->
//            uri.query = [SIGNREQMSG:util.generateSign(orderInfo,signercrt,signerkey,signerpwd)]
//            response.success = { resp, reader ->
//                req.getParams().setParameter("http.connection.timeout", 15000)
//                req.getParams().setParameter("http.socket.timeout", 15000)
//                def res = reader.text;
//
//
//            }
//        }
        return resultMap;
    }


  def  packageOrderInfo(String trxnum)
	{
              Date date = new Date();
	      java.text.SimpleDateFormat sdf=new java.text.SimpleDateFormat("yyyyMMddHHmmss");
               String c=sdf.format(date);

		StringBuffer sb = new StringBuffer("<?xml version=\"1.0\" encoding=\"GBK\"?>");
		sb.append("<stream>");
		sb.append("<E3RDPAYNO>"+this.merchantCode+"</E3RDPAYNO>");  //商户号
		sb.append("<ORDERNO>"+trxnum+"</ORDERNO>");//订单号
		sb.append("<LOCALTIME>"+c+"</LOCALTIME>");//当前时间
		sb.append("</stream>");
		log.info("order info_send："+sb.toString());
		return sb.toString();
	}

    
}
