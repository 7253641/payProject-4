package ismsapp.banks

import com.bocom.netpay.b2cAPI.BOCOMB2CClient
import com.bocom.netpay.b2cAPI.OpResultSet
import ismsapp.IsmsConfig

class CommService {

    static transactional = true
    def httpInvokeHsbcClientService;
    
    def query(trxnum,orderdate) {
         def resultMap=[]
         def orders = trxnum
         def com =httpInvokeHsbcClientService.getRep("", "BOCM", orders);
           if(com!=null){
                 def result=com.orderState
                if(result!=null&&!"".equals(result)){
                    def sts=''
                    println "COMM return:result="+result
                    switch(result){
                        case "0":
                            sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNPAID)
                            break;
                        case "1":
                            sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                            break;
                        default:
                            sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.NOTFOUND)
                            break;
                    }
                    resultMap=[RESCODE:"200-00",BANKCODE: 'HSBC', TRXNUM:trxnum , TRXAMOUNT: (com.amount as BigDecimal)*100 as long, TRXDATE: orderdate, STS: sts]
                }else{
                    println "COMM return: not found result is null"
                    resultMap=[RESCODE:"200-01",RESMSG:"not found"]
                }
           }else{
               println "COMM return: not found com is null"
               resultMap=[RESCODE:"200-01",RESMSG:"not found"]
           }

         return resultMap           //

    }
}
