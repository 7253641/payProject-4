package ismsapp.banks

import com.hitrust.trustpay.client.TrxResponse
import com.hitrust.trustpay.client.XMLDocument
import ismsapp.IsmsConfig
import java.text.NumberFormat
import com.hitrust.trustpay.client.b2c.*

class Sdb_B2BService {

    static transactional = true

    def query(tOrderNo, tQueryType) {
        def resultMap=[]
        boolean tEnableDetailQuery = false;
        if (tQueryType.equals("1"))
            tEnableDetailQuery = true;

        //2、生成商户订单查询请求对象
        def tRequest = new QueryOrderRequest();
        tRequest.setOrderNo(tOrderNo);  //订单号           （必要信息）
        tRequest.enableDetailQuery(tEnableDetailQuery);  //是否查询详细信息 （必要信息）

        //3、传送商户订单查询请求并取得订单查询结果
        TrxResponse tResponse = tRequest.postRequest();

        //4、判断商户订单查询结果状态，进行后续操作
        if (tResponse.isSuccess()) {
            //5、生成订单对象
            Order tOrder = new Order(new XMLDocument(tResponse.getValue("Order")));
            if(tOrder==null){
                resultMap=[RESCODE:"200-01",RESMSG:"not found"]
            }
            println("OrderNo      = [" + tOrder.getOrderNo() + "]<br>");
            println("OrderAmount  = [" + tOrder.getOrderAmount() + "]<br>");
            println("OrderDesc    = [" + tOrder.getOrderDesc() + "]<br>");
            println("OrderDate    = [" + tOrder.getOrderDate() + "]<br>");
            println("OrderTime    = [" + tOrder.getOrderTime() + "]<br>");
            println("OrderURL     = [" + tOrder.getOrderURL() + "]<br>");
            println("PayAmount    = [" + tOrder.getPayAmount() + "]<br>");
            println("RefundAmount = [" + tOrder.getRefundAmount() + "]<br>");
            println("OrderStatus  = [" + tOrder.getOrderStatus() + "]<br>");
            def result = tOrder.getOrderStatus()
             if(result!=null&&!"".equals(result)){
                   def sts=''
                    switch(result){
                            case "00":
                                sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.NOTFOUND)
                                break;
                            case "01":
                                sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNPAID)
                                break;
                             case "02":
                                sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNPAID)
                                break;
                            case "03":
                                sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                break;
                            case "04":
                                sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                break;
                             case "05":
                                sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.NOTFOUND)
                                break;
                            default:
                                sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.FAILURE)
                                break;
                        }
                     resultMap=[RESCODE:"200-00",BANKCODE: 'ABC', TRXNUM:tOrder.getOrderNo() , TRXAMOUNT: (tOrder.getOrderAmount())*100 as long, TRXDATE: tOrder.getOrderDate(), STS: sts]
             }else{
                resultMap=[RESCODE:"200-01",RESMSG:"not found"]
             }
        }
        else {
            //7、商户订单查询失败
            println("ReturnCode   = [" + tResponse.getReturnCode() + "]<br>");
            println("ErrorMessage = [" + tResponse.getErrorMessage() + "]<br>");
            resultMap=[RESCODE:"200-01",RESMSG:"not found"]
        }
    }

    def refund(tOrderNo, tNewOrderNo, tTrxAmount) {
        RefundRequest tRequest = new RefundRequest();
        tRequest.setOrderNo(tOrderNo);  //订单号   （必要信息）
        tRequest.setNewOrderNo(tNewOrderNo);  //新订单号   （必要信息）
        tRequest.setTrxAmount(tTrxAmount);  //退货金额 （必要信息）

        //3、传送退货请求并取得退货结果
        TrxResponse tResponse = tRequest.postRequest();

        //4、判断退货结果状态，进行后续操作
        if (tResponse.isSuccess()) {
            //5、退货成功
            println("TrxType   = [" + tResponse.getValue("TrxType") + "]<br>");
            println("OrderNo   = [" + tResponse.getValue("OrderNo") + "]<br>");
            println("NewOrderNo   = [" + tResponse.getValue("NewOrderNo") + "]<br>");
            println("TrxAmount = [" + tResponse.getValue("TrxAmount") + "]<br>");
            println("BatchNo   = [" + tResponse.getValue("BatchNo") + "]<br>");
            println("VoucherNo = [" + tResponse.getValue("VoucherNo") + "]<br>");
            println("HostDate  = [" + tResponse.getValue("HostDate") + "]<br>");
            println("HostTime  = [" + tResponse.getValue("HostTime") + "]<br>");
            println("TrnxNo    = [" + tResponse.getValue("iRspRef") + "]<br>");
        }
        else {
            //6、退货失败
            println("ReturnCode   = [" + tResponse.getReturnCode() + "]<br>");
            println("ErrorMessage = [" + tResponse.getErrorMessage() + "]<br>");
        }
        return tResponse.isSuccess();
    }

    def getSettleList(tSettleDate) {
        NumberFormat tFormat = NumberFormat.getInstance();
        tFormat.setMaximumFractionDigits(2);
        tFormat.setGroupingUsed(false);
        tFormat.setMinimumFractionDigits(2);

        //2、生成商户对账单下载请求对象
        SettleRequest tRequest = new SettleRequest();
        tRequest.setSettleDate(tSettleDate);               //对账日期YYYY/MM/DD （必要信息）
        tRequest.setSettleType(SettleFile.SETTLE_TYPE_TRX);//对账类型 （必要信息）
        //SettleFile.SETTLE_TYPE_TRX：交易对账单

        //3、传送商户对账单下载请求并取得对账单
        TrxResponse tResponse = tRequest.postRequest();

        //4、判断商户对账单下载结果状态，进行后续操作
        if (tResponse.isSuccess()) {
            //5、商户对账单下载成功，生成对账单对象
            SettleFile tSettleFile = new SettleFile(tResponse);
            println("SettleDate        = [" + tSettleFile.getSettleDate() + "]<br>");
            println("SettleType        = [" + tSettleFile.getSettleType() + "]<br>");
            println("NumOfPayments     = [" + tSettleFile.getNumOfPayments() + "]<br>");
            println("SumOfPayAmount    = [" + tFormat.format(tSettleFile.getSumOfPayAmount()) + "]<br>");
            println("NumOfRefunds      = [" + tSettleFile.getNumOfRefunds() + "]<br>");
            println("SumOfRefundAmount = [" + tSettleFile.getSumOfRefundAmount() + "]<br>");

            //6、取得对账单明细
            String[] tRecords = tSettleFile.getDetailRecords();
            for (int i = 0; i < tRecords.length; i++) {
                println("Record-" + i + " = [" + tRecords[i] + "]<br>");
            }
        }
        else {
            //7、商户账单下载失败
            println("ReturnCode   = [" + tResponse.getReturnCode() + "]<br>");
            println("ErrorMessage = [" + tResponse.getErrorMessage() + "]<br>");
        }
    }

}
