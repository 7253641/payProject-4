package ismsapp.banks

import com.alipay.util.HttpsClient
import ismsapp.IsmsConfig
import org.apache.http.HttpEntity
import org.apache.http.HttpResponse
import org.apache.http.NameValuePair
import org.apache.http.client.entity.UrlEncodedFormEntity
import org.apache.http.client.methods.HttpPost
import org.apache.http.impl.client.DefaultHttpClient
import org.apache.http.message.BasicNameValuePair
import org.apache.http.util.EntityUtils
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException


/**
 * Created with IntelliJ IDEA.
 * User: admin
 * Date: 14-3-3
 * Time: 下午1:56
 * To change this template use File | Settings | File Templates.
 */
class CibService {

    def service = "cib.netpay.order.get"//服务名称
    def ver = '01'//接口版本号
    def mrch_no = '' //商户号
    def b2c_no = '110433' //b2c商户号
    def b2b_no = '110434' //b2b商户号
    def pubKey = '12345678' //加密串
    def CIB_PATH = "https://220.250.30.210:38091/payment/api/rest" //请求地址

    def query(trxnum,channel) {

        def resultMap = [];

        if(channel == 'CIB'){
            log.info("兴业银行B2C订单状态查询接口。。。。。")
            mrch_no = b2c_no
        }else  if(channel == 'CIB_B2B'){
            log.info("兴业银行B2B订单状态查询接口。。。。。")
            mrch_no = b2b_no
        }

        def sf = "service"+service+"ver"+ver+"mrch_no"+mrch_no+"ord_no"+trxnum
        log.info("验签字符串："+sf)
        def mac = md5(sf+pubKey)
        log.info("加密字符串："+mac)

        Map<String, String> params = new HashMap<String, String>();
        params.put("service",service);
        params.put("ver",ver);
        params.put("mrch_no",mrch_no);
        params.put("ord_no",trxnum);
        params.put("mac",mac);

        DefaultHttpClient client = HttpsClient.getInstance();
        HttpPost httppost = new HttpPost(CIB_PATH);
        List<NameValuePair> formParams = new ArrayList<NameValuePair>();
        for(Map.Entry<String,String> entry : params.entrySet()){
            formParams.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
        }
        httppost.setEntity(new UrlEncodedFormEntity(formParams, "gbk"));
        HttpResponse response = client.execute(httppost);
        HttpEntity resEntity = response.getEntity();
        def res = EntityUtils.toString(resEntity, "gbk")
        log.info("兴业银行订单状态查询接口返回："+res)
        def rec = new XmlSlurper().parseText(res)
        def order  =  rec.Order
        if(order != null && order != ''){
            def merchantNo = order.merchantNo //商户代号
            def orderNo = order.orderNo //订单编号
            def merchantName = order.merchantName //商户名称
            def subMerchantName = order.subMerchantName //二级商户名称
            def orderDate = order.orderDate //订单生成日期
            def orderAmount = order.orderAmount //订单金额
            def currency = order.currency //订单币种
            def orderStatus = order.orderStatus //订单状态
            def refundAmount = order.refundAmount //已退款金额
            def updateTime = order.updateTime //状态最后更新时间

            def sts = ''
            switch (orderStatus){
                case  ["1","2"]:
                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                    break
                case ["3"]:
                      sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.CLOSED)
                    break
                case ["0"]:
                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNPAID)
                    break
                default:
                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.FAILURE)
                    break
            }
            resultMap=[RESCODE:"200-00",BANKCODE:'CIB',MERCHANT:merchantNo ,TRXNUM: orderNo, TRXAMOUNT:orderAmount,TRXDATE:orderDate, STS: sts]
        }else{
            def code = rec.code
            def msg = rec.msg
            resultMap=[RESCODE:"200-01",RESMSG:msg]
        }
        log.info("兴业银行自动核对返回："+resultMap)
        return resultMap;
    }

    def String md5(String str) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(str.getBytes("UTF-8"));
            byte [] b = md.digest();
            int i;
            StringBuffer buf = new StringBuffer();
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0)
                    i += 256;
                if (i < 16)
                    buf.append("0");
                buf.append(Integer.toHexString(i));
            }
            return buf.toString().toUpperCase();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null;
        }
    }
}


