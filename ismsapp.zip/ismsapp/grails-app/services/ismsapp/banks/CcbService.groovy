package ismsapp.banks

import CCBSign.RSASig
import ismsapp.ScriptMD5
import groovyx.net.http.HTTPBuilder
import static groovyx.net.http.Method.GET
import static groovyx.net.http.ContentType.TEXT
import groovyx.net.http.ContentType
import ismsapp.IsmsConfig





class CcbService {

    static transactional = true
    private String ccb_MERCHANTID = "105120073990257";                        //建行商户ID
    private String ccb_BRANCHID = "120000000";                          //建行分支
    private String ccb_POSID = "774514193";                             //建行柜员号
    private String ccb_ptStyle = "9";                       //显示结果风格	xml
    private String pubkey = "30819c300d06092a864886f70d010101050003818a003081860281807596cfc34e832d6fe078b14f954f6ab0c51502bf55e7a4505de46ad7ec481da8a8923b3d1ddfd34bcf5d89d3882b9681b544a0db2a642da79a71a4a2c2a4aeefd3353112dc7dbc357b15dd8167ef9ef92c2feb5bcd3f2e475d96fff29a4002e55de088ae500a80e69f642d3e671a08f470e9c2a50ec173ca2ef7de639539ed73020111";
    private final String CCB_PATH = "https://ibsbjstar.ccb.com.cn/app/ccbMain";               //访问路径
    private final String CCB_TXCODE = "410404";                    //交易号

    def query(orderdate, trxnum) {

        def http = new HTTPBuilder(CCB_PATH);

        def resultMap=[];
        http.request(CCB_PATH, GET, TEXT) {req ->
            //uri.path = "app/ccbMain"
            req.getParams().setParameter("http.connection.timeout", 15000)
            req.getParams().setParameter("http.socket.timeout", 15000)
            requestContentType = ContentType.URLENC
            headers.'User-Agent' = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)"
            uri.query = [MERCHANTID: ccb_MERCHANTID, BRANCHID: ccb_BRANCHID, POSID: ccb_POSID, ORDERDATE: orderdate,
                    ORDERID: trxnum, TXCODE: CCB_TXCODE, PT_STYLE: ccb_ptStyle, MAC: encrypt(orderdate, trxnum)]

            response.success = { resp, reader ->
                def res = reader.text;
                println res
                def rec = new XmlSlurper().parseText(res)
                if (res?.indexOf("DOCUMENT") > 0) {
                    rec."QUERYORDER".each {
                        def sign_b=checkSigns(it.ORDERDATE.text(), it.ORDERID.text(), it.RESULT.text(),it.SIGN.text());
                        if (sign_b) {
                            def sts = "";
                            switch (it.RESULT.text()) {
                                case ["1", "3"]:   //success
                                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                    break;
                                case ["2", "0"]:   //failure
                                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.FAILURE)
                                    break;
                                case "4":         //uncetain
                                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNCERTAIN)
                                    break;
                                case "5":        //not found
                                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.NOTFOUND)
                                    break;
                                default:
                                    break;
                            }
                            resultMap=[RESCODE:"200-00",BANKCODE: 'CCB', MERCHANT: it.MERCHANTID.text(), TRXNUM: it.ORDERID.text(), TRXAMOUNT:it.AMOUNT.text(), TRXDATE: it.ORDERDATE.text(), STS: sts]
                        }else{
                            println 'sign wrong'
                        }

                    }
                }else if(res?.indexOf("ROOT") > 0){
                    resultMap=[RESCODE:"200-01",RESMSG:rec.ERROR.ERRORCODE.text()]
                }
            }
        }
        return resultMap;
    }


    private String encrypt(orderdate, ordernum) {
        String plain = "MERCHANTID=" + ccb_MERCHANTID +
                "&BRANCHID=" + ccb_BRANCHID +
                "&POSID=" + ccb_POSID +
                "&ORDERDATE=" + orderdate +
                "&ORDERID=" + ordernum +
                "&TXCODE=" + this.CCB_TXCODE;
        if ("9".equals(this.ccb_ptStyle)) {
            plain += "&PT_STYLE=" + this.ccb_ptStyle;
        }
        return new ScriptMD5().calcMD5(plain);
    }

    def checkSigns(orderdate, orderid, result,signs) {
        String s = "MERCHANTID=" + ccb_MERCHANTID + "&BRANCHID="+ ccb_BRANCHID + "&POSID=" + ccb_POSID + "&ORDERDATE=" +orderdate + "&ORDERID=" + orderid;
        s += "&RESULT=" + result;
        println s;
        RSASig sign = new RSASig();
        sign.setPublicKey(pubkey);
        sign.verifySigature(signs,s)

    }
    /*
    <?xml version="1.0" encoding="GB2312" ?>
            <ROOT>
              <ERROR>
                <ERRORCODE>
                  0130Z110C414
                </ERRORCODE>
                <ERRORLIST>

                  <ERRORCONTENT>
                        交易处理失败，请您稍候再试或咨询95533。

                  </ERRORCONTENT>

                </ERRORLIST>
              </ERROR>
            </ROOT>
    */
}
