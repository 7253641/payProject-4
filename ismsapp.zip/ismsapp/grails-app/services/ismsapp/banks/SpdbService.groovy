package ismsapp.banks

import groovyx.net.http.HTTPBuilder
import static groovyx.net.http.Method.GET
import static groovyx.net.http.ContentType.TEXT
import ismsapp.IsmsConfig
import spdb.Spdb

class SpdbService {

    static transactional = true
//    def http = new HTTPBuilder("https://ebank.spdb.com.cn/payment/paygate");
    def http = new HTTPBuilder("http://124.74.239.32/payment/main");
    def keypath=org.codehaus.groovy.grails.commons.ConfigurationHolder.config.Resource.Path
    def merchantCode ="820545110000101"

    def query(trxnum) {
        def resultMap = [];
        String plain = "MercCode="+merchantCode+"|OTranAbbr=IPER|TermSsn="+trxnum;
        http.request(GET, TEXT) {req ->
            uri.query = [transName: "IQSR", Plain: plain, Signature: getSignData(plain)]
            response.success = { resp, reader ->

                req.getParams().setParameter("http.connection.timeout", 15000)
                req.getParams().setParameter("http.socket.timeout", 15000)
                def res = reader.text;
                println res
                def rec = new XmlSlurper().parseText(res)
                println rec                
                if(res?.indexOf("packet") > 0)
                {
                    def sts = "";
                    if(res?.indexOf("transName") > 0)
                    {
                        String Plain = rec.toString().substring(4,rec.toString().lastIndexOf(("RespCode="))+11);
                        String Signature = rec.toString().substring(rec.toString().lastIndexOf(("RespCode="))+11,rec.toString().length());
                        if(decodeSignData(Signature, Plain))
                        {
                            String[] results = Plain.toString().split("\\|");
                            println results;
                            String SettDate = results[0].split("=")[1];
                            String AcqSsn = results[1].split("=")[1];
                            String TermSsn = results[2].split("=")[1];
                            String TranAmt = results[3].split("=")[1];
                            String CompFlag = results[4].split("=")[1];
                            String RespCode = results[5].split("=")[1];
                            switch (RespCode)
                            {
                                case ["00"]:   //success
                                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                    break;
                                case ["12"]:        //not found
                                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.NOTFOUND)
                                    break;
                            }
                            resultMap = [RESCODE: "200-00", BANKCODE: 'SPDB', BANKSEQ:AcqSsn,
                                    TRXNUM: TermSsn, TRXAMOUNT: TranAmt,STS: sts]
                        }
                    }
                    if(res?.indexOf("ErrorCode") > 0)
                    {
                        resultMap=[RESCODE: "200-01",RESMSG:rec.toString().substring(2,rec.toString().length())]
                    }
                }else{
                    resultMap=[RESCODE: "200-01",RESMSG:rec."header".exception]
                }
            }
        }
        println resultMap;
        return resultMap;
    }
    def getSignData(String plain) {
        try {
            println plain;
            String sign = Spdb.getSign(plain);
            println sign;
            return sign;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean decodeSignData(String signature, String plain)
    {
        try {
            println signature.concat("=============").concat(plain);
            boolean sign = Spdb.decodeSign(signature,plain);
            println sign;
            return sign;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

}