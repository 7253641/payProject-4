package ismsapp.banks

import cmb.netpayment.Settle
import ismsapp.AcquireSynTrx
import ismsapp.IsmsConfig
import ismsapp.Gwtrxs
import ismsapp.AcquireFaultTrx
import java.text.DecimalFormat
import java.text.SimpleDateFormat

class CmbService {

    def httpInvokeClientService;
    static transactional = true
    def cmb_branchid="0022"; //BRANCHID;  //招行开户行代码
	def cmb_cono="000371";    //CONO;      //招行商户代码
	def cmb_password="628525"; //PASSWORD;  //招行商户密码
    def cmb_hosts="netpay.cmbchina.com"; //CMB_OPTIONS
    def Settle settle=new Settle();

    def login() {
        int iRet = settle.SetOptions(cmb_hosts); //?connect to
   		if (iRet == 0){
			log.info("SetOptions ok");
    	}
    	else{
			log.error(settle.GetLastErr(iRet));
		}
   		iRet = settle.LoginC(this.cmb_branchid,
   				              this.cmb_cono,
							  this.cmb_password);
    	if (iRet == 0){
			log.info("LoginC ok");
	    }else{
            log.info("logerr:"+settle.GetLastErr(iRet))
        }
        return iRet
    }
    def logout(){
		int i_result=settle.Logout();
		if(i_result!=0){
			log.info(settle.GetLastErr(i_result));
		}else{
			log.error("logout:be sure you logined");
		}
    }
    def getUnsettledTrxs(){
        def list=[]
        if(login()==0){
            StringBuffer str_buf2 = new StringBuffer()
            int iRet = settle.QueryUnsettledOrder(str_buf2);
            if (iRet == 0){
                log.info("QueryUnsettledOrder ok"+str_buf2.toString());
                StringTokenizer st=new StringTokenizer(str_buf2.toString(),"\n")
                if(st.countTokens()%4==0){
                    int  count=st.countTokens()/4;

                    for(int i=0;i<count;st.hasMoreElements()){
                        i++;
                        def x=[]
                        (1..4).times{
                            x<<st.nextElement();
                        }
                        list<<x;
                    }
                }else{
                    log.error(str_buf2.toString()+ "wrong data format")
                }
            }
            else{
                log.info(settle.GetLastErr(iRet));
            }
        }else{
            println "CMB not login"
        }
        return list;

    }
    def settleTrxs(strBillNo,strRefNo,strPartAmount){
        int i_result=settle.SettlePartOrder(strBillNo,strRefNo,strPartAmount);
		if(i_result!=-1&&i_result!=0){
			log.info(settle.GetLastErr(i_result));
		}
    }
    def cronSettle(){
        def list=getUnsettledTrxs();
        log.info "CMB SETTLE LIST:"+list
        for(x in list){
            def syntrx=new AcquireSynTrx();
            syntrx.acquireCode="CMB"
            syntrx.acquireDate=x[0]
            syntrx.amount=(x[1] as double)*100
            syntrx.acquireSeq=x[3]
            syntrx.trxid=x[2]
            syntrx.trxsts=IsmsConfig.stateMap[IsmsConfig.TrxSTS.SUCCESS]  as int
            if(syntrx.save(flush:true)){
                settleTrxs(x[2],x[3],x[1])
                log.info("settle:"+x[2])

                Gwtrxs trx=Gwtrxs.findByAcquirerCodeAndTrxnum(syntrx.acquireCode,syntrx.trxid)
                if(trx!=null&&trx.trxsts!=syntrx.trxsts){
                    AcquireFaultTrx faultTrx=new AcquireFaultTrx();
                    faultTrx.iniSts=trx.trxsts
                    faultTrx.createDate=new Date()
                    faultTrx.updateDate=new Date();
                    faultTrx.authDate=new Date()
                    faultTrx.authOper="SYSTEM"
                    faultTrx.authSts="U"
                    faultTrx.changeApplier="CMBSettler"
                    faultTrx.changeSts="3"

                    faultTrx.acquireTrxnum=syntrx.trxid;
                    faultTrx.trxid=trx.id;
                    faultTrx.acquireSeq=syntrx.acquireSeq
                    faultTrx.trxamount=syntrx.amount

                    if(faultTrx.save(flush:true)){
                        def flg=httpInvokeClientService.next(faultTrx.id)
                        log.info("fault Trx Generating:"+faultTrx.trxid+" clientService:"+flg)

                    }
                }else{
                    log.error "trx not found:"+syntrx.trxid
                }

            }else{
               syntrx.errors.each {
                    println it
               }
            }

        }
        logout();
    }

    def query(orderdate,trxnum){
         def resultMap=[];
         int i=login();
         if(i==0||i==2){
               StringBuffer str_buf3 = new StringBuffer()
               int iRet=settle.QuerySingleOrder(orderdate,trxnum,str_buf3)
             log.info("CMB return iRet:"+iRet);
              if (iRet == 0){
                log.info(trxnum+" QueryOrder ok ,result:"+str_buf3.toString());
                def result=str_buf3.toString().split("\n")
                if(result.length>=3){
                    def sts=''
                    switch(result[2]){
                        case "0":
                            sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                            break;
                        case "4":
                            sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                            break;
                        default:
                            sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.NOTFOUND)
                            break;
                    }
                    log.info("CMB return sts:"+sts);
                    resultMap=[RESCODE:"200-00",BANKCODE: 'CMB', MERCHANT: cmb_cono, TRXNUM:trxnum , TRXAMOUNT: (result[3] as BigDecimal)*100 as long, TRXDATE: orderdate, STS: sts]
                }else{
                    resultMap=[RESCODE:"200-00",RESMSG:"not found"]
                }
                logout();
            }
            else{
                log.info(trxnum+settle.GetLastErr(iRet));
                resultMap=[RESCODE:"200-01",RESMSG:"not found"]
                return
		     }
         }
         return resultMap;
    }

    def downloadTrxs(acqdate){
        StringBuffer strbuf = new StringBuffer();
        int i=login();
        def batchnum=""
        if(i==0||i==2){
            batchnum="CMB"+acqdate+"-"+new SimpleDateFormat("MMddHHmmss").format(new Date());
            settle.PageReset();
            int iRet = settle.QueryTransactByPage(acqdate,100,strbuf);
            while(iRet==0 && !settle.m_bIsLastPage){
                iRet = settle.QueryTransactByPage(acqdate,100,strbuf);
            }
            log.info(strbuf.toString())
            StringTokenizer st=new StringTokenizer(strbuf.toString(),"\n")
            if(st.countTokens()%5==0){
                int  count=st.countTokens()/5;
                for(int j=0;j<count;st.hasMoreElements()){
                    j++;
                    AcquireSynTrx synTrx=new AcquireSynTrx();
                    synTrx.acquireDate=st.nextElement() as String;
                    st.nextElement();
                    synTrx.amount=(st.nextElement() as BigDecimal)*100 ;
                    synTrx.trxid =st.nextElement() as String;
                    switch(st.nextElement()){
                        case "0":
                             synTrx.trxsts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)  as int
                            break;
                        case "1":
                             synTrx.trxsts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.FAILURE) as int        //CANCEL
                            break;
                        default:
                            synTrx.trxsts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNCERTAIN) as int
                            break;
                    }
                    synTrx.acquireCode="CMB"
                    synTrx.acquireMerchant=cmb_cono.substring(0,6)
                    synTrx.createDate=new Date()
                    synTrx.batchnum=batchnum
                    if(synTrx.save(flush:true)){
                        log.error "save "+synTrx.acquireCode+" trx:"+synTrx.id
                    }else{
                       synTrx.errors.each {
                            log.error it
                       }
                    }

                }
            }else{
                log.error(strbuf?.toString()+ "wrong data format")
                batchnum=""
            }

        }else{
            log.info("login error:"+i)
        }
        logout();
        return batchnum
    }


}
