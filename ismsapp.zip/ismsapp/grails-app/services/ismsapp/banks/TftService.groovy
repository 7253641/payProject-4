package ismsapp.banks

import net.sf.json.JSONObject
import groovyx.net.http.HTTPBuilder
import ismsapp.IsmsConfig
import ismsapp.Md5Algorithm
import java.security.MessageDigest
import static groovyx.net.http.ContentType.TEXT
import static groovyx.net.http.Method.POST
import cn.tempus.pt.supplier.send.Sender
import cn.tempus.pt.supplier.exception.TrxException

class TftService {



    static transactional = true
    def http = new HTTPBuilder("https://yintong.com.cn/traderapi/orderquery.htm");
    def keypath=org.codehaus.groovy.grails.commons.ConfigurationHolder.config.Resource.Path
    def merchantCode =201406091000001297
   // def keyStorePath =keypath+"/boc/104110048991204.pfx";
   // def keyStorePassword = "111111"
   // def keyPassword = "111111"
   // def rootCertificatePath = ""
    def  tftSender;
    def query(submitdate,trxnum) {
        def resultMap = []

                Map m = new HashMap();
                m.put("code", "ORD004");
                m.put("OrderDate", submitdate[0..7]);
                 m.put("merOrderId", trxnum);
                Map outMap = new HashMap();
                try {
                    outMap = tftSender.send(m).getMap();
                } catch (TrxException e) {
                    e.printStackTrace();
                }

                if(outMap!=null){
                       JSONObject rec = JSONObject.fromObject(outMap);

                        if("99".equals(rec.getString("merOrderStatus"))){
                                resultMap=[RESCODE: "200-01",RESMSG:rec.getString("merOrderStatus")]
                        }else{
                        def merchantNo=rec.getString("merCode");
                        def trxNum=rec.getString("merOrderId");
                        def bankSeq=rec.getString("merOrderId");
                        def transAmount=rec.getString("merOrderAmt");
                        def result=rec.getString("merOrderStatus");
                        def sts="";
                        switch (result) {
                            case "01":   //success
                                sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                break;
                            case "00":   //failure
                                sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNPAID)
                                break;
                            case "02":        //not found
                                sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNCERTAIN)
                        }

                         resultMap = [RESCODE: "200-00", BANKCODE: 'tft', MERCHANT: merchantNo,BANKSEQ:bankSeq,
                                TRXNUM: trxNum, TRXAMOUNT: transAmount,STS: sts]
                        }
                }else{
                      resultMap=[RESCODE: "200-01",RESMSG:"not found"]
                }

        return resultMap;
    }


     String addSignMD5(JSONObject reqObj, String md5_key)
     {
         System.out.println("进入商户[" + reqObj.getString("oid_partner")
                 + "]MD5加签名");
         if (reqObj == null)
         {
             return "";
         }
         // 生成待签名串
         String sign_src = genSignData(reqObj);
         System.out.println("商户[" + reqObj.getString("oid_partner") + "]加签原串"
                 + sign_src);
         sign_src += "&key=" + md5_key;
         try
         {
             return Md5Algorithm.getInstance().md5Digest(
                     sign_src.getBytes("utf-8"));
         } catch (Exception e)
         {
             System.out.println("商户[" + reqObj.getString("oid_partner")
                     + "]MD5加签名异常" + e.getMessage());
             return "";
         }
     }


     String genSignData(JSONObject jsonObject)
    {
        StringBuffer content = new StringBuffer();

        // 按照key做首字母升序排列
        List<String> keys = new ArrayList<String>(jsonObject.keySet());
        Collections.sort(keys, String.CASE_INSENSITIVE_ORDER);
        for (int i = 0; i < keys.size(); i++)
        {
            String key = (String) keys.get(i);
            if ("sign".equals(key))
            {
                continue;
            }
            String value = jsonObject.getString(key);

            content.append((i == 0 ? "" : "&") + key + "=" + value);

        }
        String signSrc = content.toString();
        if (signSrc.startsWith("&"))
        {
            signSrc = signSrc.replaceFirst("&", "");
        }
        return signSrc;
    }

//    public boolean verify(String signData, String plain) {
//        try {
//            PKCS7Tool tools = PKCS7Tool.getVerifier(rootCertificatePath);
//            if (tools != null) {
//                tools.verify(signData, plain.getBytes(), this.dn);
//                return true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return false;
//
//    }
      String MD5(String s) {
	        char[]  hexDigits = [ '0','1', '2', '3', '4', '5', '6', '7', '8', '9','A', 'B', 'C', 'D', 'E', 'F' ];
	        try {
	            byte[] btInput = s.getBytes();
	            //获得MD5摘要算法的 MessageDigest 对象
	            MessageDigest mdInst = MessageDigest.getInstance("MD5");
	            //使用指定的字节更新摘要
	            mdInst.update(btInput);
	            //获得密文
	            byte[] md = mdInst.digest();
	            //把密文转换成十六进制的字符串形式
	            int j = md.length;
	            char[]  str= new char[j * 2];
	            int k = 0;
	            for (int i = 0; i < j; i++) {
	                byte byte0 = md[i];
	                str[k++] = hexDigits[byte0 >>> 4 & 0xf];
	                str[k++] = hexDigits[byte0 & 0xf];
	            }
	            return new String(str).toLowerCase();
	        }
	        catch (Exception e) {
	            e.printStackTrace();
	            return null;
	        }
	    }

    def printXml() {
        def rec = new XmlSlurper().parseText(teststr)
        println rec."header".merchantNo;
        rec."body".orderTrans.each {
            println it.orderNo;
        }
    }

    def teststr = """<?xml version="1.0" encoding="utf-8" ?>
<res>
    <header>
         <merchantNo>104110041000000</merchantNo>
    </header>
    <body>
         <orderTrans>
                  <orderNo>TEST0001</orderNo>
                  <orderSeq>1001</orderSeq>
                  <orderStatus>1</orderStatus>
                  <cardTyp>04</cardTyp>
                  <payTime>20090605000000</payTime>
                  <payAmount>200.12</payAmount>
         </orderTrans>
         <orderTrans>
                  <orderNo>TEST0009</orderNo>
                  <orderSeq>1009</orderSeq>
                  <orderStatus>1</orderStatus>
                  <cardTyp>04</cardTyp>
                  <payTime>20090609121212</payTime>
                  <payAmount>360.00</payAmount>
         </orderTrans>

    </body>
</res>
     """
}
