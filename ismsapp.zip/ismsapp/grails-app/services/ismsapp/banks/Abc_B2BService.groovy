package ismsapp.banks

import com.hitrust.b2b.trustpay.client.XMLDocument
import com.hitrust.b2b.trustpay.client.b2b.DownloadTrnxRequest
import ismsapp.IsmsConfig
import com.hitrust.b2b.trustpay.client.b2b.QueryTrnxRequest
import com.hitrust.b2b.trustpay.client.TrxResponse

class Abc_B2BService {

    static transactional = true

    //def query(tOrderNo, tQueryType) {
    def query(tOrderNo) {
          log.info "login ...class Abc_B2BService======================================================="
        def resultMap=[]
//       tOrderNo="311308060061512756"
//        boolean tEnableDetailQuery = false;
//        if (tQueryType.equals("1"))
//            tEnableDetailQuery = true;

        //2、生成商户订单查询请求对象
        println(tOrderNo);
        def tRequest = new QueryTrnxRequest();
        tRequest.setMerchantTrnxNo(tOrderNo);  //订单号           （必要信息）
        tRequest.setMerchantRemarks("ceshi");  //是否查询详细信息 （必要信息）

        //3、传送商户订单查询请求并取得订单查询结果
        TrxResponse tTrxResponse = tRequest.postRequest();

        //4、判断商户订单查询结果状态，进行后续操作
        if (tTrxResponse.isSuccess()) {
            if(tTrxResponse==null){
                resultMap=[RESCODE:"200-01",RESMSG:"not found"]
            }
            println("TrnxType      = [" + tTrxResponse.getValue("TrnxType" ) + "]<br>");
            println("TrnxAMT  = [" + tTrxResponse.getValue("TrnxAMT" ) + "]<br>");
            println("MerchantID    = [" +tTrxResponse.getValue("MerchantID" ) + "]<br>");
            println("MerchantTrnxNo    = [" + tTrxResponse.getValue("MerchantTrnxNo") + "]<br>");
            println("ReturnCode    = [" + tTrxResponse.getValue("ReturnCode") + "]<br>");
            println("TrnxSN    = [" + tTrxResponse.getValue("TrnxSN") + "]<br>");
            println("TrnxStatus    = [" + tTrxResponse.getValue("TrnxStatus") + "]<br>");
            println("TrnxTime    = [" + tTrxResponse.getValue("TrnxTime") + "]<br>");
            def result =tTrxResponse.getValue("TrnxStatus")
             if(result!=null&&!"".equals(result)){
                   def sts=''
                    switch(result){
                            case "2":
                                sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                break;
                            default:
                                sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.NOTFOUND)
                                break;
                        }
                     resultMap=[RESCODE:"200-00",BANKCODE: 'ABC_B2B', TRXNUM:tTrxResponse.getValue("TrnxSN") , TRXAMOUNT: (tTrxResponse.getValue("TrnxAMT" ) as BigDecimal)*100 as long, TRXDATE: tTrxResponse.getValue("TrnxTime"), STS: sts]
             }else{
                resultMap=[RESCODE:"200-01",RESMSG:"not found"]
             }
        }
        else {
            //7、商户订单查询失败
            println("ReturnCode   = [" + tTrxResponse.getReturnCode() + "]<br>");
            println("ErrorMessage = [" + tTrxResponse.getErrorMessage() + "]<br>");
            resultMap=[RESCODE:"200-01",RESMSG:"not found"]
        }
    }

    /*def refund(tOrderNo, tNewOrderNo, tTrxAmount) {
        RefundRequest tRequest = new RefundRequest();
        tRequest.setOrderNo(tOrderNo);  //订单号   （必要信息）
        tRequest.setNewOrderNo(tNewOrderNo);  //新订单号   （必要信息）
        tRequest.setTrxAmount(tTrxAmount);  //退货金额 （必要信息）

        //3、传送退货请求并取得退货结果
        TrxResponse tResponse = tRequest.postRequest();

        //4、判断退货结果状态，进行后续操作
        if (tResponse.isSuccess()) {
            //5、退货成功
            println("TrxType   = [" + tResponse.getValue("TrxType") + "]<br>");
            println("OrderNo   = [" + tResponse.getValue("OrderNo") + "]<br>");
            println("NewOrderNo   = [" + tResponse.getValue("NewOrderNo") + "]<br>");
            println("TrxAmount = [" + tResponse.getValue("TrxAmount") + "]<br>");
            println("BatchNo   = [" + tResponse.getValue("BatchNo") + "]<br>");
            println("VoucherNo = [" + tResponse.getValue("VoucherNo") + "]<br>");
            println("HostDate  = [" + tResponse.getValue("HostDate") + "]<br>");
            println("HostTime  = [" + tResponse.getValue("HostTime") + "]<br>");
            println("TrnxNo    = [" + tResponse.getValue("iRspRef") + "]<br>");
        }
        else {
            //6、退货失败
            println("ReturnCode   = [" + tResponse.getReturnCode() + "]<br>");
            println("ErrorMessage = [" + tResponse.getErrorMessage() + "]<br>");
        }
        return tResponse.isSuccess();
    }

    def getSettleList(tSettleDate) {
        NumberFormat tFormat = NumberFormat.getInstance();
        tFormat.setMaximumFractionDigits(2);
        tFormat.setGroupingUsed(false);
        tFormat.setMinimumFractionDigits(2);

        //2、生成商户对账单下载请求对象
        SettleRequest tRequest = new SettleRequest();
        tRequest.setSettleDate(tSettleDate);               //对账日期YYYY/MM/DD （必要信息）
        tRequest.setSettleType(SettleFile.SETTLE_TYPE_TRX);//对账类型 （必要信息）
        //SettleFile.SETTLE_TYPE_TRX：交易对账单

        //3、传送商户对账单下载请求并取得对账单
        TrxResponse tResponse = tRequest.postRequest();

        //4、判断商户对账单下载结果状态，进行后续操作
        if (tResponse.isSuccess()) {
            //5、商户对账单下载成功，生成对账单对象
            SettleFile tSettleFile = new SettleFile(tResponse);
            println("SettleDate        = [" + tSettleFile.getSettleDate() + "]<br>");
            println("SettleType        = [" + tSettleFile.getSettleType() + "]<br>");
            println("NumOfPayments     = [" + tSettleFile.getNumOfPayments() + "]<br>");
            println("SumOfPayAmount    = [" + tFormat.format(tSettleFile.getSumOfPayAmount()) + "]<br>");
            println("NumOfRefunds      = [" + tSettleFile.getNumOfRefunds() + "]<br>");
            println("SumOfRefundAmount = [" + tSettleFile.getSumOfRefundAmount() + "]<br>");

            //6、取得对账单明细
            String[] tRecords = tSettleFile.getDetailRecords();
            for (int i = 0; i < tRecords.length; i++) {
                println("Record-" + i + " = [" + tRecords[i] + "]<br>");
            }
        }
        else {
            //7、商户账单下载失败
            println("ReturnCode   = [" + tResponse.getReturnCode() + "]<br>");
            println("ErrorMessage = [" + tResponse.getErrorMessage() + "]<br>");
        }
    }*/

    def merchantDownloadTrnx(def merchantTrnxDate){
        //1、取得下载交易记录请求所需要的信息
        //2、生成下载交易记录请求对象
        DownloadTrnxRequest tDownloadTrnxRequest = new DownloadTrnxRequest();
        tDownloadTrnxRequest.setMerchantTrnxDate(merchantTrnxDate);           //设定商户交易编号    （必要信息）
        tDownloadTrnxRequest.setMerchantRemarks("helipay");             //设定商户备注信息

        //3、传送下载交易记录请求并取得支付网址
        TrxResponse tTrxResponse = tDownloadTrnxRequest.postRequest();
        if (tTrxResponse.isSuccess()) {
            //4、下载交易记录请求提交成功
            XMLDocument tDetailRecords = new XMLDocument(tTrxResponse.getValue("TrnxDetail"));
            ArrayList tRecords = tDetailRecords.getDocuments("TrnxRecord");
            String[] iRecord = new String[tRecords.size()];
            if(tRecords.size() > 0) {
                for(int i = 0; i < tRecords.size(); i++) {
                    iRecord[i] = ((XMLDocument)tRecords.get(i)).toString();
                    println("Record-" + i + " = [" + iRecord[i] + "]<br>");
                }
            }
            else {
                out.println("<br>指定的日期里没有交易记录<br><br>");
            }
        }
        else {
            //5、下载交易记录请求提交失败，商户自定后续动作
            println("ReturnCode   = [" + tTrxResponse.getReturnCode  () + "]<br>");
            println("ErrorMessage = [" + tTrxResponse.getErrorMessage() + "]<br>");
        }
    }

}
