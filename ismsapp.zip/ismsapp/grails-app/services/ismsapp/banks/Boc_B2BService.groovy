package ismsapp.banks

import groovyx.net.http.HTTPBuilder
import ismsapp.IsmsConfig
import ismsapp.PKCS7Tool

import static groovyx.net.http.Method.GET
import static groovyx.net.http.ContentType.TEXT



class Boc_B2BService {


    static transactional = true
    def http = new HTTPBuilder("https://ebspay.boc.cn/PGWPortal/QueryOrder.do");
    def keypath=org.codehaus.groovy.grails.commons.ConfigurationHolder.config.Resource.Path
    def merchantCode =104110048991204
    def keyStorePath =keypath+"/boc/104110048991204.pfx";
    def keyStorePassword = "111111"
    def keyPassword = "111111"
    def rootCertificatePath = ""

    def query(trxnum) {
        def resultMap = []
        http.request(GET, TEXT) {req ->

            req.getParams().setParameter("http.connection.timeout", 15000)
            req.getParams().setParameter("http.socket.timeout", 15000)

            uri.query = [merchantNo: merchantCode, orderNos: trxnum, signData: getSignData(merchantCode + "|" + trxnum)]
            response.success = { resp, reader ->
                def res = reader.text;
                println res
                def rec = new XmlSlurper().parseText(res)
//                if(res?.indexOf("res") > 0 && merchantCode.equals(rec."header".merchantNo)) {
                if(res?.indexOf("res") > 0) {
                    rec."body".orderTrans.each {
                        def sts = "";
                        println "BOC return: "+it.orderStatus.text()
                        switch (it.orderStatus.text()) {
                            case ["1"]:   //success
                                sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                break;
                            case ["2", "0"]:   //failure
                                sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.FAILURE)
                                break;
                            case "4":         //uncetain
                                sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNCERTAIN)
                                break;
                            case "5":        //not found
                                sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.NOTFOUND)
                        }
                        resultMap = [RESCODE: "200-00", BANKCODE: 'BOC', MERCHANT: it.bocNo.text(),BANKSEQ:it.orderSeq.text(),
                                TRXNUM: it.orderNo.text(), TRXAMOUNT: it.payAmount.text(),STS: sts]

                    }
                }else {
                    resultMap=[RESCODE: "200-01",RESMSG:rec."header".exception]
                }
            }
        }
        return resultMap;
    }

    def getSignData(String plain) {
        try {
            return PKCS7Tool.getSigner(this.keyStorePath, keyStorePassword, keyPassword).sign(plain.getBytes());

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }



}
