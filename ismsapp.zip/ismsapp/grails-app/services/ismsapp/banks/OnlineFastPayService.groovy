//package ismsapp.banks
//
//import com.alibaba.fastjson.JSON
//import com.alibaba.fastjson.JSONObject
//import groovyx.net.http.HTTPBuilder
//import ismsapp.IsmsConfig
//import ismsapp.Md5Algorithm
//import java.security.MessageDigest
//import static groovyx.net.http.ContentType.TEXT
//import static groovyx.net.http.Method.POST
//import ismsapp.DES
//import ismsapp.MD5
//import com.sun.org.apache.xml.internal.security.utils.Base64
//import org.apache.commons.httpclient.HttpClient
//import org.apache.commons.httpclient.methods.PostMethod
//import org.apache.commons.httpclient.protocol.SecureProtocolSocketFactory
//import java.security.KeyStore
//import org.apache.commons.httpclient.protocol.Protocol
//import org.apache.commons.httpclient.params.HttpParams
//import org.apache.commons.httpclient.NameValuePair
//
//class OnlineFastPayService {
//
//
//
//    static transactional = true
//    def http = new HTTPBuilder("https://yintong.com.cn/traderapi/orderquery.htm");
//    def keypath=org.codehaus.groovy.grails.commons.ConfigurationHolder.config.Resource.Path
//    def merchantCode =201406091000001297
//   // def keyStorePath =keypath+"/boc/104110048991204.pfx";
//   // def keyStorePassword = "111111"
//   // def keyPassword = "111111"
//   // def rootCertificatePath = ""
//
//    def query(submitdate,trxnum) {
//        def resultMap = []
//        http.request(POST,TEXT ) {req ->
//
//            req.getParams().setParameter("http.connection.timeout", 15000)
//            req.getParams().setParameter("http.socket.timeout", 15000)
//
//
//            StringBuffer data=new StringBuffer("");
//
//            data.append("<?xml version=\"1.0\" encoding=\"UTF-8").append("\"?>");
//			data.append("<DATA>");
//			data.append("<TRADE>");
//			data.append("<TYPE>").append("Q")
//					.append("</TYPE>");
//			data.append("<ID>").append(trxnum).append(
//					"</ID>");
//			data.append("</TRADE>");
//			data.append("</DATA>");
//
//            String dataDES = null;
//			String signMD5 = null;
//			try {
//				dataDES = DES.encrypt(data.toString(), "YdqJnu+wrl0vDeb++OzZMpcWq9l1qEPN", "UTF-8");
//				// 计算数据签名version+merchant+terminal+data元素，MD5密钥是在商户在网银在线后台设置，签名是为了验证请求的合法性
//				signMD5 = MD5.md5("1.0.0" + "22907856"
//						+ "00000001" + dataDES, "1111qqqq");
//			} catch (Exception e) {
//				e.printStackTrace();
//				throw new RuntimeException("签名失败!");
//			}
//
//            data = new StringBuffer("");
//
//			data.append("<?xml version=\"1.0\" encoding=\"").append("UTF-8")
//					.append("\"?>");
//			data.append("<CHINABANK>");
//			data.append("<VERSION>").append(this.getVersion()).append(
//					"</VERSION>");
//			data.append("<MERCHANT>").append(this.getCorpid()).append(
//					"</MERCHANT>");
//			data.append("<TERMINAL>").append(this.getTerminal()).append(
//					"</TERMINAL>");
//			data.append("<DATA>").append(dataDES);
//			data.append("</DATA>");
//			data.append("<SIGN>").append(signMD5);
//			data.append("</SIGN>");
//			data.append("</CHINABANK>");
//
//			// String
//			// egStr="<?xml version=\"1.0\" encoding=\"UTF-8\"?><CHINABANK><VERSION>1.0.0</VERSION><MERCHANT>22907856</MERCHANT><TERMINAL>00000001</TERMINAL><DATA>U6uuI3PKfhPvh0nlVl1waLXIXf1L+bWTcxb9g6QCVMuENXNHZzepm9jwdvuz8yNjcUVdR5qTpGrZVy9jv02KG3nSgtBcKqQGpVzMQhGhOBUP0fkR8p5zvJ7Hmbq8QhqXRGnmtJcl1n1xJ4Ho1gklRiLEPxqjn/YouwHGIJyBmK1Gywkzw4KRGYeGPFGJp39VlDimD0aOomAIbq1pG4b1tDk/JX6gv7EHqOCs/JNJFWNTa2fd11oZwtoRJw/WCjKIZSjxF+4/ARS7USQeobKH4FSAXOFm41FIqk/xL1GIFkSUOKYPRo6iYLX02sNLRfBHN5DlPpmpaWOR10iJY6NgOK24XbUtU2NKH/j7bG38KiCS9XOGfti7MolvBvCw6q/xpVcfWeDA9IG9+ygQib0cto0kUDLJOiDwSffd4GGJdU7kNLKkh0lIMZVc3cEvQaC/2K2D9w9VCG9F6MnY/heO31azW4PIcS/3XuUByT03tKUxeorPUlywt1azW4PIcS/3z8O+Yl/1UhCZPt67EUjK+20mYK2r3YTz2VcvY79NihsjE6HOpmIWWHAAqtOMIVeuNw4t8QlGeOBX2mtyapCkmQcqEWf5dC3P2vCS2JcErtyWxTb8o6SwdZVc3cEvQaC/F7qSycSeyvuMUclU+gCkPg==</DATA><SIGN>d5bdd7768aa32e9f56b8bbbaa54bc228</SIGN></CHINABANK>";
//			String reqParams = Base64.encode(data.toString().getBytes());
//			// String reqParams = Base64.encode(egStr.getBytes());
//			return process("UTF-8", reqParams, getDesturl());
////            JSONObject jsonObject=(JSONObject)JSON.parse(signSf.toString());
////
////            	String sign =addSignMD5(jsonObject, "S34SD56FIFTRDEE45R6GYUGYUGFT432E");
////               jsonObject.put "sign",sign;
////             println jsonObject.toJSONString()
//
//            body = jsonObject.toString()
//            response.success = { resp, reader ->
//                def res = reader.text;
//                println res
//                if(res.toString()!=null){
//                       JSONObject rec = (JSONObject)JSON.parse(res.toString());
//
//                        if(!"0000".equals(rec.getString("ret_code"))){
//                                resultMap=[RESCODE: "200-01",RESMSG:rec.getString("ret_msg")]
//                        }else{
//                        def merchantNo=rec.getString("oid_partner");
//                        def bankSeq=rec.getString("oid_paybill");
//                        def trxNum=rec.getString("no_order");
//                        def transAmount=rec.getString("money_order");
//                        def result=rec.getString("result_pay");
//                        def sts="";
//                        switch (result) {
//                            case "SUCCESS":   //success
//                                sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
//                                break;
//                            case "WAITING":   //failure
//                                sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNPAID)
//                                break;
//                            case "PROCESSING":         //uncetain
//                                sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNCERTAIN)
//                                break;
//                            case "REFUND":        //not found
//                                sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNPAID)
//                            case "FAILURE":        //not found
//                                sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNCERTAIN)
//                        }
//
//                         resultMap = [RESCODE: "200-00", BANKCODE: 'YINTONG', MERCHANT: merchantNo,BANKSEQ:bankSeq,
//                                TRXNUM: trxNum, TRXAMOUNT: transAmount,STS: sts]
//                        }
//                }else{
//                      resultMap=[RESCODE: "200-01",RESMSG:"not found"]
//                }
//
//            }
//        }
//        return resultMap;
//    }
//
//    public String process(String charset, String req, String reqUrl)
//            {
//        String resp = null;
//        HttpClient httpClient = null;
//        // HttpPost httpPost = null;
//        PostMethod post = null;
//        InputStream in = null;
//        String dataDES = null;
//        StringBuffer respBuffer = new StringBuffer("");
//        try {
//            httpClient = new HttpClient();
//            post = new PostMethod(getDesturl());
//
//            if (reqUrl.indexOf("https") != -1) {
//                SecureProtocolSocketFactory protoSocketFactory = new ClientAndServerAuthSSLSocketFactory(
//                        new URL("file:" + jkspath), "chinabank", KeyStore
//                                .getDefaultType(), new URL("file:" + jkspath),
//                        "chinabank", KeyStore.getDefaultType());
//                Protocol authhttps = new Protocol("https", protoSocketFactory,
//                        443);
//                // httpClient.getHostConfiguration().setHost("quick.chinabank.com.cn",
//                // 443, authhttps);
//                Protocol.registerProtocol("https", authhttps);
//            }
//
//            HttpParams httpParams = httpClient.getParams();
//            httpParams.setIntParameter(HttpConnectionParams.CONNECTION_TIMEOUT,
//                    1000 * 60);
//            httpParams.setIntParameter(HttpConnectionParams.SO_TIMEOUT,
//                    1000 * 60);
//            post.addParameter(new NameValuePair("charset", charset));
//            post.addParameter(new NameValuePair("req", req));
//
//            int response = httpClient.executeMethod(post);
//
//            byte[] responseData = post.getResponseBody();
//            resp = new String(responseData, charset);
//
//            if (post.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
//                throw new Exception(post.getStatusLine().toString() + "|"
//                        + resp);
//            }
//
//            String temResp = resp.substring(resp.indexOf("=") + 1);
//
//            // 快捷支付数据先base64解码
//            temResp = new String(Base64.decode(temResp));
//            Map<String, String> respParams = ebank.web.common.util.XmlMsg
//                    .parse(temResp);
//            // System.out.println("版本号|商户号|终端号|交易数据|数据签名"
//            // +respParams.get("chinabank.version")+"|"+respParams.get("chinabank.merchant")+"|"+respParams.get("chinabank.terminal")+"|"
//            // +respParams.get("chinabank.data")+"|"+respParams.get("chinabank.sign"));
//            // //验证数据签名的合法性。版本号+商户号+终端号+交易数据使用md5加密和数据签名比较，md5密钥在网银在线商户后台设置
//            if (MD5.verify(respParams.get("chinabank.version")
//                    + respParams.get("chinabank.merchant")
//                    + respParams.get("chinabank.terminal")
//                    + respParams.get("chinabank.data"), getMd5(), respParams
//                    .get("chinabank.sign"))) {
//
//                // 使用DES解密data交易数据,des密钥网银在线商户后台设置
//                dataDES = DES.decrypt(respParams.get("chinabank.data"),
//                        getDes(), respParams.get("xml.charset"));
//                Map<String, String> dataParams = XmlMsg.parse(dataDES);
//                respBuffer.append("<data>");
//                respBuffer.append("<tradeType>").append(
//                        dataParams.get("data.trade.type")).append(
//                        "</tradeType>");
//                respBuffer.append("<transId>").append(
//                        dataParams.get("data.trade.id")).append("</transId>");
//                respBuffer.append("<totalFee>").append(
//                        Amount.getFormatAmount(dataParams.get("data.trade.amount"), -2)).append(
//                        "</totalFee>");
//                respBuffer.append("<currency>").append(
//                        dataParams.get("data.trade.currency")).append(
//                        "</currency>");
//                if ("S".equals(dataParams.get("data.trade.type"))) {// 消费专用参数
//                    respBuffer.append("<date>").append(
//                            dataParams.get("data.trade.date"))
//                            .append("</date>");
//                    respBuffer.append("<time>").append(
//                            dataParams.get("data.trade.time"))
//                            .append("</time>");
//                    respBuffer.append("<note>").append(
//                            dataParams.get("data.trade.note") == null ? ""
//                                    : dataParams.get("data.trade.note"))
//                            .append("</note>");
//                    respBuffer.append("<status>").append(
//                            dataParams.get("data.trade.status")).append(
//                            "</status>");
//                }
//
//                respBuffer.append("<code>").append(
//                        dataParams.get("data.return.code")).append("</code>");
//                // 支付结果描述暂时屏蔽
//                // respBuffer.append("<desc>").append(
//                // dataParams.get("data.return.desc")).append("</desc>");
//                // respBuffer.append("</data>");
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            return resp;
//            // throw new ServiceException("交易失败!");
//        } finally {
//            try {
//                if (in != null) {
//                    in.close();
//                }
//                post.releaseConnection();
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//
//        return respBuffer.toString();
//    }
//
//
//     String addSignMD5(JSONObject reqObj, String md5_key)
//     {
//         System.out.println("进入商户[" + reqObj.getString("oid_partner")
//                 + "]MD5加签名");
//         if (reqObj == null)
//         {
//             return "";
//         }
//         // 生成待签名串
//         String sign_src = genSignData(reqObj);
//         System.out.println("商户[" + reqObj.getString("oid_partner") + "]加签原串"
//                 + sign_src);
//         sign_src += "&key=" + md5_key;
//         try
//         {
//             return Md5Algorithm.getInstance().md5Digest(
//                     sign_src.getBytes("utf-8"));
//         } catch (Exception e)
//         {
//             System.out.println("商户[" + reqObj.getString("oid_partner")
//                     + "]MD5加签名异常" + e.getMessage());
//             return "";
//         }
//     }
//
//
//     String genSignData(JSONObject jsonObject)
//    {
//        StringBuffer content = new StringBuffer();
//
//        // 按照key做首字母升序排列
//        List<String> keys = new ArrayList<String>(jsonObject.keySet());
//        Collections.sort(keys, String.CASE_INSENSITIVE_ORDER);
//        for (int i = 0; i < keys.size(); i++)
//        {
//            String key = (String) keys.get(i);
//            if ("sign".equals(key))
//            {
//                continue;
//            }
//            String value = jsonObject.getString(key);
//
//            content.append((i == 0 ? "" : "&") + key + "=" + value);
//
//        }
//        String signSrc = content.toString();
//        if (signSrc.startsWith("&"))
//        {
//            signSrc = signSrc.replaceFirst("&", "");
//        }
//        return signSrc;
//    }
//
////    public boolean verify(String signData, String plain) {
////        try {
////            PKCS7Tool tools = PKCS7Tool.getVerifier(rootCertificatePath);
////            if (tools != null) {
////                tools.verify(signData, plain.getBytes(), this.dn);
////                return true;
////            }
////        } catch (Exception e) {
////            e.printStackTrace();
////        }
////        return false;
////
////    }
//      String MD5(String s) {
//	        char[]  hexDigits = [ '0','1', '2', '3', '4', '5', '6', '7', '8', '9','A', 'B', 'C', 'D', 'E', 'F' ];
//	        try {
//	            byte[] btInput = s.getBytes();
//	            //获得MD5摘要算法的 MessageDigest 对象
//	            MessageDigest mdInst = MessageDigest.getInstance("MD5");
//	            //使用指定的字节更新摘要
//	            mdInst.update(btInput);
//	            //获得密文
//	            byte[] md = mdInst.digest();
//	            //把密文转换成十六进制的字符串形式
//	            int j = md.length;
//	            char[]  str= new char[j * 2];
//	            int k = 0;
//	            for (int i = 0; i < j; i++) {
//	                byte byte0 = md[i];
//	                str[k++] = hexDigits[byte0 >>> 4 & 0xf];
//	                str[k++] = hexDigits[byte0 & 0xf];
//	            }
//	            return new String(str).toLowerCase();
//	        }
//	        catch (Exception e) {
//	            e.printStackTrace();
//	            return null;
//	        }
//	    }
//
//    def printXml() {
//        def rec = new XmlSlurper().parseText(teststr)
//        println rec."header".merchantNo;
//        rec."body".orderTrans.each {
//            println it.orderNo;
//        }
//    }
//
//    def teststr = """<?xml version="1.0" encoding="utf-8" ?>
//<res>
//    <header>
//         <merchantNo>104110041000000</merchantNo>
//    </header>
//    <body>
//         <orderTrans>
//                  <orderNo>TEST0001</orderNo>
//                  <orderSeq>1001</orderSeq>
//                  <orderStatus>1</orderStatus>
//                  <cardTyp>04</cardTyp>
//                  <payTime>20090605000000</payTime>
//                  <payAmount>200.12</payAmount>
//         </orderTrans>
//         <orderTrans>
//                  <orderNo>TEST0009</orderNo>
//                  <orderSeq>1009</orderSeq>
//                  <orderStatus>1</orderStatus>
//                  <cardTyp>04</cardTyp>
//                  <payTime>20090609121212</payTime>
//                  <payAmount>360.00</payAmount>
//         </orderTrans>
//
//    </body>
//</res>
//     """
//}
