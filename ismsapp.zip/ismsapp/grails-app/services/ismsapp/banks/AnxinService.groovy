/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ismsapp.banks

import groovyx.net.http.HTTPBuilder
import static groovyx.net.http.Method.GET
import static groovyx.net.http.ContentType.TEXT
import ismsapp.IsmsConfig
import ismsapp.XmlUtils
import anxin.Anxin
import groovyx.net.http.ContentType
import java.text.SimpleDateFormat;
import java.util.Date;
import com.anxin.ipg.util.MD5;
import org.w3c.dom.Document;
/**
 *
 * @author edward
 */
class AnxinService
{
    static transactional = true
    def http = new HTTPBuilder("http://netpay.anxin1688.com/anxin.pay")
    def merchantCode ="888816880001001"
    def serviceType="t0_query"
    def keyStr="NA9SDWYHEO3984G59W38GT"

    def query(trxnum, orderdate, amount, trxsts) {
        def resultMap = [];
        String signTime = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String plain = serviceType+merchantCode+trxnum+orderdate+signTime;
        http.request(GET, TEXT) {req ->
            
            req.getParams().setParameter("http.connection.timeout", 15000)
            req.getParams().setParameter("http.socket.timeout", 15000)

            requestContentType = ContentType.URLENC
            uri.query = [service:serviceType,mer_id:merchantCode,order_id:trxnum,order_date:orderdate,sign_time: signTime,sign_type:"1",sign_value:getSignData(plain.concat(keyStr))]
            response.success = { resp, reader ->
                String res = reader.text;
                res = res.replaceAll("  ","").replaceAll("\"","'");
                def rec = new XmlSlurper().parseText(res)
                println "anxin return : "+res
                Document sDoc = XmlUtils.getDocument(res);
                if(sDoc!=null)
                {
                    def sts = "";
                    if("SUCCESS".equals(XmlUtils.getNodeValue(sDoc,"ret_code")))
                    {
                        String signString = XmlUtils.getNodeValue(sDoc,"ax_order_id")==null?"":XmlUtils.getNodeValue(sDoc,"ax_order_id")
                                .concat(XmlUtils.getNodeValue(sDoc,"mer_id"))
                                .concat(XmlUtils.getNodeValue(sDoc,"order_id"))
                                .concat(XmlUtils.getNodeValue(sDoc,"order_date"))
                                .concat(XmlUtils.getNodeValue(sDoc,"trans_amt"))
                                .concat(XmlUtils.getNodeValue(sDoc,"order_status"))
                                .concat(XmlUtils.getNodeValue(sDoc,"trans_time"));

                        println "signString:"+signString
                        
                        String chkValue = XmlUtils.getNodeValue(sDoc,"sign_value");
                        String verifySign = Anxin.toStr(signString.concat(keyStr));
                        println "sign_value:"+chkValue+"======================verifySign:"+verifySign
                        if(verifySign.equalsIgnoreCase(chkValue))
                        {
                            String SettDate = XmlUtils.getNodeValue(sDoc,"trans_time");
                            String orderId = XmlUtils.getNodeValue(sDoc,"order_id");
                            String TranAmt = XmlUtils.getNodeValue(sDoc,"trans_amt");
                            String orderStatus = XmlUtils.getNodeValue(sDoc,"order_status");
                            switch (orderStatus)
                            {
                                case ["0"]:   //success
                                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                    break;
                                case ["1"]:   //failure
                                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.FAILURE)
                                    break;
                                case ["D"]:   //uncertain
                                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNCERTAIN)
                                    break;
                                case ["F"]:   //unpaid
                                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.UNPAID)
                                    break;
                            }
                            resultMap = [RESCODE: "200-00", BANKCODE: 'PREPAYCARD', TRXNUM: orderId, TRXAMOUNT: TranAmt,STS: sts]
                        }
                    }
                    if("ILLEGAL_SIGN".equalsIgnoreCase(XmlUtils.getNodeValue(sDoc,"ret_code")))
                    {
                        resultMap=[RESCODE: "200-01",RESMSG:XmlUtils.getNodeValue(sDoc,"ret_code")]
                    }
                }else{
                    resultMap=[RESCODE: "200-01",RESMSG:rec."header".exception]
                }

            }
        }
        println resultMap;
        return resultMap;
    }
    def getSignData(String plain) {
        try {
            println plain;
            String sign = Anxin.toStr(plain);
            println sign;
            return sign;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}

