package ismsapp.banks

import org.apache.commons.httpclient.methods.PostMethod
import org.apache.commons.httpclient.params.HttpMethodParams
import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler
import org.apache.commons.httpclient.protocol.Protocol
import ext.AuthSSLProtocolSocketFactory
import org.apache.commons.httpclient.NameValuePair
import org.apache.commons.httpclient.HttpClient
import org.apache.commons.httpclient.methods.GetMethod
import org.w3c.dom.Document
import ismsapp.IsmsConfig
import org.apache.jasper.tagplugins.jstl.core.Url
import ismsapp.XmlUtils

class IcbcService {

    static transactional = true
    def keypath=org.codehaus.groovy.grails.commons.ConfigurationHolder.config.Resource.Path
    def jkspwd ="12345678";
    def jkspath =keypath+"/icbc/icbc.jks";

     def query(trxnum,orderdate) {
        def resultMap=[];
        String result="";
        PostMethod method=new PostMethod();
        HttpClient client=new HttpClient();
        Protocol myhttps=null;
         //指定请求内容的类型
        method.setRequestHeader("Content-type", "text/xml; charset=GB2312");
        method.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new DefaultHttpMethodRetryHandler());
        String bankHost = "https://corporbank.icbc.com.cn/servlet/ICBCINBSEBusinessServlet";
        try{
               URL url=new URL(bankHost);
               method.setPath(url.getPath());
               if(bankHost.indexOf("https")==0){//https
                  if(myhttps==null)
                        myhttps = new Protocol("https",
                                                       new AuthSSLProtocolSocketFactory(
                                                       new URL("file:///"+this.jkspath), this.jkspwd,
                                                       new URL("file:///"+this.jkspath), this.jkspwd), 443);
                        client.getHostConfiguration().setHost(url.getHost(), 443, myhttps);
               }else {
                   	client.getHostConfiguration().setHost(url.getHost(),80,url.getProtocol());
               }
               StringBuilder sb = new StringBuilder();
               sb = this.getPerMap(bankHost,trxnum,orderdate);

                  method.setQueryString([
					new NameValuePair("APIName","EAPI"),
					new NameValuePair("APIVersion","001.001.002.001"),
					new NameValuePair("MerReqData",sb.toString())
			        ] as  NameValuePair[]);
                log.info("MerReqData ["+ sb.toString() +"]");
               log.info("query string["+method.getQueryString()+"]");
               int rescode=client.executeMethod(method);
               if(rescode==200){
                    BufferedReader reader=new BufferedReader(new InputStreamReader(method.getResponseBodyAsStream()));
                    String curline="";
                    while((curline=reader.readLine())!=null){
                        result+=curline;
                    }
                    log.debug("reponse:"+result);
                    if(result!=null){
                         result = URLDecoder.decode(result,"gbk")
                           log.info "result-------------------------"+result;
                         if(result.indexOf("<?xml")==0){
                           Document doc=XmlUtils.getDocument(result);
                           if(doc==null)resultMap=[RESCODE: "200-01",RESMSG:"not found"];
                           String status = XmlUtils.getNodeValue(doc,"tranStat");
                            def sts = "";
                            switch(status){
                                case "0":
                                    sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                    break;
                                case "1":
                                    sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                    break;
                                 case "3":
                                    sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.FAILURE)
                                    break;
                                default:
                                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.FAILURE)
                                    break;
                            }
                               log.info "status-------------------------"+status;
                            resultMap=[RESCODE:"200-00",BANKCODE: 'ICBC', TRXNUM:XmlUtils.getNodeValue(doc,"orderNum") , TRXAMOUNT: IsmsConfig.getFormatAmount(XmlUtils.getNodeValue(doc,"amount"), -2), TRXDATE: XmlUtils.getNodeValue(doc,"tranDate"), STS: sts]
                          }else{
                         resultMap=[RESCODE: "200-01",RESMSG:"not found"]
                      }
                    }else{
                        resultMap=[RESCODE: "200-01",RESMSG:"not found"]
                    }
                }else{
                    log.error("icbc error:"+rescode);
                   resultMap=[RESCODE: "200-01",RESMSG:"not found"]
                }
            }catch (Exception e) {
                 e.printStackTrace();
                 resultMap=[RESCODE: "200-01",RESMSG:"not found"]
            }finally{
                 method.releaseConnection();
            }
           return resultMap;
     }

        def getPerMap(def url,def trxnum,def orderdate){

            StringBuilder sb = new StringBuilder();
            sb.append("<?xml version=\"1.0\" encoding=\"GBK\" standalone=\"no\"?>") ;
            sb.append("<ICBCAPI>") ;
            sb.append("<in>") ;
            sb.append("<orderNum>").append(trxnum).append("</orderNum>") ;
            sb.append("<tranDate>").append(orderdate).append("</tranDate>") ;
            sb.append("<ShopCode>").append("0200EC23805744").append("</ShopCode>") ;
            sb.append("<ShopAccount>").append("0200080919200210730").append("</ShopAccount>") ;
            sb.append("</in>") ;
            sb.append("</ICBCAPI>") ;
        return sb
      }
}
