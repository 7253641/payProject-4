package ismsapp.banks

import refund.TradeBase
import java.text.SimpleDateFormat
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.KeyStore;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils
import ismsapp.Gwtrxs
import net.sf.json.JSONObject;
import java.util.Random;
import com.psbc.payment.client.SignatureService
import ismsapp.IsmsConfig
import org.w3c.dom.Document
import ismsapp.XmlUtils


class PsbcService {
    def keypath=org.codehaus.groovy.grails.commons.ConfigurationHolder.config.Resource.Path

    static transactional = true

     def query(trxnum) {
        //构造相应的form表单，提给预付费卡系统。进行退款
        def resultMap=[]
        def urlStr = "https://pbank.psbc.com/payment/main"
        String result = "-20";
        StringBuilder sb = new StringBuilder();
        sb = this.getSelectPerMap(urlStr,trxnum)
        DefaultHttpClient httpclient = new DefaultHttpClient();
	    try {
	        KeyStore trustStore  = KeyStore.getInstance(KeyStore.getDefaultType());
	        FileInputStream instream = new FileInputStream(new File(keypath+"/psbc/psbc.jks"));
	        try {
	             trustStore.load(instream, "111111".toCharArray());
	         } finally {
	             try { instream.close(); } catch (Exception ignore) {}
	         }
	         SSLSocketFactory socketFactory = new SSLSocketFactory(trustStore);
	         Scheme sch = new Scheme("https", 443, socketFactory);
	         httpclient.getConnectionManager().getSchemeRegistry().register(sch);
	         HttpGet httpget = new HttpGet(sb.toString());
	         System.out.println("executing request" + httpget.getRequestLine());
	         HttpResponse response = httpclient.execute(httpget);
	         HttpEntity entity = response.getEntity();
	         System.out.println("----------------------------------------");
	         System.out.println(response.getStatusLine());
	         String retStr = "";
	         if (entity != null) {
	            InputStream instream2 = entity.getContent();
	             try {
	                BufferedReader reader = new BufferedReader( new InputStreamReader(instream2));
	                retStr = reader.readLines();
	               } catch (IOException ex) {
	                    throw ex;
	              } catch (RuntimeException ex) {
	                    throw ex;

	              } finally {
	                 instream2.close();
	              }
	            }else{
                        resultMap=[RESCODE:"200-01",RESMSG:"not found"]
                    }
	            System.out.println("自动对账返回信息："+retStr);
                    if(retStr.contains(",")){
                              retStr = retStr.replace(',','');
                    }
                    if(retStr.contains("[")){
                          retStr = retStr.replace('[','');
                    }
                   if(retStr.contains("]")){
                              retStr = retStr.replace(']','');
                    }
	           if(retStr!=null){
                         if(retStr.indexOf("<?xml")==0){
                           Document doc=XmlUtils.getDocument(retStr);
                           if(doc!=null){
                                if(retStr.contains("Plain")){
                                     String plain = XmlUtils.getNodeValue(doc,"Plain");
                                       String signature = XmlUtils.getNodeValue(doc,"Signature");
                                        def sts = "";
                                       if (SignatureService.verify(plain, signature)) {//页签通过
                                           String[] str = plain.split("\\|");
                                           String status = "";
                                           String orderID = "";
                                           String amount="";
                                           String transdate="";
                                               for(int i=0;i<str.size();i++){
                                                   String[] aa = str[i].split("=")
                                                   if(aa.length>1){
                                                     if(aa[0].equals("CompFlag")){
                                                         status = aa[1];
                                                     }
                                                      if(aa[0].equals("TermSsn")){
                                                         orderID = aa[1];
                                                     }
                                                      if(aa[0].equals("TranAmt")){
                                                         amount = aa[1];
                                                     }
                                                      if(aa[0].equals("SettDate")){
                                                         transdate = aa[1];
                                                     }

                                                   }
                                               }
                                               switch(status){
                                                case "00":
                                                    sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.SUCCESS)
                                                    break;
                                                case "01":
                                                    sts=IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.FAILURE)
                                                    break;
                                                default:
                                                    sts = IsmsConfig.getTrxsts(IsmsConfig.TrxSTS.FAILURE)
                                                    break;
                                            }
                                            resultMap=[RESCODE:"200-00",BANKCODE: 'PSBC', TRXNUM:orderID, TRXAMOUNT: amount, TRXDATE: transdate, STS: sts]
                                         }else{
                                           resultMap=[RESCODE: "200-01",RESMSG:"not found"]
                                         }
                                }else{
                                  resultMap=[RESCODE: "200-01",RESMSG:"not found"];
                                }
                          
                           }else{
                               resultMap=[RESCODE: "200-01",RESMSG:"not found"];
                           }
                          }else{
                         resultMap=[RESCODE: "200-01",RESMSG:"not found"]
                      }
                   }else{
                        resultMap=[RESCODE: "200-01",RESMSG:"not found"]
                    }
	        } finally {
	            httpclient.getConnectionManager().shutdown();
	        }
         return resultMap

    }


     def getSelectPerMap(def url,def trxnum){
            StringBuilder sb = new StringBuilder();
            String plain = "OTranAbbr=IPER|MercCode=9999998885000004100|TermSsn="+trxnum;
            String sign = SignatureService.sign(plain);
            sb.append(url+"?");
            sb.append("transName=").append("IQSR");
            sb.append("&Plain=").append(URLEncoder.encode(plain));
            sb.append("&Signature=").append(sign);
        return sb
   }


}

