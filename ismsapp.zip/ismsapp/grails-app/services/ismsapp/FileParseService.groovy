package ismsapp

import org.apache.poi.hssf.usermodel.HSSFWorkbook

class FileParseService {

    static transactional = true

    def parsefile(bankname, reader) {
        def list = [];
        def ASCII_SPLITER = 124; // |124
        def SKIP_LINES = 0;
        def SKIP_HORLINE = true;
        def INDEX = [];
        def DATA_SZ = 0;
        def CHECK_SZ = false;
        def ADD_ITEM = false;
        def REGEX = /[0-9]/; /*"消"; */
        def MERCHANTID='000000'
        switch (bankname) {
            case "CEB":
                INDEX = [1, 4, 5];
                DATA_SZ = 10;
                CHECK_SZ = true;
                REGEX = /['|']/
                break;
            case "CMB":
                INDEX = [3, 2, 0];
                ASCII_SPLITER = 44;
                MERCHANTID='000099'
             break;
            case "ICBC":
                INDEX = [1, 3, 4];
                break;
            case "CCB":
                REGEX = /['支']/;
                CHECK_SZ = true;
                DATA_SZ = 13;
                INDEX = [3, 5, 1];
                break;
            case "CMBC":
                INDEX = [2, 3, 0];
                break;
            case "BOC":
                INDEX = [1, 6, 4];
                SKIP_LINES = 1;
                break;
            case "ABC":
                INDEX = [0, 10, 3];
                ASCII_SPLITER = 94;
                break;
            case "SPDB":
                INDEX = [5, 2, 1];
                REGEX = /['消']/;
                break;
            case "HXB":
                INDEX = [1, 3, 4];
                break;
            case "CITIC":
                INDEX = [0, 7, 2];
                break;
            case "HSBC":
                INDEX = [0, 3, 1];
                ADD_ITEM = true;
                break;
            case "CIB":
                INDEX = [3, 5, 9];
                break;
            case "CIB0":
                INDEX = [2, 4, 0];
                bankname = "CIB";
                break;
            case "GDB":
                INDEX = [1, 4, 2];
                break;
            case "SDB":
                INDEX = [0, 5, 3];
                break;

        }
        reader.eachLine {line ->
            if (SKIP_HORLINE) line = line.replace(String.valueOf((char) 9), ' ');
            if (line.length() > 0 && line.replace(' ', '').length() > 0) {
                if (line.length() > 0 && line.replace(' ', '').substring(0, 1) ==~ REGEX) {
                    def linelist = [];
                    line.replace(String.valueOf((char) ASCII_SPLITER), ' ').split(' ').each {
                        if (it != '') {
                            linelist << it
                        }
                    }

                    if (ADD_ITEM) linelist << "0.00";
                    list << linelist;
                }
            }
        }
        //println list;
        if (list.size() > SKIP_LINES && SKIP_LINES > 0) (1..SKIP_LINES).each {list.remove(it - 1)};
        def trxlist=[];
        list.each{
            if((it.size()==DATA_SZ&&CHECK_SZ)||!CHECK_SZ){
                //['UNIONPAY',it.@OrderId.text(),(it.@TransAmt.text() as BigDecimal).movePointLeft(2) ,decode(it.@TransState.text()),it.@MerId.text(),it.@CpDate.text(),it.@CpSeqId.text()]
                trxlist<<[bankname,${it[INDEX[0]]},${it[INDEX[1]].replaceAll(',','') as BigDecimal},1,MERCHANTID,${it[INDEX[2]].replace('-','').replace('/','').replace('年','').replace('月','').replace('日','').substring(0,8)},0]
             }
      	}
        return list;

    }


     def parseTxt(bankCode,reader) {

        def SKIP_LINES = 0;
        /*收单商户号，订单号，金额，交易时间，交易状态,交易类型,记账日期,商户账号*/
        def INDEX = [:];
        def SPLITCHAR = '|'
        def TRADE_DATEFORMAT = 'yyyyMMddHHmmss';
        def ACCOUNT_DATEFORMAT = 'yyyyMMdd';
        def SUCCESS_TAG=[]
        def TRADE_TYPE=[]
        def FINAL_LINE=0
        switch (bankCode) {
            case ['icbc','ICBC']:      //工行
                SKIP_LINES=4
                SPLITCHAR = ' '
                INDEX = [7:0,1:1,2:3,3:[4,5],4:6,5:7]
                TRADE_DATEFORMAT = 'yyyy-MM-ddHH:mm'
                TRADE_TYPE =['未经退货']
                SUCCESS_TAG=['支付成功已清算']
                break;
            case ['cncb','CNCB']:       //中信
                SKIP_LINES=1
                SPLITCHAR = '|'
                INDEX = [1:0,3:2,2:5,6:1];
                TRADE_DATEFORMAT = 'yyyy-MM-dd-HH:mm:ss'
                ACCOUNT_DATEFORMAT = 'yyyy-MM-dd'
                break;
             case ['boc','BOC']:             //中行
                SKIP_LINES=0
                SPLITCHAR = '|'
                INDEX = [0:0,1:1,3:3,2:5,4:8,6:2];
                TRADE_DATEFORMAT = 'yyyyMMddHHmmss'
                ACCOUNT_DATEFORMAT = 'yyyyMMddHHmmss'
                SUCCESS_TAG=['1','0']
                break;
             case ['ccb','CCB']:             //建行
                SKIP_LINES=4
                SPLITCHAR = '\t'
                INDEX = [1:1,2:3,3:0,4:9,5:4,6:10]
                TRADE_DATEFORMAT = 'yyyy-MM-dd HH:mm:ss'
                ACCOUNT_DATEFORMAT = 'yyyyMMdd'
                TRADE_TYPE =['0.00']
                SUCCESS_TAG=['成功']
                break;
             case ['spdb','SPDB']:         //浦发银行
                SKIP_LINES=0
                SPLITCHAR = '|'
                INDEX = [0:3,1:5,2:2,3:1,4:[7,8],5:0,6:9];
                TRADE_DATEFORMAT = 'yyyy/MM/dd'
                ACCOUNT_DATEFORMAT = 'yyyy/MM/dd'
                TRADE_TYPE =['消费']
                SUCCESS_TAG=['00','00']
                break;
             case ['bocom','BOCOM','HSBC']:         //交行
                SKIP_LINES=1
                SPLITCHAR = '\t '
                INDEX = [7:9,1:0,2:4,3:[5,6],4:3,5:2,6:1];
                TRADE_DATEFORMAT = 'yyyyMMddHHmmss'
                ACCOUNT_DATEFORMAT = 'yyyyMMdd'
                TRADE_TYPE =['已支付']
                SUCCESS_TAG=['成功']
                break;

             case ['psbc','PSBC']:         //邮储
                SKIP_LINES=0
                SPLITCHAR = ','
                INDEX = [1:1,2:2,3:0,4:4,5:3];
                TRADE_DATEFORMAT = 'yyyy-MM-dd HH:mm:ss'
                TRADE_TYPE =['支付']
                SUCCESS_TAG=['成功']
                break;
            case ['alipay','ALIPAY']:         //支付宝
                SKIP_LINES=5
                SPLITCHAR = ' +'
                INDEX = [1:1,2:9,3:[2,3],4:11,5:6,6:[4,5]];
                TRADE_DATEFORMAT = 'yyyy-MM-ddHH:mm:ss'
                ACCOUNT_DATEFORMAT = 'yyyy-MM-ddHH:mm:ss'
                TRADE_TYPE =['其他（包括阿里巴巴和外部商家）即时到账交易']
                SUCCESS_TAG=['交易成功可以退款']
                FINAL_LINE=1
                break;
        }
         int i= 0

         def trxlist=[];

//          reader.eachLine {line ->
//              i++
//              if(line){
//                 if(i>SKIP_LINES){
//                     def it = [];
//                     it = line.tokenize(SPLITCHAR)
//                       if(it[INDEX[FINAL_LINE]]!=null){
//                          println INDEX[5]
//                          println it[INDEX[5]].toString().trim()
//                          println TRADE_TYPE[0]
//                          if(INDEX[5]==null||it[INDEX[5]].toString().trim()==TRADE_TYPE[0]){
//                              it = line.tokenize(SPLITCHAR)
//                              println it[INDEX[5]].toString().trim()
//                           }
//                       }
//                   }
//              }
//          }

         reader.eachLine {line ->
           i++
           if(line){
           if(i>SKIP_LINES){
               def it = [];
               it = line.tokenize(SPLITCHAR)
//              println "INDEX FINAL_LINE ${it[FINAL_LINE]}"

               if(it[FINAL_LINE]!=null){
                 if(INDEX[5]==null||it[INDEX[5]].toString().trim()==TRADE_TYPE[0]){
                   def trxMap=[:]
                   trxMap['acquireMerchant']  =  INDEX[0]!=null?it[INDEX[0]].toString().trim():''
                   trxMap['bankAccountNo']  =  INDEX[7]!=null?it[INDEX[7]].toString().trim():''
                   trxMap['trxid'] =  INDEX[1]!=null?it[INDEX[1]]:''
//                   println "trxMap trxid ${trxMap['trxid']}"
                   trxMap['amount']   =  (INDEX[2]!=null?it[INDEX[2]].toString().trim().replaceAll(',',''):'0.00') as BigDecimal
                   def datex
                       if(INDEX[3] instanceof ArrayList){
                           datex=it[INDEX[3][0]].toString().trim()+it[INDEX[3][1]].toString().trim()
                       } else{
                           datex=it[INDEX[3]].toString().trim()
                       }

                   trxMap['acquireDate']  = Date.parse(TRADE_DATEFORMAT, datex)
                    def trxstsk ;
                    if(INDEX[4]!=null){
                        if(INDEX[4] instanceof ArrayList){
                            if(it[INDEX[4][0]].toString().trim()==SUCCESS_TAG[0]&&it[INDEX[4][1]].toString().trim()==SUCCESS_TAG[1]){
                                trxstsk=1
                            }else{trxstsk=2}
                          }else{
                              if(it[INDEX[4]].toString().trim()==SUCCESS_TAG[0]){
                                   trxstsk=1
                              }else if(it[INDEX[4]].toString().trim()==SUCCESS_TAG[1]){
                                   trxstsk=0
                              }else{
                                  trxstsk=2
                              }
                          }
                     }else{
                        trxstsk=1
                    }
                   trxMap['trxsts']  = trxstsk

                   if(INDEX[6]!=null){
                       if(INDEX[6] instanceof ArrayList){
                          datex=it[INDEX[6][0]].toString().trim()+it[INDEX[6][1]].toString().trim()
                      } else{
                          datex=it[INDEX[6]].toString().trim()
                      }
                      trxMap['accountDate']  = Date.parse(ACCOUNT_DATEFORMAT, datex)
                   } else{
                      trxMap['accountDate']  = null
                   }

                   trxlist<< trxMap
                 }
           }
           }
           }
         }
         println trxlist
         println trxlist.size()
         return trxlist
     }

     def parseCsv(bankCode,reader) {
        def SKIP_LINES = 0;
        /*收单商户号，订单号，金额，交易时间，交易状态,交易类型,记账日期,商户账号*/
        def INDEX = [:];
        def SPLITCHAR = '|'
        def TRADE_DATEFORMAT = 'yyyyMMddHHmmss';
        def ACCOUNT_DATEFORMAT = 'yyyyMMdd';
        def SUCCESS_TAG=[]
        def TRADE_TYPE=[]
        def FINAL_LINE=0
        switch (bankCode) {
            case ['alipay','ALIPAY']:         //支付宝
                SKIP_LINES=5
                SPLITCHAR = '\t,'
                INDEX = [1:1,2:8,3:2,4:10,5:5,6:3]
                TRADE_DATEFORMAT = 'yyyy-MM-dd HH:mm:ss'
                ACCOUNT_DATEFORMAT = 'yyyy-MM-dd HH:mm:ss'
                TRADE_TYPE =['即时到账交易']
                SUCCESS_TAG=['交易成功可以退款']
                FINAL_LINE=1
                break;
        }
         int i= 0

         def trxlist=[];
//
//          reader.eachLine {line ->
//              i++
//              if(line){
//                 if(i>SKIP_LINES){
//                     def it = [];
//                     it = line.tokenize(SPLITCHAR)
//                       if(it[INDEX[FINAL_LINE]]!=null){
////                          println INDEX[5]
////                          println it[INDEX[5]]
////                          println TRADE_TYPE[0]
//                          if(INDEX[5]==null||it[INDEX[5]].toString().trim()==TRADE_TYPE[0]){
//                              it = line.tokenize(SPLITCHAR)
//                              println it[INDEX[5]]
//                           }
//                       }
//                   }
//              }
//          }

         reader.eachLine {line ->
           i++
           if(line){
           if(i>SKIP_LINES){
               def it = [];
               it = line.tokenize(SPLITCHAR)

                 if(INDEX[5]==null||it[INDEX[5]].toString().trim()==TRADE_TYPE[0]){
                   def trxMap=[:]
                   trxMap['acquireMerchant']  =  INDEX[0]!=null?it[INDEX[0]].toString().trim():''
                   trxMap['bankAccountNo']  =  INDEX[7]!=null?it[INDEX[7]].toString().trim():''
                   trxMap['trxid'] =  INDEX[1]!=null?it[INDEX[1]].toString().trim():''
                   trxMap['amount']   =  (INDEX[2]!=null?it[INDEX[2]].toString().trim().replaceAll(',',''):'0.00') as BigDecimal
                   def datex
                       if(INDEX[3] instanceof ArrayList){
                           datex=it[INDEX[3][0]].toString().trim()+it[INDEX[3][1]].toString().trim()
                       } else{
                           datex=it[INDEX[3]].toString().trim()
                       }

                   trxMap['acquireDate']  = Date.parse(TRADE_DATEFORMAT, datex)
                    def trxstsk ;
                    if(INDEX[4]!=null){
                        if(INDEX[4] instanceof ArrayList){
                            if(it[INDEX[4][0]].toString().trim()==SUCCESS_TAG[0]&&it[INDEX[4][1]].toString().trim()==SUCCESS_TAG[1]){
                                trxstsk=1
                            }else{trxstsk=2}
                          }else{
                              if(it[INDEX[4]].toString().trim()==SUCCESS_TAG[0]){
                                   trxstsk=1
                              }else if(it[INDEX[4]].toString().trim()==SUCCESS_TAG[1]){
                                   trxstsk=0
                              }else{
                                  trxstsk=2
                              }
                          }
                     }else{
                        trxstsk=1
                    }
                   trxMap['trxsts']  = trxstsk
                   if(INDEX[6]!=null){
                       if(INDEX[6] instanceof ArrayList){
                          datex=it[INDEX[6][0]].toString().trim()+it[INDEX[6][1]].toString().trim()
                      } else{
                          datex=it[INDEX[6]].toString().trim()
                      }
                      trxMap['accountDate']  = Date.parse(ACCOUNT_DATEFORMAT, datex)
                   } else{
                      trxMap['accountDate']  = null
                   }
                   trxlist<< trxMap
                 }
           }
           }
         }
         println trxlist
         println trxlist.size()
         return trxlist
     }

    def parseXls(bankCode, reader) {
        def SKIP_LINES = 0;
        /*收单商户号，订单号，金额，交易时间，交易状态,交易类型,记账日期,商户账号,手续费*/
        def INDEX = [:];
        def TRADE_DATEFORMAT = 'yyyyMMddHHmmss';
        def ACCOUNT_DATEFORMAT = 'yyyyMMdd';
        def SUCCESS_TAG=[]
        def TRADE_TYPE=[]
        def FINAL_LINE=0
        switch (bankCode) {
            case ['ceb','CEB']:      //光大银行
                SKIP_LINES=3
                INDEX = [0:0,1:1,2:4,3:5,4:10,5:3,6:7];
                TRADE_DATEFORMAT = 'yyyy-MM-dd'
                ACCOUNT_DATEFORMAT = 'yyyy-MM-dd'
                TRADE_TYPE =['消费']
                SUCCESS_TAG=['交易成功']
                FINAL_LINE=1
                break;
            case ['psbc','PSBC']:       //邮政储蓄
                SKIP_LINES=1
                INDEX = [1:2,2:3,3:[0,1],4:5,5:4];
                TRADE_DATEFORMAT = 'yyyy-MM-ddHH:mm:ss'
                TRADE_TYPE =['支付']
                SUCCESS_TAG=['成功']
		        FINAL_LINE=2
                break;
             case ['hzbank','HZBANK']:             //杭州
                SKIP_LINES=2
                INDEX = [1:0,2:1,3:2,4:4];
                TRADE_DATEFORMAT = 'yyyy年MM月dd日 HH:mm:ss'
                SUCCESS_TAG=['支付成功']
                FINAL_LINE=4
		        break;
             case ['cmb','CMB']:             //招商
                SKIP_LINES=2
                INDEX = [1:5,2:7,3:3,4:6,6:4];
                TRADE_DATEFORMAT = 'yyyyMMdd'
                ACCOUNT_DATEFORMAT = 'yyyyMMdd'
                SUCCESS_TAG=['已结帐']
                FINAL_LINE=2
                break;
             case ['unionpay','UNIONPAY']:             //银联
                SKIP_LINES=1
                INDEX = [0:3,1:4,2:5,3:2,4:6,5:10,6:16];
                TRADE_DATEFORMAT = 'yyyyMMddHHmmss'
                ACCOUNT_DATEFORMAT = 'yyyyMMdd'
                TRADE_TYPE =['0001']
                SUCCESS_TAG=[1001.0]
                FINAL_LINE=2
                break;
             case ['yintong','YINTONG']:             //连连
                SKIP_LINES=1

                INDEX = [0:1,1:0,2:6,3:2,4:8,5:3,6:5,7:10];
                TRADE_DATEFORMAT = 'yyyyMMdd HH:mm:ss'
                ACCOUNT_DATEFORMAT = 'yyyyMMdd'
                TRADE_TYPE =[101001]
                SUCCESS_TAG=[0]
                FINAL_LINE=2
                break;
             case ['online','ONLINE']:             //网银在线
                SKIP_LINES=1
             /*收单商户号，订单号，金额，交易时间，交易状态,交易类型,记账日期,商户账号,手续费*/
                INDEX = [1:0,2:1,3:8,4:5,5:4,6:8,7:2];
                TRADE_DATEFORMAT = 'yyyy-MM-dd HH:mm:ss'
                ACCOUNT_DATEFORMAT = 'yyyy-MM-dd HH:mm:ss'
                TRADE_TYPE =['支付单']
                SUCCESS_TAG=['成功订单']
                FINAL_LINE=2
                break;
            case ['tft','TFT']:             //腾付通
                SKIP_LINES=2
             /*收单商户号，订单号，金额，交易时间，交易状态,交易类型,记账日期,商户账号,手续费*/
                INDEX = [1:3,2:11,3:7,4:9,5:1,6:7,7:14];
                TRADE_DATEFORMAT = 'yyyy-MM-dd HH:mm:ss'
                ACCOUNT_DATEFORMAT = 'yyyy-MM-dd HH:mm:ss'
                TRADE_TYPE =['消费']
                SUCCESS_TAG=['支付成功']
                FINAL_LINE=3
                break;
        }
         int i= 0

         def trxlist=[];
         new Excel2003Builder(reader).eachLine {
             // println "First column on row ${line.rowNum} = ${cell(3)}"
//             println  cell(INDEX[4])
             i++
           if(i>SKIP_LINES){
               if(cell(FINAL_LINE)){
                 if(INDEX[5]==null||it[INDEX[5]]==TRADE_TYPE[0]){
                 def trxMap=[:]
                   trxMap['acquireMerchant']  =  INDEX[0]!=null?cell(INDEX[0]):''
                   trxMap['bankAccountNo']  =  INDEX[7]!=null?cell(INDEX[7]):''
                   trxMap['trxid'] =  INDEX[1]!=null?cell(INDEX[1]):''
                   trxMap['amount']   =  (INDEX[2]!=null?cell(INDEX[2]):'0.00') as BigDecimal
                   def datex
                   if(INDEX[3]!=null){
                       if(INDEX[3] instanceof ArrayList){
                           datex=cell(INDEX[3][0])+cell(INDEX[3][1])
                       } else{
                           datex=cell(INDEX[3])
                       }


                       if(datex instanceof java.util.Date){
                          trxMap['acquireDate']  = datex;
                       }else{
                           trxMap['acquireDate']  = Date.parse(TRADE_DATEFORMAT, datex)
                       }



                   } else{
                      trxMap['acquireDate']  = null
                   }

                   if(INDEX[6]!=null){
                      if(INDEX[6] instanceof ArrayList){
                          datex=cell(INDEX[6][0])+cell(INDEX[6][1])
                      } else{
                          datex=cell(INDEX[6])
                      }

                     if(INDEX[7]!=null){   // 手续费


                         if(cell(INDEX[7]) instanceof String){
                              trxMap['fee']= Double.parseDouble(cell(INDEX[7]).toString());
                         }else{
                              trxMap['fee']= cell(INDEX[7]);
                         }
                      }else{
                          trxMap['fee']=0;
                     }
                    if(datex instanceof Double){

                        BigDecimal db = new BigDecimal(datex);

                        datex =db.toPlainString();

                    }

                       if(datex instanceof java.util.Date){
                          trxMap['accountDate']  = datex;
                       }else{
                           trxMap['accountDate']  = Date.parse(ACCOUNT_DATEFORMAT, datex)
                       }


                   } else{
                      trxMap['accountDate']  = null
                   }

                   def trxstsk
                    if(INDEX[4]!=null){
                        if(INDEX[4] instanceof ArrayList){
                            if(cell(INDEX[4][0])==SUCCESS_TAG[0]&&cell(INDEX[4][1])==SUCCESS_TAG[1]){
                                trxstsk=1
                            }else{trxstsk=2}
                          }else{
                              if(cell(INDEX[4])==SUCCESS_TAG[0]){
                                   trxstsk=1
                              }else if(cell(INDEX[4])==SUCCESS_TAG[1]){
                                   trxstsk=0
                              }else{
                                  trxstsk=2
                              }
                          }
                     }else{
                        trxstsk=1
                    }
                   trxMap['trxsts']  = trxstsk
                   trxlist<< trxMap
               }
               }
           }
         }
        println trxlist
        println trxlist.size()
        return trxlist

     }


    def parseXlsx(bankCode, reader) {
        def SKIP_LINES = 0;
        /*收单商户号，订单号，金额，交易时间，交易状态,交易类型,记账日期*/
        def INDEX = [:];
        def TRADE_DATEFORMAT = 'yyyyMMddHHmmss'; /*"消"; */
        def ACCOUNT_DATEFORMAT = 'yyyyMMdd'; /*"消"; */
        def SUCCESS_TAG=[]
        def TRADE_TYPE=[]
        def FINAL_LINE=0
        switch (bankCode) {
            case ['ceb','CEB']:      //光大银行
                SKIP_LINES=3
                INDEX = [0:0,1:1,2:4,3:5,4:10,5:3,6:7];
                TRADE_DATEFORMAT = 'yyyy-MM-dd'
                ACCOUNT_DATEFORMAT = 'yyyy-MM-dd'
                TRADE_TYPE =['消费']
                SUCCESS_TAG=['交易成功']
                FINAL_LINE=1
                break;
            case ['psbc','PSBC']:       //邮政储蓄
                SKIP_LINES=1
                INDEX = [1:2,2:3,3:[0,1],4:5,5:4];
                TRADE_DATEFORMAT = 'yyyy-MM-ddHH:mm:ss'
                TRADE_TYPE =['支付']
                SUCCESS_TAG=['成功']
		        FINAL_LINE=2
                break;
             case ['hzbank','HZBANK']:             //杭州
                SKIP_LINES=2
                INDEX = [1:0,2:1,3:2,4:4];
                TRADE_DATEFORMAT = 'yyyy年MM月dd日 HHmmss'
                SUCCESS_TAG=['支付成功']
                FINAL_LINE=4
                break;
             case ['cmb','CMB']:             //招商
                SKIP_LINES=2
                INDEX = [1:5,2:7,3:3,4:6,6:4];
                TRADE_DATEFORMAT = 'yyyyMMdd'
                ACCOUNT_DATEFORMAT = 'yyyyMMdd'
                SUCCESS_TAG=['已结帐']
                FINAL_LINE=2
                break;
             case ['unionpay','UNIONPAY']:             //银联
                SKIP_LINES=1
                INDEX = [0:3,1:4,2:5,3:2,4:6,5:10,6:16];
                TRADE_DATEFORMAT = 'yyyyMMddHHmmss'
                ACCOUNT_DATEFORMAT = 'yyyyMMdd'
                TRADE_TYPE =['0001']
                SUCCESS_TAG=[1001.0]
                FINAL_LINE=2
                break;

        }
         int i= 0

         def trxlist=[];
         new Excel2007Builder(reader).eachLine {
             // println "First column on row ${line.rowNum} = ${cell(3)}"
//             println  cell(0)
//             println  cell(1)
//             println  cell(INDEX[0])
//             println  cell(INDEX[1])
//             println  cell(INDEX[2])
//             println  cell(INDEX[3])
//             println  cell(INDEX[4])
//             println  cell(INDEX[5])
//             println  cell(INDEX[6])
            i++
           if(i>SKIP_LINES){
               if(cell(FINAL_LINE)){
                 if(INDEX[5]==null||it[INDEX[5]]==TRADE_TYPE[0]){
                 def trxMap=[:]
                   trxMap['acquireMerchant']  =  INDEX[0]!=null?cell(INDEX[0]):''
                   trxMap['bankAccountNo']  =  INDEX[7]!=null?cell(INDEX[7]):''
                   trxMap['trxid'] =  INDEX[1]!=null?cell(INDEX[1]):''
                   trxMap['amount']   =  (INDEX[2]!=null?cell(INDEX[2]):'0.00') as BigDecimal
                   def datex
                   if(INDEX[3]!=null){
                       if(INDEX[3] instanceof ArrayList){
                           datex=cell(INDEX[3][0])+cell(INDEX[3][1])
                       } else{
                           datex=cell(INDEX[3])
                       }
                       trxMap['acquireDate']  = Date.parse(TRADE_DATEFORMAT, datex)
                   } else{
                      trxMap['accountDate']  = null
                   }

                   if(INDEX[6]!=null){
                      if(INDEX[6] instanceof ArrayList){
                          datex=cell(INDEX[6][0])+cell(INDEX[6][1])
                      } else{
                          datex=cell(INDEX[6])
                      }
                      trxMap['accountDate']  = Date.parse(ACCOUNT_DATEFORMAT, datex)
                   } else{
                      trxMap['accountDate']  = null
                   }
                   def trxstsk ;
                    if(INDEX[4]!=null){
                        if(INDEX[4] instanceof ArrayList){
                            if(cell(INDEX[4][0])==SUCCESS_TAG[0]&&cell(INDEX[4][1])==SUCCESS_TAG[1]){
                                trxstsk=1
                            }else{trxstsk=2}
                          }else{
                              if(cell(INDEX[4])==SUCCESS_TAG[0]){
                                   trxstsk=1
                              }else if(cell(INDEX[4])==SUCCESS_TAG[1]){
                                   trxstsk=0
                              }else{
                                  trxstsk=2
                              }
                          }
                     }else{
                        trxstsk=1
                    }
                   trxMap['trxsts']  = trxstsk
                   trxlist<< trxMap
               }
               }
          }
         }
        println trxlist
        println trxlist.size()
         return trxlist
     }
}
