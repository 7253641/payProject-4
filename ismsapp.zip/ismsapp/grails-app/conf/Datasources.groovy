import org.codehaus.groovy.grails.commons.*
import refund.TradeRefund
import refund.TradeBase
import ismsapp.Gwtrxs
import ismsapp.Gwsyn
import ismsapp.AcquireSynTrx
import ismsapp.AcquireFaultTrx

datasources = {
    datasource(name: 'ismp'){
        domainClasses([
                ismsapp.AcquireFaultTrx,
                ismsapp.AcquireSynTrx,
                ismsapp.AcquireSynResult,
                ismsapp.Gwsyn,
                ismsapp.Gwtrxs,
                refund.TradeBase,
                refund.TradeRefund

        ])
        readOnly(Boolean.parseBoolean(ConfigurationHolder.config.dataSource.ismp.readOnly == null ? 'false' : ConfigurationHolder.config.dataSource.ismp.readOnly))
        driverClassName(ConfigurationHolder.config.dataSource.ismp.driverClassName)
        url(ConfigurationHolder.config.dataSource.ismp.url)
        //println "ismp:"+ConfigurationHolder.config.dataSource.ismp.url
        username(ConfigurationHolder.config.dataSource.ismp.username)
        //println "ismp:"+ConfigurationHolder.config.dataSource.ismp.password
//        println "ismpPWD:"+DESCodec.decode(ConfigurationHolder.config.dataSource.ismp.password)
//        println "123456"
        password(ConfigurationHolder.config.dataSource.ismp.password)
//                password("ismp")
        println "88888"
        dbCreate(ConfigurationHolder.config.dataSource.ismp.dbCreate)
        pooled(Boolean.parseBoolean(ConfigurationHolder.config.dataSource.ismp.pooled == null ? 'false' : ConfigurationHolder.config.dataSource.ismp.pooled))
        logSql(Boolean.parseBoolean(ConfigurationHolder.config.dataSource.ismp.logSql == null ? 'false' : ConfigurationHolder.config.dataSource.ismp.logSql))
        dialect(ConfigurationHolder.config.dataSource.ismp.dialect)
        hibernate {
            cache {
                use_second_level_cache(false)
                use_query_cache(false)
                provider_class('net.sf.ehcache.hibernate.EhCacheProvider')
            }
        }
    }

}
