class UrlMappings {

	static mappings = {
       "/$controller/$action?/$id?"{
			constraints {
				// apply constraints here
			}
		}
       "/rpc/pumpin/$id?"{
          controller="pumpin"
          action = [GET:"show", PUT:"update", DELETE:"delete", POST:"save"]
       }

		"/"(view:"/index")
		"500"(view:'/error')
	}
}
