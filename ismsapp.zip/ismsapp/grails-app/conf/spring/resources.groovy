import org.apache.commons.dbcp.BasicDataSource
import org.codehaus.groovy.grails.commons.*

beans={
    httpInvokeClientService(org.springframework.remoting.httpinvoker.HttpInvokerProxyFactoryBean){
        serviceUrl=ConfigurationHolder.config.cashier.serverURL+"/httpFaultTrxInvoke.do"
        serviceInterface="HttpInvokeService"
    }
    httpInvokePublishService(org.springframework.remoting.httpinvoker.HttpInvokerProxyFactoryBean){
        serviceUrl=org.codehaus.groovy.grails.commons.ConfigurationHolder.config.cashier.serverURL+"/httpProcInvoke.do"
        serviceInterface="HttpInvokeService"
    }
     httpInvokeABCService(org.springframework.remoting.httpinvoker.HttpInvokerProxyFactoryBean){
        serviceUrl=org.codehaus.groovy.grails.commons.ConfigurationHolder.config.cashier.serverURL+"/httpABCInvoke.do"
        serviceInterface="HttpInvokeService"
    }
    httpInvokeHsbcClientService(org.springframework.remoting.httpinvoker.HttpInvokerProxyFactoryBean){
        serviceUrl=org.codehaus.groovy.grails.commons.ConfigurationHolder.config.jniproxy.url+"/httpJniProxy.do"
        serviceInterface="JniProxyService"
    }
}
