package ismsapp


class AutoSynAcquireJob {
    static triggers = {
       simple name: 'synTrigger', startDelay:1000, repeatInterval:3*60*1000
    }
    def synAcquireService

    def execute() {
       log.info "auto syntrigger job is running..."
       def banklist=['YINTONG','tft','BOC','CCB','ABC','SDB','BOCM','CMB','CEB',"ICBC","CMBC","ABC_B2B","CMBC_B2B"]

       banklist.each(){x->
         log.info "starting bank:"+x
         synAcquireService.inputdata(x);
       }
       synAcquireService.serviceMethod();
    }
}
