package ismsapp


class CashierPublishJob {
   // def timeout = 5000l // execute job once in 5 seconds
    static triggers = {
       simple name: 'cashierTriggers', startDelay:3000, repeatInterval: 6*60*1000
    }
    def httpInvokePublishService
    def execute() {
         log.info "cashier publish trigger is running"
         httpInvokePublishService.tx_publish();
    }
}
