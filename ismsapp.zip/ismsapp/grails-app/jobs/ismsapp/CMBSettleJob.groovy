package ismsapp


class CMBSettleJob {
    //def timeout = 5000l // execute job once in 5 seconds
    static triggers = {
       simple name: 'cmbTrigger', startDelay:1000, repeatInterval:15*60*1000
    }
    def cmbService

    def execute() {
       log.info "cmb settle job is running..."
       cmbService.cronSettle()
    }
}
