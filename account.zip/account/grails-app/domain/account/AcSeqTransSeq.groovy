package account

class AcSeqTransSeq {

  static mapping = {
    id generator: 'sequence', params: [sequence: 'seq_ac_transseq']
  }
  static constraints = {
  }
}
