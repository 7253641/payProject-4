/*
 * @Id: BeanFactoryProxy.java 13:51:22 2006-2-14
 * 
 * @author 
 * @version 1.0
 * PAYGW_CORE PROJECT
 */
package ebank.core.bank;

public interface BeanFactoryProxy {

}
