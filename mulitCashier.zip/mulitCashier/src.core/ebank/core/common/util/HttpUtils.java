/*
 * Created on 2004-12-19
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ebank.core.common.util;


import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;


/**
 * @author fengwh
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class HttpUtils {
	static Logger logger = Logger.getLogger(HttpUtils.class); 
	
	/***
	 * ȡ�����в���
	 * @param HttpServletRequest req
	 * @return Properties����������/ֵ��
	 */
	
	
	
}
