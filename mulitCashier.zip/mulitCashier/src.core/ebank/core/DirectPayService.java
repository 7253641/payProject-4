package ebank.core;


public interface DirectPayService {
	public String WrapDirectPayByOrderid(String orderid,String encpaypwd);
	
}
