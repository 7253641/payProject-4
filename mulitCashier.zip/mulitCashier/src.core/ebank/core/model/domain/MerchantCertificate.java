package ebank.core.model.domain;


public class MerchantCertificate {

	private String certPath;
	private String certDate;
	public String getCertPath() {
		return certPath;
	}
	public void setCertPath(String certPath) {
		this.certPath = certPath;
	}
	public String getCertDate() {
		return certDate;
	}
	public void setCertDate(String certDate) {
		this.certDate = certDate;
	}

	
	

}
