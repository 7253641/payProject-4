package ebank.web.controller;

import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import ebank.core.OrderService;
import ebank.core.PayResultService;
import ebank.core.STEngineService;
import ebank.core.bank.BankService;
import ebank.core.bank.BankServiceFactory;
import ebank.core.bank.logic.BankCode;
import ebank.core.common.ServiceException;
import ebank.core.common.util.Amount;
import ebank.core.domain.PayResult;
import ebank.core.model.domain.GwOrders;
import ebank.core.model.domain.GwTrxs;
import ebank.web.common.WebConstants;
import ebank.web.common.WebError;
import ebank.web.common.WebEvent;
import ebank.web.common.util.LocaleUtil;
import ebank.web.common.util.RequestUtil;
import ebank.web.common.util.Validator;


/**
 * 
 * @author admin
 *
 */
public class PayNotify implements Controller{
	
	private Log log=LogFactory.getLog(this.getClass());
	private static final String CONTENT_TYPE = "text/html; charset=UTF-8";   
	
	private OrderService orderService;		
	private PayResultService payResultService;	
	private BankServiceFactory services;
	private String resultExport;	
	private STEngineService engineService;
	private boolean productionMode=false;
	
	private String getAdaptorBankID(HttpServletRequest request)throws ServiceException {
		String bankID="";		
		String uri=RequestUtil.HtmlEscape(request.getRequestURI());
		if(uri!=null&&uri.indexOf("/PayRec/")>=0&&uri.indexOf(".idx")>0){//special url return url			
			return uri.substring(uri.indexOf("/PayRec/")+8,uri.indexOf(".idx"));
		}
		if(request.getParameter("ERR")!=null){
			throw new ServiceException(request.getParameter("ERR"));
		}
		if(request.getParameter("idx")!=null){
			bankID=String.valueOf(request.getParameter("idx"));
			bankID=bankID.split("\\?")[0];
			//���´���url���ܴ�'?idx='�ŵ�����
		}else if(request.getParameter("interfaceVersion")!=null){ //����
			bankID=BankCode.BKID_ICBC[0];
		}else if(request.getParameter("merVAR")!=null && request.getParameter("notifyData") != null){ //���� version 1.0.0.11
			bankID=BankCode.BKID_ICBC_11[0];
		}
		else if(request.getParameter("EncMsg")!=null){ //����
			bankID=BankCode.BKID_BOC[0];
		}
		else if(request.getParameter("MerchantPara")!=null){			
			bankID=String.valueOf(RequestUtil.HtmlEscape(request.getParameter("MerchantPara")));  //���д���
		}else if(request.getParameter("BillNo")!=null&&request.getParameter("Signature")!=null){
			bankID=BankCode.BKID_CMB[0];
		}
		else if(request.getParameter("payresult")!=null){//��������		
			if(request.getParameter("payresult").indexOf("<CMBCB2B>")>=0){
				bankID=BankCode.BKID_CMBC_B2B[0];		
			}else{
				bankID=BankCode.BKID_CMBC[0];		
			}
		}else if(request.getParameter("netBankTraceNo")!=null){//��ҵ����
			bankID=BankCode.BKID_CIB[0];				
		}else if(request.getParameter("sequence")!=null){ //�㷢����
			bankID=BankCode.BKID_GDB[0];				
		}else if(request.getParameter("BRANCHID")!=null){//����
            //�������ַ���
			bankID=BankCode.BKID_CCB[0];
		}else if(request.getParameter("MPOSID")!=null){//����
            //�������ַ���
			bankID=BankCode.BKID_B2B_CCB[0];
		}else if(request.getParameter("checkvalue")!=null){//�����Ϻ�����
			bankID=BankCode.BKID_SYL[0];				
		}else if(request.getParameter("return_msg")!=null){//GYL  
			bankID=BankCode.BKID_GYL[0];
		}else if(request.getParameter("NetpayNotifySignData")!=null){//GYL
			bankID=BankCode.BKID_B2B_COMM[0];
		}else if(request.getParameter("cq")!=null){//��������	(��'?'bug)	
			String arg=request.getParameter("cq");			
			if(arg.indexOf("errorcode=p80017")>0)
			  bankID=BankCode.BKID_CQCB[0];
			else if(arg.indexOf("errorcode=p80012")>0)
				throw new ServiceException("400000");
			else if(arg.indexOf("errorcode=p80015")>0)
				throw new ServiceException("400001");
			else if(arg.indexOf("errorcode=1091")>0
					||arg.indexOf("errorcode=1034")>0)
				throw new ServiceException("400002");
			else if(arg.indexOf("errorcode=ICORE|EBK0021")>0){
				throw new ServiceException("400000");
			}else
				throw new ServiceException("400004");
		}else if(request.getParameter("remark")!=null && request.getParameter("remark").equals("0908")){//�㸶
			bankID = BankCode.BKID_HeePay[0];
		}else{
			throw new ServiceException(WebEvent.SERVICE_URLPARAM);
		}	
		return bankID;
		
	}
	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.mvc.Controller#handleRequest(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		
		response.setContentType(CONTENT_TYPE);
		PrintWriter out = null;
				
		HashMap<String,Object> reqs=RequestUtil.getFormInput(request);	
		reqs.put("NR","SID_"+request.getParameter("remark")+"");
		log.debug("From Bank:"+reqs);
		BankService bank=null;		
		//ȡ����Ӧ������		
		try{			
			out = response.getWriter();	
            //error page
			String bankID=this.getAdaptorBankID(request); //��������
			if(log.isDebugEnabled()) log.debug("bank idx="+bankID);			
			try{
			    bank=services.getBank(bankID);//ȡ����Ӧ�����з���
			    if(log.isDebugEnabled())log.debug("RESULT FROM:"+bank.getBankname());
			}catch(Exception ex){				
				throw new ServiceException(WebEvent.SERVICE_NOTPROVIDED);
			}			
            if(bankID!=null&&bankID.length()>=3)
			if((BankCode.BKID_ICBC[0].equals(bankID.substring(0,3))&&!reqs.containsKey("v_md5info"))
					||(BankCode.BKID_B2B_ICBC[0].equals(bankID)&&!reqs.containsKey("v_md5info"))
					||(BankCode.BKID_B2B_BOC[0].equals(bankID)&&!reqs.containsKey("v_md5info"))	
					||(BankCode.BKID_BOB[0].equals(bankID))&&!(reqs.containsKey("v_info"))//�������У���������,������
				  ){ 
					String url=bank.getRcvURL(reqs);				
					response.setContentLength(url.length());				
					if(log.isDebugEnabled()) log.debug("** special url **="+url);
					out.print(url);
					return null;
			}
            if(BankCode.BKID_B2B_CCB[0].equals(bankID)&&!reqs.containsKey("AMOUNT")){ 
					if(log.isDebugEnabled()) log.debug("** CCB_B2B Post args is null**");
					return null;
			}
            PayResult result=null;
            
            log.debug("mode value:"+request.getParameter("mode"));
            
            log.debug("mode judge :"+(!productionMode&&"test".equals(request.getParameter("mode"))));
            //TODO :IMPORTANT //MOCK RETURN            
            if(!productionMode&&"test".equals(request.getParameter("mode"))){
            	
            	log.warn("********* System is running on test receive result Mode,remember to close the test mode ********");
                result=new PayResult(request.getParameter("trxnum"),request.getParameter("bankcode"),new BigDecimal(request.getParameter("amount")),Integer.parseInt(request.getParameter("sts")));
		    }else{				
			//����֧�����
		    	log.debug("come in boc");
			    result=bank.getPayResult(reqs);
		    }
            log.debug("result is value:"+result);
			if(result==null){
				throw new ServiceException(WebEvent.PAYRESULT_HANDLE_FAILURE);
			}	
			result.setPayer_ip(RequestUtil.getIpAddr(request)); //��¼���clientIP
			GwTrxs gw20=orderService.findTrxByTrxnum(result.getTransnum(), result.getBankcode());
			
			GwOrders gw10=orderService.findOrderByTrx(result.getTransnum(),result.getBankcode()); //�����Ķ�����

			if(gw20==null){
				throw new ServiceException(WebEvent.ORDER_NOTFOUNDBYSEQ,result.getTransnum());
			}else{		
				//У����			
				if(result.getBankamount()!=null&&gw20.getAmount()!=Amount.getIntAmount(String.valueOf(result.getBankamount()),2)){
					throw new ServiceException(WebEvent.ORDER_PRICENOTEQUAL);  //ͬ��У����
				}	
				
				//У�����
				if(result.getCurrency()!=null&&!gw20.getCurrency().equalsIgnoreCase(result.getCurrency())){
					throw new ServiceException(WebEvent.CURRENCY_NOTMATCH);  //ͬ��У�����
				}
				//����˸÷��ض���
				result.setOrder(gw10);
				result.setTrx(gw20);
				
				//������������Ƕ��ҳ��
				if(!Validator.isNull(bank)&&bank.getBankcode().equals("CMBC")){
					this.setResultExport("v4/resultExportForCMBC");
				}else{
					this.setResultExport("v4/resultExport");
				}
				//i18n				
				if("1".equals(gw20.getTrxsts())){ //charge without payment or repeated refresh	
					if(isBggroud(bankID,reqs,out)) return null;	
					if("2".equals(reqs.get("r9_BType"))) return null;//�ױ�֧��ʱ������������2ʱΪ��������Ե�ͨѶ
					request.getSession().setAttribute("e_lang",LocaleUtil.getLocale(gw10==null?"CN":gw10.getLocale(),"CN"));
					Map<String,Object> mp=new HashMap<String,Object>();
					mp.put("result",result);
					mp.put("trx", gw20);
					if(gw10!=null){
						mp.put("order",gw10);
						if(result.getOrder()!=null){							
							mp.put("locale",LocaleUtil.getLocale(result.getOrder().getLocale(),"CN"));
							mp.put("forms", payResultService.mapresult(result.getOrder(),false));
						}
						Map<String,Object> map = RequestUtil.HtmlEscapeMap(mp);
						if(result.getOrder()!=null)
							map.put("action", RequestUtil.getAction(result.getOrder().getReturn_url()));
						return new ModelAndView(this.getResultExport(),"res",map);
					}else					
						return new ModelAndView("common/payresult","res",RequestUtil.HtmlEscapeMap(mp));					
				}
				
			}
			
			GwTrxs trx=null;
			
			trx=engineService.post(result);		
			
			if(trx!=null&&(!"1".equals(trx.getTrxsts())&&!"-1".equals(trx.getTrxsts()))){
				throw new ServiceException(WebEvent.TRX_PROCESSFAILURE);
			}
			if(trx==null) throw new ServiceException(WebEvent.STATE_UPDATEFAILURE);
			//��̨֪ͨ
			if(isBggroud(bankID,reqs,out)) return null;
			//���Ƶ���
			String exporter=this.getResultExport();			
			//ָ��ģ�͵���action
					
			Map<String,Object> mp=new HashMap<String,Object>();
			mp.put("result",result);
			mp.put("action","#");			
			if(result.getOrder()!=null){
				//get update order
				result.setOrder(orderService.findOrderByPk(result.getOrder().getId())); 
				mp.put("locale",LocaleUtil.getLocale(result.getOrder().getLocale(),"CN"));
				mp.put("forms", payResultService.mapresult(result.getOrder(),false));
			}						
			Map<String,Object> map = RequestUtil.HtmlEscapeMap(mp);
			if(result.getOrder()!=null)
				map.put("action", RequestUtil.getAction(result.getOrder().getReturn_url()));
			return new ModelAndView(this.getResultExport(),"res",map);			
		}catch(Exception e){	
			e.printStackTrace();
			return new ModelAndView(WebConstants.ERROR_PAGE,  WebConstants.ERROR_MODEL,new WebError(e));			
		
		}finally{			
			out.close();
			reqs=null;	
		}		
	}
	
	private boolean isBggroud(String bankid,HashMap reqs,PrintWriter out) throws ServiceException{				
		if(bankid!=null&&
		  (String.valueOf("SID_"+bankid).equalsIgnoreCase(String.valueOf(reqs.get("NR")))
		   ||bankid.equals(String.valueOf(reqs.get("NR")))
		   )){	
			log.debug("response background:"+bankid+"["+reqs.get("RES")+"]");
			String resp=String.valueOf(reqs.get("RES")==null?bankid:reqs.get("RES"));
			out.print(resp);
			reqs.remove("RES");
			return true;		
		}else{
			log.debug(String.valueOf("SID_"+bankid)+" NR="+reqs.get("NR"));
		}
		return false;
	}

	/**
	 * @param orderService The orderService to set.
	 */
	public void setOrderService(OrderService orderService) {
		this.orderService = orderService;
	}
	

	/**
	 * @param engineService The engineService to set.
	 */
	public void setEngineService(STEngineService engineService) {
		this.engineService = engineService;
	}


	/**
	 * @param payResultService The payResultService to set.
	 */
	public void setPayResultService(PayResultService payResultService) {
		this.payResultService = payResultService;
	}

	/**
	 * @param services The services to set.
	 */
	public void setServices(BankServiceFactory services) {
		this.services = services;
	}

	/**
	 * @param resultExport The resultExport to set.
	 */
	public void setResultExport(String resultExport) {
		this.resultExport = resultExport;
	}

	/**
	 * @return Returns the resultExport.
	 */
	public String getResultExport() {
		return resultExport;
	}
	public boolean isProductionMode() {
		return productionMode;
	}
	public void setProductionMode(boolean productionMode) {
		this.productionMode = productionMode;
	}

}
