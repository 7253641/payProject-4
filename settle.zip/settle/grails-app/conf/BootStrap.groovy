import ismp.CmCustomer

class BootStrap {

    def init = { servletContext ->
      //println CmCustomer.list().size()
    }
    def destroy = {
    }
}
