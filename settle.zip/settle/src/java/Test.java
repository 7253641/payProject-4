/**
 * Created by IntelliJ IDEA.
 * User: mmx
 * Date: 11-7-29
 * Time: 上午9:16
 * To change this template use File | Settings | File Templates.
 */
public class Test {
//  System.currentTimeMillis();
}
