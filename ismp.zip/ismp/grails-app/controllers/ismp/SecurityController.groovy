package ismp

class SecurityController {

    def index = {
    }

}
