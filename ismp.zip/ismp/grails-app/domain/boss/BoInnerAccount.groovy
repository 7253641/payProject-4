package boss
//系统账户字典表
class BoInnerAccount {
  //键值
  String key
  //内置账户号
  String accountNo
  //说明
  String note

  static constraints = {
  }
}
