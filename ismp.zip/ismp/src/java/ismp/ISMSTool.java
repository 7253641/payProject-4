package ismp;


public interface ISMSTool {

    public String SendSms(String mobile,String content) throws Exception;
}
