package com.ecard.products.utils;

public class ObjectUtils {

	public static boolean isEmpty(Object obj) {
		return obj == null;
	}

	public static boolean isNotEmpty(Object obj) {
		return !isEmpty(obj);
	}
	
}
