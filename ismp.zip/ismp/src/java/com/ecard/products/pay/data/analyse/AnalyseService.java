package com.ecard.products.pay.data.analyse;

public interface AnalyseService<R, P> {
	public P analyse(R r);
}
