package com.ecard.products.pay.data.analyse.filename;

import com.ecard.products.pay.data.analyse.ResponsibilityChain;

/**
 * 用户支持的业务类型
 * 
 * @author tkZhu
 *
 *暂不使用
 *@deprecated
 */

public class BizTypeVerifyResponsibilityChain extends ResponsibilityChain{

	public BizTypeVerifyResponsibilityChain(ResponsibilityChain next) {
		super(next);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String processSelf(String r) {
		// TODO Auto-generated method stub
		return null;
	}
}
